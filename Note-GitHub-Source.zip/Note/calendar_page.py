import calendar
import tkinter as tk
import tkinter.font as tkfont
from datetime import date
from tkinter import ttk

from ledger import ledger_totals, money
from visual import ACCENT, BG, EDGE, FONT, INK, MUTED, PRIMARY, WHITE, Action, pixels


class CalendarDay(Action):
    def __init__(self, parent, day, summary, selected, recorded, command):
        self.day = day
        self.summary = summary
        self.selected = selected
        super().__init__(parent, str(day.day), command, WHITE, width=73, height=79,
                         background="#c0dcfa" if selected else "#edf5ff" if recorded else WHITE,
                         hover="#dfecfb", foreground=INK)
        self.caption_font = tkfont.Font(parent, family=FONT, size=8)

    def draw_label(self, width, height):
        inset = pixels(self, 5)
        self.create_rectangle(1, 1, width - 1, height - 1, outline=ACCENT if self.selected else EDGE,
                              width=pixels(self, 1))
        self.create_text(inset, pixels(self, 11), text=self.day.day, anchor="w",
                         font=(FONT, 11, "bold"), fill=ACCENT if self.day == date.today() else INK)
        rows = (
            (f"收 {money(self.summary['income'])}" if self.summary["bills"] else "暂无收支",
             "#267254" if self.summary["bills"] else MUTED),
            (f"支 {money(self.summary['expense'])}" if self.summary["bills"] else "", "#a34d41"),
            (f"便签 {self.summary['notes']} · 日记 {self.summary['journals']}", MUTED),
        )
        for i, (text, color) in enumerate(rows):
            while text and self.caption_font.measure(text) > width - 2 * inset:
                text = text[:-2] + "…" if len(text) > 1 else ""
            self.create_text(inset, pixels(self, 30 + i * 17), text=text, anchor="w",
                             font=self.caption_font, fill=color)


class CalendarPage:
    def __init__(self, parent, workspace):
        outer = tk.Canvas(parent, bg=BG, highlightthickness=0)
        outer_scroll = ttk.Scrollbar(parent, orient="vertical", command=outer.yview)
        outer.configure(yscrollcommand=outer_scroll.set)
        outer_scroll.pack(side="right", fill="y")
        outer.pack(side="left", fill="both", expand=True)
        page = tk.Frame(outer, bg=BG)
        item = outer.create_window(0, 0, window=page, anchor="nw")
        outer.bind("<Configure>", lambda event: outer.itemconfigure(item, width=event.width))
        page.bind("<Configure>", lambda event: outer.configure(scrollregion=outer.bbox("all")))
        self.outer = outer
        parent = page
        self.workspace = workspace
        self.app = workspace.app
        self.day = date.today()
        self.month = self.day.replace(day=1)
        self.records = {}

        toolbar = tk.Frame(parent, bg=BG)
        toolbar.pack(fill="x", pady=(0, pixels(parent, 9)))
        self.heading = tk.Label(toolbar, bg=BG, fg=INK, font=(FONT, 20, "bold"))
        self.heading.pack(side="left")
        for caption, callback in (("›", lambda: self.shift(1)),
                                  ("今天", lambda: self.select(date.today())),
                                  ("‹", lambda: self.shift(-1))):
            Action(toolbar, caption, callback, BG, background=WHITE, foreground=ACCENT,
                   width=50, height=29).pack(side="right", padx=(pixels(parent, 4), 0))
        self.grid = tk.Frame(parent, bg=WHITE, highlightbackground=EDGE, highlightthickness=1,
                             padx=pixels(parent, 5), pady=pixels(parent, 5))
        self.grid.pack(fill="x")
        for col, label in enumerate(("周一", "周二", "周三", "周四", "周五", "周六", "周日")):
            self.grid.columnconfigure(col, weight=1, uniform="day")
            tk.Label(self.grid, text=label, bg=WHITE, fg=MUTED, font=(FONT, 9)).grid(
                row=0, column=col, sticky="ew", pady=(0, pixels(parent, 3)))
        self.cells = []
        detail_bar = tk.Frame(parent, bg=BG)
        detail_bar.pack(fill="x", pady=(pixels(parent, 8), pixels(parent, 4)))
        self.detail = tk.Label(detail_bar, bg=BG, fg=INK, font=(FONT, 12, "bold"))
        self.detail.pack(side="left")
        Action(detail_bar, "本日记账", lambda: self.open_ledger(self.day), BG,
               background=PRIMARY, foreground=ACCENT, bold=True, height=28).pack(side="right")
        list_frame = tk.Frame(parent, bg=BG)
        list_frame.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(list_frame, bg=BG, highlightthickness=0, height=pixels(parent, 255))
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.canvas.yview)
        scrollbar.pack(side="right", fill="y")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.sections = tk.Frame(self.canvas, bg=BG)
        self.sections.columnconfigure((0, 1), weight=1, uniform="records")
        self.task_sections = tk.Frame(self.sections, bg=BG)
        self.task_sections.grid(row=0, column=0, sticky="new", padx=(0, pixels(parent, 6)))
        self.daily_sections = tk.Frame(self.sections, bg=BG)
        self.daily_sections.grid(row=0, column=1, sticky="new")
        content = self.canvas.create_window(0, 0, window=self.sections, anchor="nw")
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(content, width=event.width))
        self.sections.bind("<Configure>", lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<MouseWheel>", self.scroll_records)

    def scroll_page(self, event):
        self.outer.yview_scroll(-int(event.delta / 120) * 3, "units")
        return "break"

    def scroll_records(self, event):
        self.canvas.yview_scroll(-int(event.delta / 120) * 3, "units")
        return "break"

    def shift(self, offset):
        number = (self.month.year - 1) * 12 + self.month.month - 1 + offset
        if 0 <= number < 9999 * 12:
            year, month = divmod(number, 12)
            self.select(date(year + 1, month + 1, 1))

    def select(self, day):
        self.day = day
        self.month = day.replace(day=1)
        self.refresh()
        self.canvas.yview_moveto(0)

    def refresh(self):
        self.heading.configure(text=f"{self.month.year} 年 {self.month.month} 月")
        days_with_records = self.app.store.calendar_days(self.month)
        summaries = self.app.store.calendar_summary(self.month)
        for cell in self.cells:
            cell.destroy()
        self.cells.clear()
        weeks = calendar.Calendar(firstweekday=calendar.MONDAY).monthdayscalendar(self.month.year, self.month.month)
        for row, week in enumerate(weeks, 1):
            for col, number in enumerate(week):
                if not number:
                    continue
                day = self.month.replace(day=number)
                recorded = day in days_with_records
                selected = day == self.day
                summary = summaries.get(day, dict(notes=0, journals=0, income=0, expense=0, bills=0))
                cell = CalendarDay(self.grid, day, summary, selected, recorded,
                                   lambda value=day: self.select(value))
                cell.grid(row=row, column=col, sticky="ew", padx=2, pady=2)
                cell.bind("<MouseWheel>", self.scroll_page)
                self.cells.append(cell)
        self.render_records()

    def render_records(self):
        self.detail.configure(text=f"{self.day.isoformat()}  ·  当天记录")
        for column in (self.task_sections, self.daily_sections):
            for child in column.winfo_children():
                child.destroy()
        self.records.clear()
        pending = self.app.store.desktop_tasks()
        completed = self.app.store.completed_tasks_on(self.day)
        for field, heading, tasks, empty in (
                ("due_at", "未完成待办", pending, "当前没有未完成待办"),
                ("completed_at", "当日已完成待办", completed, "当天没有完成记录")):
            self.add_heading(self.task_sections, heading, len(tasks))
            for task in tasks:
                time = task[field]
                suffix = f"  ·  {time[5:16]}" if time else ""
                self.add_record(task["title"] + suffix, "tasks", task)
            if not tasks:
                self.empty(empty)
        notes = self.app.store.notes_on(self.day)
        self.add_heading(self.daily_sections, "便签", len(notes))
        for note in notes:
            self.add_record(note["title"].strip() or "无标题便签", "notes", note)
        if not notes:
            self.empty("当天没有便签")
        self.add_heading(self.daily_sections, "本日日记")
        for kind, heading in (("mood", "三栏情绪日记"), ("review", "四象限日记")):
            exists = self.app.store.journal(kind, self.day) is not None
            self.add_record(heading if exists else heading + " · 开始记录", kind, self.day)
        ledger = self.app.store.ledger_entries(self.day)
        self.add_heading(self.daily_sections, "本日记账", len(ledger))
        if ledger:
            income, expense = ledger_totals(ledger)
            self.empty(f"收入 {money(income)}  ·  支出 {money(expense)}")
            self.add_record(f"结余 {money(income - expense)} · 查看明细", "ledger", self.day)
        else:
            self.empty("当天还没有账单")

    def add_heading(self, column, text, count=None):
        self.section = tk.Frame(column, bg=WHITE, padx=9, pady=6,
                                highlightbackground=EDGE, highlightthickness=1)
        self.section.pack(fill="x", pady=(0, pixels(self.sections, 6)))
        label = tk.Label(self.section, text=text if count is None else f"{text}  ·  {count}",
                         bg=WHITE, fg=ACCENT, font=(FONT, 10, "bold"))
        label.pack(anchor="w")
        label.bind("<MouseWheel>", self.scroll_records)
        self.section.bind("<MouseWheel>", self.scroll_records)

    def empty(self, text):
        label = tk.Label(self.section, text=text, bg=WHITE, fg=MUTED, font=(FONT, 9))
        label.pack(anchor="w")
        label.bind("<MouseWheel>", self.scroll_records)

    def add_record(self, label, kind, data):
        self.records[len(self.records)] = kind, data
        button = Action(self.section, label[:58] + ("…" if len(label) > 58 else "") + "   ›",
                        lambda: self.open_record(kind, data), WHITE, background=WHITE,
                        foreground=INK, height=27, width=100, align="left")
        button.pack(fill="x")
        button.bind("<MouseWheel>", self.scroll_records)

    def open_record(self, kind, data):
        if kind == "notes":
            self.app.edit_note(data)
        elif kind == "tasks":
            self.app.edit_task(data)
        elif kind == "ledger":
            self.open_ledger(data)
        else:
            self.workspace.open_journal(kind, data)

    def open_ledger(self, day):
        if self.workspace.ledger.select_date(day):
            self.app.show_main("ledger")
