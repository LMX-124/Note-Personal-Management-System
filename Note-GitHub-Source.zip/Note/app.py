import ctypes
import sqlite3
import sys
import tkinter as tk
from calendar import monthrange
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import messagebox, simpledialog, ttk

from PIL import Image

from category_manager import CategoryManager
from desktop import DesktopPanel
from note_preview import NOTE_COLORS, NOTE_STYLES, NotePreview, choose_note_picture
from palette import NEUTRAL, UNCATEGORIZED
from storage import Store, database_path
from visual import (ACCENT, APP_NAME, BG, EDGE, FONT, INK, MUTED, PRIMARY, PRIMARY_HOVER, SOFT_BLUE, SUBTLE, WHITE,
                    Action, CategoryPicker, pixels)
from workspace import Workspace


TIME_FORMAT = "%Y-%m-%d %H:%M"


def parse_time(value, field):
    value = value.strip()
    if not value:
        return None
    for time_format in (TIME_FORMAT, TIME_FORMAT + ":%S"):
        try:
            return datetime.strptime(value, time_format)
        except ValueError:
            pass
    raise ValueError(f"{field}请用 年-月-日 时:分，可包含秒，例如 2026-11-07 19:30:00。")


def show_window(window):
    window.deiconify()
    window.lift()
    window.focus_set()


def heading(parent, title, detail):
    ttk.Label(parent, text=title, style="Heading.TLabel").pack(anchor="w")
    ttk.Label(parent, text=detail, style="Muted.TLabel").pack(anchor="w", pady=(3, 12))

def editor_panel(window, title, detail):
    panel = ttk.Frame(window, padding=pixels(window, 23))
    panel.pack(fill="both", expand=True)
    heading(panel, title, detail)
    return panel


def field(parent, row, label, widget):
    ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, pixels(parent, 15)))
    widget.grid(row=row, column=1, sticky="ew", pady=pixels(parent, 4))


def data_error(parent, error):
    messagebox.showerror("操作未保存", str(error), parent=parent)


def enable_dpi_scaling():
    if sys.platform == "win32":
        ctypes.windll.user32.SetProcessDPIAware()


class DateTimePicker:
    def __init__(self, parent, variable, shortcut=None, thirty_seconds=None):
        self.variable = variable
        self.shortcut = shortcut
        self.thirty_shortcut = thirty_seconds
        self.frame = ttk.Frame(parent)
        line = ttk.Frame(self.frame)
        line.pack(fill="x")
        ttk.Entry(line, textvariable=variable).pack(side="left", fill="x", expand=True)
        self.arrow = Action(line, "▾", self.toggle, BG, foreground=ACCENT, height=34, width=34, font_size=12)
        self.arrow.pack(side="right", padx=(pixels(parent, 6), 0))
        self.panel = tk.Frame(self.frame, bg=SOFT_BLUE, padx=pixels(parent, 7), pady=pixels(parent, 6))
        self.parts = [tk.StringVar(self.panel) for _ in range(5)]
        self.boxes = []
        for column, (caption, part) in enumerate(zip("年月日时分", self.parts)):
            tk.Label(self.panel, text=caption, bg=SOFT_BLUE, fg=ACCENT, font=(FONT, 9)).grid(
                row=0, column=column, sticky="w", padx=pixels(parent, 2))
            box = ttk.Combobox(self.panel, textvariable=part, state="readonly", width=4 if column == 0 else 2)
            box.grid(row=1, column=column, padx=pixels(parent, 2), pady=(0, pixels(parent, 4)))
            box.bind("<<ComboboxSelected>>", self.selection_changed)
            self.boxes.append(box)
        if shortcut is not None:
            Action(self.panel, "下一分钟提醒", self.use_shortcut, SOFT_BLUE, background=SOFT_BLUE,
                   foreground=ACCENT, height=27, font_size=9).grid(row=2, column=0, columnspan=3, sticky="w")
        if thirty_seconds is not None:
            self.thirty_seconds = Action(self.panel, "30 秒后提醒", self.use_thirty_shortcut,
                                         SOFT_BLUE, background=SOFT_BLUE, foreground=ACCENT,
                                         height=27, font_size=9)
            self.thirty_seconds.grid(row=3, column=0, columnspan=3, sticky="w")
        Action(self.panel, "使用此时间", self.apply, SOFT_BLUE, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, height=27, font_size=9).grid(
                   row=3 if thirty_seconds is not None else 2, column=3, columnspan=2, sticky="e")

    def toggle(self):
        if self.panel.winfo_manager():
            self.close()
            return
        try:
            initial = parse_time(self.variable.get(), "时间") or datetime.now()
        except ValueError:
            initial = datetime.now()
        numbers = (initial.year, initial.month, initial.day, initial.hour, initial.minute)
        for part, number in zip(self.parts, numbers):
            part.set(f"{number:02d}")
        year = datetime.now().year
        ranges = ((min(initial.year, year - 1), max(initial.year, year + 10)), (1, 12),
                  (1, monthrange(initial.year, initial.month)[1]), (0, 23), (0, 59))
        for box, (start, end) in zip(self.boxes, ranges):
            box["values"] = [f"{number:02d}" for number in range(start, end + 1)]
        self.panel.pack(fill="x", pady=(pixels(self.frame, 4), 0))
        self.arrow.update_style("▴", PRIMARY, ACCENT)

    def selection_changed(self, event=None):
        year, month, day, hour, minute = (int(part.get()) for part in self.parts)
        maximum = monthrange(year, month)[1]
        self.boxes[2]["values"] = [f"{number:02d}" for number in range(1, maximum + 1)]
        day = min(day, maximum)
        self.parts[2].set(f"{day:02d}")
        self.variable.set(datetime(year, month, day, hour, minute).strftime(TIME_FORMAT))

    def apply(self):
        self.selection_changed()
        self.close()

    def use_shortcut(self):
        self.shortcut()
        self.close()

    def use_thirty_shortcut(self):
        self.thirty_shortcut()
        self.close()

    def close(self):
        self.panel.pack_forget()
        self.arrow.update_style("▾", SUBTLE, ACCENT)


class TaskEditor:
    def __init__(self, app, task):
        self.app = app
        self.task = task
        self.window = tk.Toplevel(app.root)
        title = "编辑待办事项" if task else "新建待办事项"
        self.window.title(title)
        self.window.resizable(False, False)
        self.title = tk.StringVar(self.window, task["title"] if task else "")
        self.category = tk.StringVar(self.window, task["category"] if task else next(iter(app.store.categories())))
        self.due = tk.StringVar(self.window, (task["due_at"] or "")[:16] if task else "")
        self.reminder = tk.StringVar(self.window, (task["remind_at"] or "") if task else "")

        panel = editor_panel(self.window, title, "填写事项名称，按需要安排时间。")
        form = ttk.Frame(panel)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)
        name = ttk.Entry(form, textvariable=self.title, width=35)
        field(form, 0, "事项名称", name)
        self.category_picker = CategoryPicker(form, self.category, app.store.category_colors,
                                              lambda: app.create_category(self.window), app.refresh_tasks,
                                              on_manage=lambda: app.manage_categories(self.window, self.category.get()))
        field(form, 1, "分类", self.category_picker)
        self.deadline_picker = DateTimePicker(form, self.due)
        self.reminder_picker = DateTimePicker(form, self.reminder, shortcut=self.next_minute,
                                              thirty_seconds=self.next_thirty_seconds)
        field(form, 2, "截止时间", self.deadline_picker.frame)
        field(form, 3, "定时提醒", self.reminder_picker.frame)

        actions = ttk.Frame(panel)
        actions.pack(fill="x", pady=(pixels(form, 16), 0))
        Action(actions, "保存待办", self.save, BG, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, bold=True, height=37).pack(side="right")
        Action(actions, "取消", self.window.destroy, BG, height=37).pack(side="right", padx=pixels(form, 8))
        self.window.bind("<Escape>", lambda event: self.window.destroy())
        self.window.bind("<Control-Return>", lambda event: self.save())
        name.focus_set()

    def next_minute(self):
        self.reminder.set((datetime.now() + timedelta(minutes=1)).strftime(TIME_FORMAT))

    def next_thirty_seconds(self):
        self.reminder.set((datetime.now() + timedelta(seconds=30)).strftime(TIME_FORMAT + ":%S"))

    def save(self):
        try:
            task_id = self.app.store.save_task(
                self.title.get(), self.category.get(),
                parse_time(self.due.get(), "截止时间"), parse_time(self.reminder.get(), "提醒时间"),
                task_id=self.task["id"] if self.task else None,
            )
        except (ValueError, sqlite3.Error) as error:
            data_error(self.window, error)
            return
        self.window.destroy()
        self.app.refresh_tasks()
        self.app.desktop.reveal_task(task_id)
        self.app.refresh_notes()
        self.app.check_reminders()


class NoteEditor:
    def __init__(self, app, note):
        self.app = app
        self.note_id = note["id"] if note else None
        self.pending = None
        self.window = tk.Toplevel(app.root)
        title = "编辑便签" if note else "新建便签"
        self.window.title(title)
        self.window.minsize(pixels(self.window, 650), pixels(self.window, 342))
        self.title = tk.StringVar(self.window, note["title"] if note else "")
        self.category = tk.StringVar(self.window, note["category"] if note else "未分类")
        self.templates = {label: key for key, label in NOTE_STYLES.items()}
        template = note["template"] if note and note["template"] in NOTE_STYLES else "lined"
        self.style = tk.StringVar(self.window, NOTE_STYLES[template])
        self.picture = note["image"] if note else None
        self.saved = (self.title.get(), note["body"] if note else "", self.category.get(), template, self.picture)
        self.status = tk.StringVar(self.window, "已本地保存" if note else "输入后自动保存")

        panel = editor_panel(self.window, title, "便签内容会自动保存到本机。")
        form = ttk.Frame(panel)
        form.pack(fill="both", expand=True)
        form.columnconfigure(1, weight=1)
        form.rowconfigure(3, weight=1)
        field(form, 0, "标题（可选）", ttk.Entry(form, textvariable=self.title, width=23))
        self.category_picker = CategoryPicker(
            form, self.category, lambda: {UNCATEGORIZED: NEUTRAL, **app.store.category_colors()},
            lambda: app.create_category(self.window), app.refresh_notes,
            on_manage=lambda: app.manage_categories(self.window, self.category.get()))
        field(form, 1, "分类", self.category_picker)
        picker = ttk.Combobox(form, state="readonly", textvariable=self.style, values=tuple(self.templates))
        field(form, 2, "便签款式", picker)
        ttk.Label(form, text="内容").grid(row=3, column=0, sticky="nw", pady=pixels(form, 7))
        self.body = tk.Text(form, width=23, height=6, wrap="word", undo=True, font=(FONT, 10),
                            bg=WHITE, fg=INK, relief="flat", highlightthickness=1,
                            highlightbackground=EDGE, highlightcolor=ACCENT, insertbackground=ACCENT,
                            padx=pixels(form, 8), pady=pixels(form, 6))
        self.body.grid(row=3, column=1, sticky="nsew", pady=pixels(form, 4))
        self.body.insert("1.0", self.saved[1])
        self.body.edit_modified(False)
        self.picture_frame = ttk.Frame(form)
        self.picture_frame.grid(row=4, column=1, sticky="ew")
        Action(self.picture_frame, "选择图片", self.choose_picture, BG, background=WHITE,
               foreground=ACCENT).pack(side="right")
        preview_panel = ttk.Frame(form)
        preview_panel.grid(row=0, column=2, rowspan=5, sticky="new", padx=(pixels(form, 16), 0))
        ttk.Label(preview_panel, text="便签预览", style="Section.TLabel").pack(anchor="w", pady=(0, pixels(form, 6)))
        self.preview = NotePreview(preview_panel, self.preview_content(), large=True)
        self.preview.pack()
        self.update_template()
        bar = ttk.Frame(panel)
        bar.pack(fill="x", pady=(pixels(panel, 16), 0))
        ttk.Label(bar, textvariable=self.status, style="Muted.TLabel").pack(side="left")
        Action(bar, "保存并关闭", self.close, BG, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, bold=True, height=37).pack(side="right")
        self.body.bind("<<Modified>>", self.body_changed)
        self.title.trace_add("write", self.content_changed)
        self.style.trace_add("write", self.select_template)
        self.category.trace_add("write", self.schedule_save)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.window.bind("<Control-s>", lambda event: self.save())
        self.body.focus_set()

    def select_template(self, *args):
        self.update_template()
        self.schedule_save()

    def preview_content(self):
        return {"template": self.templates[self.style.get()], "title": self.title.get(),
                "body": self.body.get("1.0", "end-1c"), "image": self.picture}

    def content_changed(self, *args):
        self.preview.update_note(self.preview_content())
        self.schedule_save()

    def update_template(self):
        template = self.templates[self.style.get()]
        self.body.configure(bg=NOTE_COLORS.get(template, ("", WHITE))[1])
        self.preview.update_note(self.preview_content())
        if template not in ("photo", "heart"):
            self.picture_frame.grid_remove()
        else:
            self.picture_frame.grid()

    def choose_picture(self):
        try:
            picture = choose_note_picture(self.window)
        except (OSError, ValueError, Image.DecompressionBombError) as error:
            data_error(self.window, error)
            return
        if picture is not None:
            self.picture = picture
            self.update_template()
            self.schedule_save()

    def body_changed(self, event):
        if self.body.edit_modified():
            self.body.edit_modified(False)
            self.content_changed()

    def schedule_save(self, *args):
        if self.pending is not None:
            self.window.after_cancel(self.pending)
        self.status.set("正在保存…")
        self.pending = self.window.after(450, self.save)

    def save(self):
        if self.pending is not None:
            self.window.after_cancel(self.pending)
            self.pending = None
        title = self.title.get()
        body = self.body.get("1.0", "end-1c")
        category = self.category.get()
        template = self.templates[self.style.get()]
        content = (title, body, category, template, self.picture)
        if content == self.saved or (self.note_id is None and not (title.strip() or body.strip() or self.picture)):
            self.status.set("已本地保存" if self.note_id is not None else "输入后自动保存")
            return True
        new_note = self.note_id is None
        try:
            self.note_id = self.app.store.save_note(title, body, category, note_id=self.note_id,
                                                  template=template, image=self.picture)
        except sqlite3.Error as error:
            self.status.set("保存失败")
            data_error(self.window, error)
            return False
        self.saved = content
        self.status.set("已本地保存")
        desktop = self.app.desktop
        if new_note and desktop.select_note(self.note_id):
            if desktop.window.state() == "withdrawn":
                self.app.show_desktop()
                self.window.lift()
        else:
            self.app.refresh_notes()
            if desktop.note_id == self.note_id:
                desktop.load_note()
        return True

    def close(self):
        if not self.save():
            return False
        self.window.destroy()
        return True


class CourseDesk:
    def __init__(self, root, store):
        self.root = root
        self.store = store
        self.task_editor = None
        self.note_editor = None
        self.task_signature = None
        self.tick_job = None
        self.root.title(APP_NAME)
        logo_path = Path(__file__).resolve().parent / "assets" / "note-logo.png"
        self.app_icon = tk.PhotoImage(master=root, file=str(logo_path))
        self.root.iconphoto(True, self.app_icon)
        self.brand_icon = self.app_icon.subsample(max(1, round(self.app_icon.width() / pixels(root, 35))))
        width, height, x, y = (pixels(root, value) for value in (980, 620, 42, 62))
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        self.root.minsize(pixels(root, 705), pixels(root, 440))
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self.hide_main)
        self.configure_style()
        self.workspace = Workspace(self)
        self.desktop = DesktopPanel(self)
        self.refresh_tasks()
        self.refresh_notes()
        self.tick_job = self.root.after(250, self.tick)

    def configure_style(self):
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(".", font=(FONT, 10), background=BG, foreground=INK)
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=INK)
        style.configure("Heading.TLabel", font=(FONT, 24, "bold"))
        style.configure("Section.TLabel", font=(FONT, 12, "bold"))
        style.configure("Muted.TLabel", foreground=MUTED)
        style.configure("TButton", padding=(pixels(self.root, 12), pixels(self.root, 6)),
                        background=WHITE, bordercolor=EDGE,
                        lightcolor=WHITE, darkcolor=WHITE, relief="flat")
        style.map("TButton", background=[("active", SOFT_BLUE)])
        style.configure("Accent.TButton", background=PRIMARY, foreground=ACCENT, bordercolor=PRIMARY,
                        lightcolor=PRIMARY, darkcolor=PRIMARY, font=(FONT, 10, "bold"))
        style.map("Accent.TButton", background=[("active", PRIMARY_HOVER)],
                  lightcolor=[("active", PRIMARY_HOVER)], darkcolor=[("active", PRIMARY_HOVER)])
        for field in ("TEntry", "TCombobox"):
            style.configure(field, padding=pixels(self.root, 5), fieldbackground=WHITE,
                            background=WHITE, bordercolor=EDGE, lightcolor=WHITE, darkcolor=WHITE)
            style.map(field, bordercolor=[("focus", ACCENT)], fieldbackground=[("readonly", WHITE)])
        style.layout("Vertical.TScrollbar", [
            ("Vertical.Scrollbar.trough", {"sticky": "ns", "children": [
                ("Vertical.Scrollbar.thumb", {"sticky": "nswe", "expand": True}),
            ]}),
        ])
        style.configure("Vertical.TScrollbar", width=7, gripcount=0, troughcolor=BG,
                        background="#becfe2", bordercolor=BG, lightcolor="#becfe2",
                        darkcolor="#becfe2", relief="flat")
        style.map("Vertical.TScrollbar", background=[("active", "#9ebbd8")])

    def show_main(self, page=None):
        if page:
            self.workspace.show_page(page)
        show_window(self.root)
        if page:
            self.root.focus_force()

    def hide_main(self):
        if not self.workspace.save_journals():
            return
        if self.desktop.window.state() == "withdrawn":
            self.show_desktop()
        self.root.withdraw()

    def show_desktop(self):
        show_window(self.desktop.window)

    @staticmethod
    def show_data_error(parent, error):
        data_error(parent, error)

    def refresh_tasks(self):
        now = datetime.now()
        rows = self.store.desktop_tasks(include_done=True)
        now_text = now.isoformat(sep=" ", timespec="seconds")
        def is_late(row):
            return bool(row["due_at"] and row["due_at"] <= now_text)

        states = [(row, is_late(row)) for row in rows]
        unfinished = [row for row in rows if not row["done"]]
        colors = self.store.category_colors()
        self.desktop.render_tasks(unfinished, colors)
        mode = self.workspace.mode
        category = self.workspace.task_category.get()
        if category != "全部分类" and category not in colors:
            category = "全部分类"
            self.workspace.task_category.set(category)
        signature = (mode, category, colors, [(tuple(row), late) for row, late in states])
        if signature == self.task_signature:
            return
        self.task_signature = signature
        scoped = [(row, late) for row, late in states
                  if category == "全部分类" or row["category"] == category]
        visible = [(row, late) for row, late in scoped
                   if mode == "all" or bool(row["done"]) == (mode == "done")]
        done_count = sum(row["done"] for row, _ in scoped)
        self.workspace.render_tasks(visible, len(scoped) - done_count, done_count, colors)
        if self.workspace.active_page == "calendar":
            self.workspace.calendar.refresh()

    def create_category(self, parent):
        name = simpledialog.askstring("新建分类", "分类名称", parent=parent)
        if name is None:
            return None
        try:
            category = self.store.create_category(name)
        except (ValueError, sqlite3.Error) as error:
            data_error(parent, error)
            return None
        self.refresh_category_views()
        return category

    def manage_categories(self, parent, selected):
        manager = CategoryManager(parent, self, selected)
        manager.window.wait_visibility()
        manager.window.grab_set()
        parent.wait_window(manager.window)

    def refresh_category_views(self, removed=None):
        categories = self.store.categories()
        task_editor = self.task_editor
        if task_editor and task_editor.window.winfo_exists():
            if task_editor.category.get() == removed:
                fallback = UNCATEGORIZED if UNCATEGORIZED in categories else categories[0]
                task_editor.category.set(fallback)
            task_editor.category_picker.refresh()
        note_editor = self.note_editor
        if note_editor and note_editor.window.winfo_exists():
            if note_editor.category.get() == removed:
                note_editor.category.set(UNCATEGORIZED)
            note_editor.category_picker.refresh()
        self.refresh_tasks()
        self.refresh_notes()

    def refresh_notes(self):
        category = self.workspace.note_category.get()
        categories = self.store.categories()
        if category not in categories:
            category = ""
            self.workspace.note_category.set("全部分类")
        rows = self.store.notes(self.workspace.note_query.get(), category)
        self.note_rows = {row["id"]: row for row in rows}
        desktop = self.desktop
        self.workspace.render_notes(rows, desktop.note_id if desktop.note_visible and desktop.display_kind == "note" else None)
        if self.workspace.active_page == "calendar":
            self.workspace.calendar.refresh()

    def edit_task(self, task=None):
        if self.task_editor and self.task_editor.window.winfo_exists():
            show_window(self.task_editor.window)
        else:
            self.task_editor = TaskEditor(self, task)
        return self.task_editor

    def complete_task(self, task_id, done=True):
        try:
            self.store.set_done(task_id, done)
        except sqlite3.Error as error:
            data_error(self.root, error)
            return
        self.refresh_tasks()
        self.check_reminders()

    def delete_task(self, row):
        if messagebox.askyesno("删除待办", f"删除「{row['title']}」？", parent=self.root):
            editor = self.task_editor
            if editor and editor.window.winfo_exists() and editor.task and editor.task["id"] == row["id"]:
                editor.window.destroy()
            self.store.delete_task(row["id"])
            self.refresh_tasks()

    def edit_note(self, note=None):
        if not self.desktop.flush_note():
            return self.note_editor
        if note is not None:
            note = self.note_rows.get(note["id"], note)
        if self.note_editor and self.note_editor.window.winfo_exists():
            if note is None or self.note_editor.note_id == note["id"]:
                show_window(self.note_editor.window)
                return self.note_editor
            if not self.note_editor.close():
                return self.note_editor
        if note is None:
            latest = self.store.notes()
            note = latest[0] if latest else None
        self.note_editor = NoteEditor(self, note)
        return self.note_editor

    def new_note(self):
        if self.note_editor and self.note_editor.window.winfo_exists() and not self.note_editor.close():
            return self.note_editor
        self.note_editor = NoteEditor(self, None)
        return self.note_editor

    def pin_note(self, note_id):
        if self.desktop.select_note(note_id):
            self.show_desktop()

    def delete_note(self, row):
        if messagebox.askyesno("删除便签", "删除这张便签？", parent=self.root):
            editor = self.note_editor
            if editor and editor.window.winfo_exists() and editor.note_id == row["id"]:
                if editor.pending is not None:
                    editor.window.after_cancel(editor.pending)
                editor.window.destroy()
            self.store.delete_note(row["id"])
            if self.desktop.note_id == row["id"]:
                self.desktop.load_note()
            self.refresh_notes()

    def check_reminders(self):
        due = self.store.take_reminders(datetime.now())
        if not due:
            return
        self.desktop.show_reminders(due)

    def tick(self):
        try:
            self.check_reminders()
            self.refresh_tasks()
            self.desktop.refresh_summary()
        finally:
            self.tick_job = self.root.after(2500, self.tick)

    def close(self):
        if not self.workspace.save_journals():
            return
        if not self.desktop.flush_note():
            return
        if self.note_editor and self.note_editor.window.winfo_exists() and not self.note_editor.close():
            return
        if self.tick_job is not None:
            self.root.after_cancel(self.tick_job)
        self.root.destroy()


def main():
    enable_dpi_scaling()
    root = tk.Tk()
    try:
        store = Store(database_path())
    except (OSError, sqlite3.Error) as error:
        root.withdraw()
        data_error(root, error)
        root.destroy()
        return
    try:
        CourseDesk(root, store)
        root.mainloop()
    finally:
        store.close()


if __name__ == "__main__":
    main()
