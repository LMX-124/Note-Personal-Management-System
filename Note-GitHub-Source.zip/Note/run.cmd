@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\project.ps1" -Action Run
set "result=%errorlevel%"
if not "%result%"=="0" pause
exit /b %result%
