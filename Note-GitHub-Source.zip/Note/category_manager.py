import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

from palette import PALETTE, UNCATEGORIZED
from visual import (ACCENT, BG, FONT, INK, MUTED, PRIMARY, PRIMARY_HOVER,
                    SOFT_BLUE, WHITE, Action, category_tint, pixels)


class CategoryManager:
    def __init__(self, parent, app, selected=None):
        self.app = app
        self.window = tk.Toplevel(parent)
        self.window.title("管理分类")
        self.window.transient(parent)
        self.window.resizable(False, False)
        self.window.bind("<Escape>", lambda event: self.window.destroy())
        panel = ttk.Frame(self.window, padding=pixels(self.window, 20))
        panel.pack(fill="both", expand=True)
        tk.Label(panel, text="管理分类", bg=BG, fg=INK, font=(FONT, 18, "bold")).pack(anchor="w")
        tk.Label(panel, text="选中分类后，点色块即可更改颜色。", bg=BG, fg=MUTED,
                 font=(FONT, 9)).pack(anchor="w", pady=(0, pixels(panel, 12)))

        content = tk.Frame(panel, bg=BG)
        content.pack(fill="both", expand=True)
        choices = tk.Frame(content, bg=BG)
        choices.pack(side="left", fill="y", padx=(0, pixels(panel, 12)))
        self.category_list = tk.Listbox(choices, width=17, height=9, bg=WHITE, fg=INK,
                                       font=(FONT, 10), borderwidth=0, highlightthickness=0,
                                       selectbackground=SOFT_BLUE, selectforeground=INK, exportselection=False)
        self.category_list.pack(side="left", fill="y")
        scroll = ttk.Scrollbar(choices, orient="vertical", command=self.category_list.yview)
        scroll.pack(side="right", fill="y")
        self.category_list.configure(yscrollcommand=scroll.set)
        self.category_list.bind("<<ListboxSelect>>", lambda event: self.draw_selection())

        palette = tk.Frame(content, bg=BG)
        palette.pack(side="left", fill="both", expand=True)
        self.summary = tk.StringVar(palette)
        self.current_preview = tk.Label(palette, textvariable=self.summary, bg=SOFT_BLUE, fg=ACCENT,
                                        font=(FONT, 10, "bold"), padx=pixels(panel, 8), pady=pixels(panel, 3))
        self.current_preview.pack(anchor="w", pady=(0, pixels(panel, 5)))
        grid = tk.Frame(palette, bg=BG)
        grid.pack()
        self.swatches = {}
        for index, (color, (_, tint)) in enumerate(PALETTE.items()):
            button = Action(grid, "", lambda value=color: self.apply_color(value), BG,
                            background=tint, foreground=color, hover=tint, height=29, width=66, font_size=9)
            button.grid(row=index // 5, column=index % 5, padx=pixels(grid, 2), pady=pixels(grid, 3))
            self.swatches[color] = button

        footer = tk.Frame(panel, bg=BG)
        footer.pack(fill="x", pady=(pixels(panel, 14), 0))
        Action(footer, "＋ 新建分类", self.create, BG, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, bold=True).pack(side="left")
        self.delete_button = ttk.Button(footer, text="删除分类", command=self.delete)
        self.delete_button.pack(side="left", padx=pixels(footer, 6))
        ttk.Button(footer, text="关闭", command=self.window.destroy).pack(side="right")
        self.refresh(selected)

    def refresh(self, selected=None):
        self.colors = self.app.store.category_colors()
        self.names = list(self.colors)
        self.category_list.delete(0, "end")
        for index, name in enumerate(self.names):
            self.category_list.insert("end", name)
            self.category_list.itemconfigure(index, foreground=self.colors[name])
        self.select_category(selected if selected in self.colors else self.names[0])

    def selected_category(self):
        selection = self.category_list.curselection()
        return self.names[selection[0]] if selection else None

    def select_category(self, name):
        index = self.names.index(name)
        self.category_list.selection_clear(0, "end")
        self.category_list.selection_set(index)
        self.category_list.activate(index)
        self.category_list.see(index)
        self.draw_selection()

    def draw_selection(self):
        name = self.selected_category()
        color = self.colors.get(name)
        short_name = name[:15] + "…" if name and len(name) > 16 else name
        self.summary.set(short_name or "选择分类")
        self.current_preview.configure(bg=category_tint(color) if color else SOFT_BLUE, fg=color or ACCENT)
        self.delete_button.state(["!disabled"] if name and name != UNCATEGORIZED else ["disabled"])
        sample = name if not name or len(name) <= 4 else name[:3] + "…"
        for value, button in self.swatches.items():
            _, tint = PALETTE[value]
            label = "✓ " + sample if sample and value == color else sample or ""
            button.update_style(label, tint, value)

    def apply_color(self, color):
        name = self.selected_category()
        if name is None:
            return
        try:
            self.app.store.set_category_color(name, color)
        except (ValueError, sqlite3.Error) as error:
            self.app.show_data_error(self.window, error)
            return
        self.app.refresh_category_views()
        self.refresh(name)

    def create(self):
        name = self.app.create_category(self.window)
        if name:
            self.refresh(name)

    def delete(self):
        name = self.selected_category()
        if name is None or name == UNCATEGORIZED:
            return
        if not messagebox.askyesno("删除分类", f"删除「{name}」？其中的待办和便签会移到「未分类」。",
                                   parent=self.window):
            return
        try:
            self.app.store.delete_category(name)
        except (ValueError, sqlite3.Error) as error:
            self.app.show_data_error(self.window, error)
            return
        self.app.refresh_category_views(removed=name)
        self.refresh()
