# Note

**Windows 本地待办、便签、日记与记账工具。**

使用 Python、Tkinter 与 SQLite 构建。桌面组件用于随手记录和处理事项，管理窗口提供分类、编辑与按日期回看；无需注册账号或配置 API Key。

## 功能

- **待办事项**：分类与颜色管理、截止时间、定时提醒、完成与恢复；桌面默认显示前三项，可展开并拖动排序。
- **轻量提醒**：在桌面组件下方显示事项名称和分类，点击提醒可收起；支持“30 秒后提醒”演示。
- **便签**：黄、蓝、粉色便签，白底、照片和并排款式；文字自动保存，可上传图片并选择桌面展示内容。
- **情绪日记**：事实、感受、需求三栏，支持心情和 emoji 多选。
- **四象限日记**：复盘、一日四分两套标题，也可自定义标题。
- **记账**：收入、支出、分类与备注；整数分计算金额，支持修改和删除。
- **日历**：周一至周日排列，每日方框显示收支及便签、日记数量，下方展示所选日期详情。

## 快速开始

### 方式一：直接运行 Windows 版本

如果项目 Releases 中提供 `Note-Windows.zip`，下载并解压后双击 `Note.exe`，不需要安装 Python。不要在压缩包预览中直接运行程序。

仓库源码不包含 exe；发布者可将单独准备的运行包上传到 GitHub Releases。

### 方式二：运行源码

**环境：Windows 10/11、64 位 Python 3.12，包含 Tcl/Tk。** 当前已在 Windows 11、Python 3.12.14、Pillow 13.0.0 上验证。桌面组件使用 Windows 专用窗口属性，暂未适配 macOS、Linux 或无桌面的服务器。

1. 安装 [Python](https://www.python.org/downloads/windows/)，包含 `pip`、`venv` 和 Tcl/Tk；命令 `py -3.12 --version` 应能找到 Python 3.12。
2. 下载仓库 ZIP 并解压，或用 Git 克隆项目。
3. 双击 **`setup.cmd`**：创建项目自己的 `.venv` 并安装依赖。首次安装需要联网。
4. 双击 **`run.cmd`** 启动。以后只需要运行这一步。

也可以在项目根目录打开 PowerShell，逐条执行：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

无需激活虚拟环境。Tkinter、sqlite3、unittest 等由 Python 提供，运行时唯一的第三方依赖是 Pillow。

## 第一次使用

1. 点“添加事项”，输入名称、分类和可选时间，保存后桌面与管理列表同步更新。
2. 展开提醒时间，点“30 秒后提醒”后**保存待办**。程序运行期间会检查提醒，通常在目标时间之后的下一次检查显示。
3. 拖动桌面任务标题调整顺序，点击圆圈完成；管理窗口可以查看、恢复已处理事项。
4. 桌面右上角“＋”可添加今天的便签、日记或账单。便签先选分类，再选款式；直接输入后自动保存。
5. 在日历点选日期，下方可以打开当天便签、日记及记账详情。

关闭管理窗口通常只是隐藏，桌面组件和提醒仍然运行。需要完全退出时，在桌面组件“···”菜单选择“退出 Note”。首次启动桌面默认只显示待办；创建便签或使用菜单可显示下方内容。

## 数据保存与备份

默认保存位置：

```text
%LOCALAPPDATA%\CourseDesk\course_desk.sqlite3
```

这是历史内部目录名，产品名仍是 Note。数据库与源码、exe 分开保存；换新版程序通常不会移除已有记录。便签图片也存放在数据库中。项目不包含作者的记录、备份、截图或课程汇报材料。

如需隔离演示数据，可为当前 PowerShell 会话指定另一份数据库：

```powershell
$env:COURSE_DESK_DB = Join-Path $PWD 'local-data\demo.sqlite3'
.\.venv\Scripts\python.exe app.py
```

要恢复默认位置，可关闭这个 PowerShell 会话，或执行 `Remove-Item Env:COURSE_DESK_DB`。`local-data` 和数据库文件已加入 `.gitignore`。

备份时先完全退出 Note，再复制数据库文件到安全位置；恢复前也应先退出。此应用没有云同步，数据库未加密，请自行妥善保管。

## 开发与测试

准备好环境后，双击 `test.cmd`，或运行：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

测试使用临时数据库，不读取或清空默认用户数据库。部分测试会短暂创建真实 Tk 窗口，因此需要 Windows 图形桌面环境。当前测试覆盖持久化、任务顺序、分类、日期归档、金额计算、界面联动和提醒等场景。

仓库附带 Windows / Python 3.12 的 GitHub Actions 测试配置；上传后会由 GitHub 执行，本地交付不代表云端流程已运行。

## 打包 exe

双击 `build.cmd`。脚本会安装打包依赖、运行测试，再生成 `dist\Note.exe`。首次安装需要联网，构建须在 Windows 上进行。

手动执行：

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m PyInstaller --noconfirm --windowed --onefile --name Note --icon assets/note.ico --add-data "assets/note-logo.png:assets" app.py
```

## 代码结构

```text
Note/
├── app.py                   # 入口、应用协调、任务及便签编辑器
├── storage.py               # SQLite 表、迁移、查询和事务
├── workspace.py             # 主窗口、侧栏与管理列表
├── desktop.py               # 桌面组件、拖动与紧凑提醒
├── calendar_page.py         # 日历和每日汇总
├── journal.py               # 三栏与四象限日记
├── ledger.py                # 记账与整数金额计算
├── category_manager.py      # 分类管理
├── note_preview.py          # 图片与便签预览
├── visual.py / palette.py   # 公共控件与颜色
├── assets/                  # 图标和 Logo
├── tests/                   # 数据与窗口测试
├── scripts/project.ps1      # 环境、启动、测试、构建入口
├── docs/                    # 使用、架构、GitHub 上传说明
├── .github/workflows/       # Windows 自动测试
├── requirements.txt         # 运行依赖
└── requirements-dev.txt     # 运行及打包依赖
```

一次操作的主线：**界面回调 → 输入校验 → Store 执行 SQL → SQLite 提交 → 主窗口和桌面刷新**。详见 [架构说明](docs/architecture.md)、[使用说明](docs/usage.md)、[上传 GitHub](docs/github.md)。

## 常见问题

| 问题 | 处理方式 |
|---|---|
| 找不到 Python 3.12 | 安装含 Tcl/Tk 的 Python 3.12；脚本也会检查 PATH 中的 `python` 是否为 3.12 |
| `No module named PIL` | 重新执行 `setup.cmd`，确保使用项目 `.venv` 的 Python |
| 缺少 `_tkinter` | 修改 Python 安装，补装 Tcl/Tk；可用 `py -3.12 -m tkinter` 检查 |
| 依赖下载失败 | 检查网络和 pip 输出后重新运行 `setup.cmd`，不要把其他人的 `.venv` 复制过来 |
| 提醒没有立即显示 | 确认已经保存且程序未完全退出；检查约每 2.5 秒进行一次 |
| 关闭窗口但程序还在 | 主窗口关闭为隐藏；使用组件菜单完全退出 |
| 两次打开似乎编辑同一份记录 | 默认数据库是同一份；建议一次只运行一个实例 |
| 双击脚本无法执行 | 在 PowerShell 使用上面的手动命令，或查看组织对脚本的限制 |

`.cmd` 启动器只为其子 PowerShell 进程设置执行策略，不修改系统的长期执行策略。

## 当前边界

- 本地单用户应用，没有账号体系、云同步、协作或后台服务。
- 提醒依赖程序运行，重新启动会检查未领取的到期提醒；不保证异常退出时恰好送达一次。
- 新任务参考截止时间插入，手动拖动后以保存位置为准；修改已有截止时间不会强制重排全部任务。
- 日历的未完成待办是当前清单，不是历史快照；便签按创建日期归档。
- 自动保存有短暂防抖间隔，强制结束或断电仍可能影响最后尚未保存的输入。

## 交流与许可

欢迎通过仓库 Issues 反馈复现步骤、系统版本和错误信息，请勿上传私人数据库或敏感截图。本交付未替作者选择开源许可证；发布者可在决定授权方式后添加 `LICENSE`。

## 参考资料

- [Python venv 文档](https://docs.python.org/3.12/library/venv.html)
- [Python Tkinter 文档](https://docs.python.org/3.12/library/tkinter.html)
- [Pillow 13.0.0](https://pypi.org/project/pillow/13.0.0/)
- [PyInstaller 6.22.3](https://pypi.org/project/pyinstaller/6.22.3/)
