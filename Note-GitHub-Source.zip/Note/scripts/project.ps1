param(
    [ValidateSet('Setup', 'Run', 'Test', 'Build')]
    [string]$Action = 'Run'
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvPython = Join-Path $ProjectRoot '.venv\Scripts\python.exe'

function Invoke-ProjectPython {
    param([string[]]$Arguments)
    & $VenvPython @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Python command failed (exit $LASTEXITCODE). See the output above."
    }
}

function Find-BasePython {
    $candidates = @(
        @{ File = 'py'; Prefix = @('-3.12') },
        @{ File = 'python'; Prefix = @() }
    )
    foreach ($candidate in $candidates) {
        $command = Get-Command $candidate.File -ErrorAction SilentlyContinue
        if ($null -eq $command) { continue }
        $prefixArguments = $candidate.Prefix
        try {
            & $command.Source @prefixArguments -c 'import sys, tkinter, sqlite3; assert sys.version_info[:2] == (3, 12)' 2>$null
            if ($LASTEXITCODE -eq 0) {
                return @{ File = $command.Source; Prefix = $prefixArguments }
            }
        } catch {
            continue
        }
    }
    throw 'Install Python 3.12 with pip, venv and Tcl/Tk, then run setup.cmd again.'
}

Push-Location $ProjectRoot
try {
    if ($Action -eq 'Setup') {
        if (-not (Test-Path -LiteralPath $VenvPython)) {
            $basePython = Find-BasePython
            $prefixArguments = $basePython.Prefix
            & $basePython.File @prefixArguments -m venv '.venv'
            if ($LASTEXITCODE -ne 0) { throw 'Could not create .venv.' }
        }
        Invoke-ProjectPython -Arguments @('-c', 'import sys, tkinter, sqlite3; assert sys.version_info[:2] == (3, 12)')
        Invoke-ProjectPython -Arguments @('-m', 'pip', 'install', '-r', 'requirements.txt')
        Write-Host 'Setup complete. Double-click run.cmd to start Note.'
    } else {
        if (-not (Test-Path -LiteralPath $VenvPython)) {
            throw 'Project environment not found. Run setup.cmd first.'
        }
        switch ($Action) {
            'Run' {
                Invoke-ProjectPython -Arguments @('app.py')
            }
            'Test' {
                Invoke-ProjectPython -Arguments @('-m', 'unittest', 'discover', '-s', 'tests', '-v')
            }
            'Build' {
                Invoke-ProjectPython -Arguments @('-m', 'pip', 'install', '-r', 'requirements-dev.txt')
                Invoke-ProjectPython -Arguments @('-m', 'unittest', 'discover', '-s', 'tests', '-v')
                Invoke-ProjectPython -Arguments @(
                    '-m', 'PyInstaller', '--noconfirm', '--windowed', '--onefile',
                    '--name', 'Note', '--icon', 'assets/note.ico',
                    '--add-data', 'assets/note-logo.png:assets', 'app.py'
                )
                Write-Host 'Build complete: dist\Note.exe'
            }
        }
    }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
} finally {
    Pop-Location
}
