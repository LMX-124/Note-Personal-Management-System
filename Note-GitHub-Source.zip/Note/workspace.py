import tkinter as tk
from datetime import date
from tkinter import ttk

from calendar_page import CalendarPage
from journal import JournalPage
from ledger import LedgerWindow
from note_preview import NotePreview
from palette import NEUTRAL
from visual import (ACCENT, APP_NAME, BG, EDGE, FONT, INK, MUTED, PRIMARY, PRIMARY_HOVER, SOFT_BLUE, SUBTLE, WHITE,
                    Action, CategoryPicker, CircleAction, FitLabel, RecordCard, category_tint, pixels, soft_rect)


SIDEBAR = "#eaf2fc"
PENDING_RED = "#bf324c"
DONE_GRAY = "#626d7b"
OVERDUE = "#b12740"
OVERDUE_BG = "#ffe3e9"


class ItemList:
    def __init__(self, parent):
        frame = tk.Frame(parent, bg=BG)
        frame.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(frame, bg=BG, highlightthickness=0, bd=0,
                                yscrollincrement=pixels(parent, 12))
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scroll = ttk.Scrollbar(frame, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scroll.set)
        self.inner = tk.Frame(self.canvas, bg=BG)
        self.content = self.canvas.create_window(0, 0, anchor="nw", window=self.inner)
        self.canvas.bind("<Configure>", self.resize)
        self.inner.bind("<Configure>", lambda event: self.resize())
        self.canvas.bind("<MouseWheel>", self.wheel)
        self.items = {}

    def resize(self, event=None):
        self.canvas.itemconfigure(self.content, width=self.canvas.winfo_width())
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        if self.inner.winfo_reqheight() > self.canvas.winfo_height():
            self.scroll.pack(side="right", fill="y", padx=(pixels(self.canvas, 4), 0))
        else:
            self.scroll.pack_forget()

    def wheel(self, event):
        self.canvas.yview_scroll(-int(event.delta / 120) * 3, "units")
        return "break"

    def replace(self, entries, make_item, empty_text):
        for child in self.inner.winfo_children():
            child.destroy()
        self.items = {row["id"]: make_item(self.inner, row, state) for row, state in entries}
        if not self.items:
            card = RecordCard(self.inner, height=94)
            tk.Label(card.body, text=empty_text, fg=MUTED, bg=WHITE,
                     font=(FONT, 10)).pack(anchor="w", pady=pixels(card.body, 20))


def compact_text(value, limit):
    line = " ".join(value.split())
    return line if len(line) <= limit else f"{line[:limit - 1]}…"


def title_and_detail(parent, title, detail):
    text = tk.Frame(parent, bg=WHITE)
    text.pack(side="left", fill="x", expand=True)
    FitLabel(text, title, (FONT, 11, "bold"), INK).pack(fill="x")
    FitLabel(text, detail, (FONT, 9), MUTED).pack(
        fill="x", pady=(pixels(text, 2), 0))


def row_menu(parent, actions):
    menu = tk.Menu(parent, tearoff=False, font=(FONT, 10))
    for label, callback in actions:
        menu.add_command(label=label, command=callback)
    button = Action(parent, "···", lambda: menu.tk_popup(button.winfo_rootx(),
                    button.winfo_rooty() + button.winfo_height()), WHITE,
                    background=WHITE, foreground=MUTED, bold=True, width=35)
    button.pack(side="right")
    return button


class Workspace:
    def __init__(self, app):
        self.app = app
        root = app.root
        self.mode = "open"
        self.task_category = tk.StringVar(root, "全部分类")
        self.note_category = tk.StringVar(root, "全部分类")
        self.note_query = tk.StringVar(root)
        self.task_open_count = tk.IntVar(root)
        self.task_done_count = tk.IntVar(root)
        self.note_count = tk.IntVar(root)
        sidebar = tk.Frame(root, bg=SIDEBAR, padx=pixels(root, 18), pady=pixels(root, 25))
        sidebar.pack(side="left", fill="y")
        brand = tk.Frame(sidebar, bg=SIDEBAR)
        brand.pack(fill="x", pady=(0, pixels(root, 36)))
        tk.Label(brand, image=app.brand_icon, bg=SIDEBAR, bd=0).pack(
            side="left", padx=(0, pixels(root, 5)))
        tk.Label(brand, text=APP_NAME, bg=SIDEBAR, fg=ACCENT, font=("Segoe UI", 23, "bold")).pack(
            side="left", padx=pixels(root, 4))
        self.pages = {}
        self.nav = {}
        self.content = tk.Frame(root, bg=BG, padx=pixels(root, 32), pady=pixels(root, 28))
        self.content.pack(side="left", fill="both", expand=True)
        for key, title in (("tasks", "待办事项"), ("notes", "便签库"),
                           ("calendar", "日历"), ("mood", "情绪日记"), ("review", "复盘日记"),
                           ("ledger", "记账")):
            self.pages[key] = tk.Frame(self.content, bg=BG)
            self.nav[key] = Action(sidebar, title, lambda name=key: self.show_page(name), SIDEBAR,
                                   width=130, height=41, align="left")
            self.nav[key].pack(fill="x", pady=(0, pixels(root, 5)))
        Action(sidebar, "显示桌面组件", app.show_desktop, SIDEBAR, background=WHITE,
               foreground=ACCENT, height=38).pack(side="bottom", fill="x")
        self.build_tasks(self.pages["tasks"])
        self.build_notes(self.pages["notes"])
        self.journals = {kind: JournalPage(self.pages[kind], app, kind) for kind in ("mood", "review")}
        self.calendar = CalendarPage(self.pages["calendar"], self)
        self.ledger = LedgerWindow(app, date.today(), self.calendar.refresh, parent=self.pages["ledger"])
        self.active_page = None
        self.show_page("tasks")
        root.bind("<Control-n>", lambda event: app.edit_task())
        root.bind("<Control-Shift-N>", lambda event: app.new_note())
        root.bind("<Control-s>", self.save_active_journal)

    def page_header(self, parent, title, metrics):
        header = tk.Frame(parent, bg=BG)
        header.pack(fill="x", pady=(0, pixels(parent, 13)))
        tk.Label(header, text=title, bg=BG, fg=INK,
                 font=(FONT, 25, "bold")).pack(side="left", anchor="n")
        totals = tk.Frame(header, bg=BG)
        totals.pack(side="right")
        for value, label, color in metrics:
            metric = tk.Frame(totals, bg=BG)
            metric.pack(side="left", padx=(pixels(parent, 18), pixels(parent, 2)))
            tk.Label(metric, textvariable=value, bg=BG, fg=color,
                     font=("Arial Black", 46, "bold")).pack()
            tk.Label(metric, text=label, bg=BG, fg=INK, font=(FONT, 9)).pack()

    def build_tasks(self, parent):
        self.page_header(parent, "待办事项", ((self.task_open_count, "待处理", PENDING_RED),
                                             (self.task_done_count, "已处理", DONE_GRAY)))
        filters = tk.Frame(parent, bg=BG)
        filters.pack(fill="x", pady=(0, pixels(parent, 11)))
        Action(filters, "＋  添加事项", self.app.edit_task, BG, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, bold=True, height=36).pack(side="right")
        self.task_category_picker = CategoryPicker(
            filters, self.task_category, self.app.store.category_colors,
            lambda: self.app.create_category(self.app.root), self.apply_task_category, include_all=True,
            on_manage=lambda: self.app.manage_categories(self.app.root, self.task_category.get()))
        self.task_category_picker.pack(side="right", padx=(0, pixels(parent, 8)))
        self.filters = {}
        for name, title in (("open", "待处理"), ("done", "已完成"), ("all", "全部")):
            button = Action(filters, title, lambda mode=name: self.set_task_filter(mode), BG,
                            foreground=MUTED, height=34)
            button.pack(side="left", padx=(0, pixels(parent, 7)))
            self.filters[name] = (button, title)
        self.tasks = ItemList(parent)

    def build_notes(self, parent):
        self.page_header(parent, "便签库", ((self.note_count, "便签总数", ACCENT),))
        tools = tk.Frame(parent, bg=BG)
        tools.pack(fill="x", pady=(0, pixels(parent, 15)))
        Action(tools, "＋  新建便签", self.app.new_note, BG, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, bold=True, height=36).pack(side="right")
        self.build_search(tools)
        self.category_button = CategoryPicker(
            tools, self.note_category, self.app.store.category_colors,
            lambda: self.app.create_category(self.app.root), self.app.refresh_notes, include_all=True,
            on_manage=lambda: self.app.manage_categories(self.app.root, self.note_category.get()))
        self.category_button.pack(side="left", padx=(pixels(tools, 8), 0))
        self.note_query.trace_add("write", lambda *args: self.app.refresh_notes())
        self.notes = ItemList(parent)

    def build_search(self, parent):
        p = lambda n: pixels(parent, n)
        search = tk.Canvas(parent, width=p(228), height=p(36), bg=BG, highlightthickness=0)
        search.pack(side="left")
        soft_rect(search, 0, 0, p(228), p(36), p(10), EDGE)
        soft_rect(search, 1, 1, p(228) - 1, p(36) - 1, p(10), WHITE)
        search.create_oval(p(13), p(11), p(23), p(21), outline=MUTED, width=p(1))
        search.create_line(p(22), p(20), p(27), p(25), fill=MUTED, width=p(1))
        entry = tk.Entry(search, textvariable=self.note_query, bg=WHITE, fg=INK,
                         insertbackground=INK, font=(FONT, 10), relief="flat", bd=0,
                         highlightthickness=0, selectbackground=SOFT_BLUE, selectforeground=INK)
        search.create_window(p(34), p(18), anchor="w", width=p(180), window=entry)
        hint = tk.Label(search, text="搜索便签", font=(FONT, 9), fg=MUTED, bg=WHITE, bd=0)

        def refresh_hint(event=None):
            show_hint = not self.note_query.get() and entry.focus_get() != entry
            if show_hint:
                hint.place(x=p(35), y=p(18), anchor="w")
                hint.lift()
            else:
                hint.place_forget()

        search.bind("<Button-1>", lambda event: entry.focus_set())
        hint.bind("<Button-1>", lambda event: entry.focus_set())
        entry.bind("<FocusIn>", refresh_hint)
        entry.bind("<FocusOut>", refresh_hint)
        self.note_query.trace_add("write", lambda *args: refresh_hint())
        refresh_hint()

    def show_page(self, selected):
        previous = self.journals.get(self.active_page)
        if previous is not None and selected != self.active_page and not previous.save():
            return
        self.active_page = selected
        for key, page in self.pages.items():
            page.pack_forget()
            button = self.nav[key]
            button.update_style(button.label, SOFT_BLUE if key == selected else SIDEBAR,
                                ACCENT if key == selected else MUTED)
        self.pages[selected].pack(fill="both", expand=True)
        if selected == "calendar":
            self.calendar.refresh()
        elif selected == "ledger":
            self.ledger.refresh()

    def open_journal(self, kind, day):
        if self.journals[kind].select_date(day):
            self.app.show_main(kind)

    def save_active_journal(self, event):
        journal = self.journals.get(self.active_page)
        if journal is not None:
            journal.save()
            return "break"

    def save_journals(self):
        return all(page.save() for page in self.journals.values())

    def set_task_filter(self, mode):
        self.mode = mode
        self.tasks.canvas.yview_moveto(0)
        self.app.refresh_tasks()

    def apply_task_category(self):
        self.tasks.canvas.yview_moveto(0)
        self.app.refresh_tasks()

    def render_tasks(self, visible, open_count, done_count, colors):
        self.colors = colors
        self.task_category_picker.refresh()
        self.task_open_count.set(open_count)
        self.task_done_count.set(done_count)
        for mode, (button, label) in self.filters.items():
            selected = mode == self.mode
            button.update_style(label, SOFT_BLUE if selected else BG,
                                ACCENT if selected else MUTED)
        if self.task_category.get() != "全部分类":
            empty = "这个分类下暂无事项。"
        else:
            empty = "这里会显示已完成的事项。" if self.mode == "done" else "清单还是空的，可以先添加一项。"
        self.tasks.replace(visible, self.task_card, empty)

    def task_card(self, parent, row, late):
        app = self.app
        card = RecordCard(parent)
        card.primary = CircleAction(card.body, row["done"],
                                    lambda: app.complete_task(row["id"], not row["done"]))
        card.primary.pack(side="left", padx=(0, pixels(parent, 9)))
        row_menu(card.body, (("编辑事项", lambda: app.edit_task(row)),
                             ("删除事项", lambda: app.delete_task(row))))
        text = tk.Frame(card.body, bg=WHITE)
        text.pack(side="left", fill="x", expand=True)
        title_line = tk.Frame(text, bg=WHITE)
        title_line.pack(fill="x")
        card.title = FitLabel(title_line, compact_text(row["title"], 48), (FONT, 13, "bold"),
                              MUTED if row["done"] else INK)
        if late and not row["done"]:
            card.overdue_badge = tk.Label(title_line, text="！已逾期", fg=OVERDUE, bg=OVERDUE_BG,
                                          font=(FONT, 9, "bold"), padx=pixels(card, 4))
            title_line.configure(height=card.title.winfo_reqheight())
            gap = pixels(card, 5)
            preferred = card.title.measure_font.measure(card.title.full_text) + 6

            def place_overdue(event):
                width = max(1, min(preferred, event.width - gap - card.overdue_badge.winfo_reqwidth()))
                card.title.place(x=0, y=event.height / 2, anchor="w", width=width)
                card.overdue_badge.place(x=width + gap, y=event.height / 2, anchor="w")

            title_line.bind("<Configure>", place_overdue)
        else:
            card.title.pack(fill="x")
        card.details = tk.Frame(text, bg=WHITE)
        card.details.pack(fill="x", pady=(pixels(text, 3), 0))
        category = row["category"]
        color = self.colors.get(category, NEUTRAL)
        tag = Action(card.details, compact_text(category, 8), lambda: self.task_category_picker.select(category),
                     WHITE, foreground=color, background=category_tint(color), height=21, font_size=9)
        tag.pack(side="left", padx=(0, pixels(card, 8)))
        if row["due_at"]:
            tk.Label(card.details, text=row["due_at"][:16], fg=INK, bg=WHITE,
                     font=(FONT, 9)).pack(side="left")
        self.bind_card_wheel(card, self.tasks.wheel)
        return card

    def render_notes(self, rows, active):
        self.category_button.refresh()
        self.note_count.set(len(rows))
        self.notes.replace([(row, row["id"] == active) for row in rows],
                           self.note_card, "没有找到便签。")

    def note_card(self, parent, row, active):
        app = self.app
        card = RecordCard(parent, height=89)
        icon = NotePreview(card.body, row)
        icon.pack(side="left", padx=(0, pixels(parent, 11)))
        row_menu(card.body, (("编辑便签", lambda: app.edit_note(row)),
                             ("删除便签", lambda: app.delete_note(row))))
        card.primary = Action(card.body, "展示中" if active else "展示到桌面",
                              lambda: app.pin_note(row["id"]), WHITE,
                              foreground=ACCENT, background=SOFT_BLUE if active else SUBTLE)
        card.primary.pack(side="right", padx=(0, pixels(parent, 6)))
        snippet = compact_text(row["body"], 32)
        details = f"{row['category']}  ·  {row['updated_at'][5:16]}"
        if snippet:
            details += f"  ·  {snippet}"
        title_and_detail(card.body, compact_text(row["title"], 38) or "无标题便签", details)
        self.bind_card_wheel(card, self.notes.wheel)
        return card

    @staticmethod
    def bind_card_wheel(widget, callback):
        widget.bind("<MouseWheel>", callback)
        for child in widget.winfo_children():
            Workspace.bind_card_wheel(child, callback)
