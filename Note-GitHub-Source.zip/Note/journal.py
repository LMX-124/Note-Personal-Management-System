import sqlite3
import tkinter as tk
from datetime import date, timedelta
from tkinter import messagebox, simpledialog, ttk

from visual import (ACCENT, PRIMARY, PRIMARY_HOVER, BG, FONT, INK, MUTED, SOFT_BLUE, SUBTLE, WHITE,
                    Action, RecordCard, pixels)


MOODS = ("开心", "平静", "焦虑", "难过", "生气", "疲惫")
MOOD_EMOJIS = ("😊", "😌", "😄", "🥰", "😎", "🤔", "😟", "😢", "😠", "😴", "😮", "🥳")
FIELD_BG = "#edf4fc"
BLUE = "#4d6589"
ROSE = "#925968"
REVIEW_FIELDS = ("gains", "improvements", "plan", "reward")
REVIEW_PRESETS = {"复盘": ("今日收获", "遗憾不足", "明日计划", "小奖励"),
                  "一日四分": ("凌晨", "上午", "下午", "夜晚")}
REVIEW_PAPER = "#fdfcf8"


class JournalPage:
    def __init__(self, parent, app, kind, *, compact=False):
        self.parent = parent
        self.app = app
        self.kind = kind
        self.compact = compact
        self.day = date.today()
        self.texts = {}
        self.moods = {}
        self.marked = set()
        self.emojis = set()
        self.pending = None
        self.loading = False
        self.status = tk.StringVar(parent)
        self.build_header()
        body = self.build_scroll_area()
        if kind == "mood":
            self.build_mood(body)
        else:
            self.build_review(body)
        self.load(app.store.journal(kind, self.day))

    def build_header(self):
        parent = self.parent
        header = tk.Frame(parent, bg=BG)
        header.pack(fill="x", pady=(0, pixels(parent, 12)))
        Action(header, "保存日记", self.save, BG, background=PRIMARY, foreground=ACCENT,
               hover=PRIMARY_HOVER, bold=True, height=39).pack(side="right", pady=(pixels(parent, 4), 0))
        title = "三栏情绪日记" if self.kind == "mood" else "四象限复盘日记"
        detail = "从发生的事，写到自己的感受和需求。" if self.kind == "mood" else "回看今天，也为明天留出一点方向。"
        tk.Label(header, text=title, bg=BG, fg=INK, font=(FONT, 21, "bold")).pack(anchor="w")
        tk.Label(header, text=detail, bg=BG, fg=MUTED, font=(FONT, 9)).pack(anchor="w")

        toolbar = tk.Frame(parent, bg=BG)
        toolbar.pack(fill="x", pady=(0, pixels(parent, 11)))
        if self.compact:
            tk.Label(toolbar, text=self.day.isoformat(), bg=BG, fg=ACCENT, font=(FONT, 10)).pack(side="left")
            tk.Label(toolbar, textvariable=self.status, bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="right")
            return
        for label, offset in (("‹", -1), ("›", 1)):
            Action(toolbar, label, lambda delta=offset: self.shift_day(delta),
                   BG, height=31, width=30).pack(side="left", padx=(0, pixels(parent, 4)))
        self.date_button = Action(toolbar, self.day.isoformat(), self.choose_date, BG,
                                  background=WHITE, foreground=ACCENT, height=31, width=108)
        self.date_button.pack(side="left", padx=(0, pixels(parent, 5)))
        Action(toolbar, "今天", lambda: self.select_date(date.today()), BG, height=31).pack(
            side="left", padx=(0, pixels(parent, 5)))
        self.history_button = Action(toolbar, "历史记录  ▾", self.open_history, BG, height=31)
        self.history_button.pack(side="left")
        self.history = tk.Menu(self.history_button, tearoff=False, font=(FONT, 10))
        tk.Label(toolbar, textvariable=self.status, bg=BG, fg=MUTED, font=(FONT, 8)).pack(side="right")

    def build_scroll_area(self):
        holder = tk.Frame(self.parent, bg=BG)
        holder.pack(fill="both", expand=True)
        canvas = tk.Canvas(holder, bg=BG, highlightthickness=0, yscrollincrement=pixels(holder, 14))
        scrollbar = ttk.Scrollbar(holder, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        body = tk.Frame(canvas, bg=BG)
        content = canvas.create_window(0, 0, window=body, anchor="nw")

        def resize(event=None):
            canvas.itemconfigure(content, width=canvas.winfo_width())
            canvas.configure(scrollregion=canvas.bbox("all"))
            if body.winfo_reqheight() > canvas.winfo_height():
                scrollbar.pack(side="right", fill="y", padx=(pixels(holder, 4), 0))
            else:
                scrollbar.pack_forget()

        canvas.bind("<Configure>", resize)
        body.bind("<Configure>", resize)
        canvas.bind("<MouseWheel>", lambda event: canvas.yview_scroll(-int(event.delta / 120) * 3, "units"))
        return body

    def card(self, parent, row, column, index, title, prompt, color, height):
        card = RecordCard(parent, height=height, auto_pack=False)
        card.grid(row=row, column=column, sticky="ew", padx=(0, pixels(parent, 8)),
                  pady=(0, pixels(parent, 8)))
        body = card.body
        heading = tk.Frame(body, bg=WHITE)
        heading.pack(fill="x", pady=(0, pixels(body, 3)))
        tk.Label(heading, text=f"{index:02d}", bg=WHITE, fg=color,
                 font=(FONT, 9, "bold")).pack(side="left", padx=(0, pixels(body, 7)))
        tk.Label(heading, text=title, bg=WHITE, fg=INK, font=(FONT, 13, "bold")).pack(side="left")
        question = tk.Label(body, text=prompt, bg=WHITE, fg=MUTED, font=(FONT, 9),
                            anchor="w", justify="left")
        question.pack(fill="x", pady=(0, pixels(body, 8)))
        body.bind("<Configure>", lambda event: question.configure(wraplength=max(1, event.width - 3)))
        return body

    def add_text(self, parent, field, background=FIELD_BG):
        editor = tk.Text(parent, width=1, height=1, bg=background, fg=INK,
                         font=(FONT, 10), wrap="word", undo=True, relief="flat", bd=0,
                         highlightthickness=0, insertbackground=ACCENT, selectbackground=SOFT_BLUE,
                         padx=pixels(parent, 7), pady=pixels(parent, 7), spacing3=pixels(parent, 3))
        editor.pack(fill="both", expand=True, pady=(0, pixels(parent, 3)))
        editor.bind("<<Modified>>", self.text_changed)
        self.texts[field] = editor

    def build_mood(self, body):
        for column in range(3):
            body.columnconfigure(column, weight=1, uniform="mood")
        facts = self.card(body, 0, 0, 1, "事实", "客观发生了什么？", BLUE, 326)
        feeling = self.card(body, 0, 1, 2, "感受", "标记自己的心情，也可以写下来。", ROSE, 326)
        needs = self.card(body, 0, 2, 3, "需求", "我真正需要什么？", ACCENT, 326)
        self.add_text(facts, "facts")
        chips = tk.Frame(feeling, bg=WHITE)
        chips.pack(fill="x", pady=(0, pixels(chips, 6)))
        for index, name in enumerate(MOODS):
            button = Action(chips, name, lambda mood=name: self.toggle_mood(mood),
                            WHITE, foreground=MUTED, height=26)
            button.grid(row=index // 2, column=index % 2, sticky="ew",
                        padx=(0, pixels(chips, 4)), pady=(0, pixels(chips, 4)))
            self.moods[name] = button
        emoji_row = tk.Frame(feeling, bg=WHITE)
        emoji_row.pack(fill="x", pady=(0, pixels(feeling, 4)))
        self.emoji_button = Action(emoji_row, "＋ 表情", self.open_emojis, WHITE, height=25,
                                   foreground=ACCENT, font_size=9)
        self.emoji_button.pack(side="left")
        self.emoji_text = tk.StringVar(emoji_row)
        tk.Label(emoji_row, textvariable=self.emoji_text, bg=WHITE, fg=INK,
                 font=("Segoe UI Emoji", 10), wraplength=pixels(emoji_row, 95)).pack(side="left", fill="x")
        self.emoji_menu = tk.Menu(self.emoji_button, tearoff=False, font=("Segoe UI Emoji", 13))
        self.emoji_values = {}
        for emoji in MOOD_EMOJIS:
            value = self.emoji_values[emoji] = tk.BooleanVar(emoji_row)
            self.emoji_menu.add_checkbutton(label=emoji, variable=value, command=lambda icon=emoji: self.toggle_emoji(icon))
        self.add_text(feeling, "feelings")
        self.add_text(needs, "needs")

    def build_review(self, body):
        toolbar = tk.Frame(body, bg=BG)
        toolbar.pack(fill="x", pady=(0, pixels(body, 7)))
        for name in REVIEW_PRESETS:
            Action(toolbar, name, lambda preset=name: self.apply_review_preset(preset), BG,
                   background=WHITE, foreground=ACCENT, height=30).pack(side="left", padx=(0, 5))
        tk.Label(toolbar, text="点击任一标题可修改", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        sheet = tk.Canvas(body, bg=REVIEW_PAPER, height=pixels(body, 355 if self.compact else 455),
                          highlightthickness=0)
        sheet.pack(fill="x")
        self.review_titles = []
        sections = []
        for field in REVIEW_FIELDS:
            section = tk.Frame(sheet, bg=REVIEW_PAPER)
            title = tk.StringVar(section)
            self.review_titles.append(title)
            tk.Entry(section, textvariable=title, bg=REVIEW_PAPER, fg=INK, font=(FONT, 13, "bold"),
                     bd=0, highlightthickness=0).pack(fill="x", pady=(0, pixels(body, 6)))
            title.trace_add("write", self.schedule_save)
            self.add_text(section, field, REVIEW_PAPER)
            sections.append(sheet.create_window(0, 0, window=section, anchor="nw"))
        self.review_date = tk.StringVar(sheet)
        badge = tk.Label(sheet, textvariable=self.review_date, bg=REVIEW_PAPER, fg=INK,
                         font=(FONT, 10, "bold"), relief="solid", bd=1, padx=7, pady=5)
        center = sheet.create_window(0, 0, window=badge)

        def draw(event):
            w, h = event.width, event.height
            step, margin = pixels(sheet, 17), pixels(sheet, 15)
            gap = pixels(sheet, 18)
            sheet.delete("paper")
            for x in range(0, w, step):
                sheet.create_line(x, 0, x, h, fill="#eeeae0", tags="paper")
            for y in range(0, h, step):
                sheet.create_line(0, y, w, y, fill="#eeeae0", tags="paper")
            sheet.create_line(w // 2, margin, w // 2, h - margin, fill=MUTED, width=2, tags="paper")
            sheet.create_line(margin, h // 2, w - margin, h // 2, fill=MUTED, width=2, tags="paper")
            sheet.tag_lower("paper")
            for index, item in enumerate(sections):
                sheet.coords(item, index % 2 * (w // 2) + margin, index // 2 * (h // 2) + gap)
                sheet.itemconfigure(item, width=max(1, w // 2 - 2 * margin),
                                    height=max(1, h // 2 - 2 * gap))
            sheet.coords(center, w // 2, h // 2)

        sheet.bind("<Configure>", draw)

    def apply_review_preset(self, name):
        for title, value in zip(self.review_titles, REVIEW_PRESETS[name]):
            title.set(value)

    def text_changed(self, event):
        if event.widget.edit_modified():
            event.widget.edit_modified(False)
            self.schedule_save()

    def draw_moods(self):
        for name, button in self.moods.items():
            active = name in self.marked
            button.update_style(name, SOFT_BLUE if active else SUBTLE, ACCENT if active else MUTED)

    def toggle_mood(self, mood):
        self.marked.symmetric_difference_update({mood})
        self.draw_moods()
        self.schedule_save()

    def open_emojis(self):
        button = self.emoji_button
        try:
            self.emoji_menu.tk_popup(button.winfo_rootx(), button.winfo_rooty() + button.winfo_height())
        finally:
            self.emoji_menu.grab_release()

    def draw_emojis(self):
        if self.kind == "mood":
            for emoji, value in self.emoji_values.items():
                value.set(emoji in self.emojis)
            self.emoji_text.set(" ".join(emoji for emoji in MOOD_EMOJIS if emoji in self.emojis))

    def toggle_emoji(self, emoji):
        self.emojis.symmetric_difference_update({emoji})
        self.draw_emojis()
        self.schedule_save()

    def schedule_save(self, *args):
        if self.loading:
            return
        if self.pending is not None:
            self.parent.after_cancel(self.pending)
        self.status.set("正在保存…")
        self.pending = self.parent.after(650, self.save)

    def contents(self):
        result = {field: editor.get("1.0", "end-1c") for field, editor in self.texts.items()}
        if self.kind == "mood":
            result["moods"] = [name for name in MOODS if name in self.marked]
            if self.emojis:
                result["emojis"] = [emoji for emoji in MOOD_EMOJIS if emoji in self.emojis]
        else:
            result["plan"] = result["plan"].split("\n")
            titles = tuple(title.get() for title in self.review_titles)
            if titles != REVIEW_PRESETS["复盘"]:
                result["titles"] = list(titles)
        return result

    def load(self, entry):
        self.loading = True
        contents = entry or {}
        for field, editor in self.texts.items():
            editor.delete("1.0", "end")
            value = contents.get(field, "")
            editor.insert("1.0", "\n".join(value) if isinstance(value, list) else value)
            editor.edit_reset()
            editor.edit_modified(False)
        self.marked = set(contents.get("moods", []))
        self.draw_moods()
        self.emojis = set(contents.get("emojis", [])) & set(MOOD_EMOJIS)
        self.draw_emojis()
        if self.kind == "review":
            self.apply_review_preset("复盘")
            for title, value in zip(self.review_titles, contents.get("titles", [])):
                title.set(value)
            self.review_date.set(self.day.strftime("%m / %d"))
        self.saved = self.contents()
        self.has_entry = entry is not None
        self.status.set("已保存到本机" if self.has_entry else "尚未记录")
        if not self.compact:
            self.date_button.update_style(self.day.isoformat(), WHITE, ACCENT)
        self.loading = False

    def save(self):
        if self.pending is not None:
            self.parent.after_cancel(self.pending)
            self.pending = None
        contents = self.contents()
        if contents != self.saved:
            try:
                self.has_entry = self.app.store.save_journal(self.kind, self.day, contents)
            except sqlite3.Error as error:
                self.status.set("保存失败")
                self.app.show_data_error(self.parent, error)
                return False
            self.saved = contents
        self.status.set("已保存到本机" if self.has_entry else "尚未记录")
        return True

    def select_date(self, day):
        if not self.save():
            return False
        try:
            entry = self.app.store.journal(self.kind, day)
        except sqlite3.Error as error:
            self.app.show_data_error(self.parent, error)
            return False
        self.day = day
        self.load(entry)
        return True

    def shift_day(self, days):
        ordinal = min(date.max.toordinal(), max(date.min.toordinal(), self.day.toordinal() + days))
        self.select_date(date.fromordinal(ordinal))

    def choose_date(self):
        value = simpledialog.askstring("选择日期", "请输入日期（年-月-日）",
                                       initialvalue=self.day.isoformat(), parent=self.parent)
        if value is not None:
            try:
                day = date.fromisoformat(value.strip())
            except ValueError:
                messagebox.showwarning("日期格式", "请按 YYYY-MM-DD 输入有效日期。", parent=self.parent)
                return
            self.select_date(day)

    def open_history(self):
        if not self.save():
            return
        self.history.delete(0, "end")
        days = self.app.store.journal_dates(self.kind)
        for day in days:
            self.history.add_command(label=day.isoformat(), command=lambda value=day: self.select_date(value))
        if not days:
            self.history.add_command(label="还没有记录", state="disabled")
        button = self.history_button
        self.history.tk_popup(button.winfo_rootx(), button.winfo_rooty() + button.winfo_height())
