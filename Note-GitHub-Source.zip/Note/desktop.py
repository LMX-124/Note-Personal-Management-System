import sqlite3
import tkinter as tk
from datetime import date
from io import BytesIO
from tkinter import ttk

from PIL import Image, ImageTk

from journal import JournalPage, REVIEW_FIELDS, REVIEW_PAPER, REVIEW_PRESETS
from ledger import LedgerWindow, ledger_totals, money
from note_preview import NOTE_COLORS, choose_note_picture, draw_note_tape
from palette import NEUTRAL, UNCATEGORIZED
from visual import (ACCENT, APP_NAME, BG, EDGE, FONT, INK, MUTED, PRIMARY, WHITE,
                    Action, CircleAction, FitLabel, category_tint, pixels, soft_rect)


MASK = "#ff00fe"
WIDTH = 342
ROW_HEIGHT = 36
COLLAPSED_ROWS = 3
EXPANDED_ROWS = 6
BURGUNDY = "#7c2843"
COUNT_BG = "#f8edf1"
NOTE_TEMPLATES = {"sticky": "彩色便签", "photo": "照片便签", "heart": "并排便签", "lined": "白底便签"}


class HeaderIcon(Action):
    def __init__(self, parent, label, command, surface=WHITE):
        super().__init__(parent, label, command, surface, background=surface, foreground=ACCENT,
                         height=28, width=28)

    def draw_label(self, width, height):
        x, y = width / 2, height / 2
        half = pixels(self, 7)
        ink = self.foreground
        if self.label == "＋":
            stroke = half * .22
            self.create_rectangle(x - half, y - stroke, x + half, y + stroke, fill=ink, outline="")
            self.create_rectangle(x - stroke, y - half, x + stroke, y + half, fill=ink, outline="")
        elif self.label == "···":
            radius = half * .28
            offset = half - radius
            for center in (x - offset, x, x + offset):
                self.create_oval(center - radius, y - radius, center + radius, y + radius,
                                 fill=ink, outline="")
        else:
            rise = half * .76 if self.label == "▾" else -half * .76
            self.create_polygon(x - half, y - rise, x + half, y - rise, x, y + rise, fill=ink)


class NoteTemplateTile(Action):
    def __init__(self, parent, kind, command):
        self.kind = kind
        super().__init__(parent, NOTE_TEMPLATES[kind], command, WHITE, background="#f6f8fb",
                         foreground=INK, width=109, height=76, font_size=9)

    def draw_label(self, width, height):
        scale = pixels(self, 10) / 10
        x = width / 2 - 24 * scale

        def box(left, top, right, bottom, fill=WHITE):
            self.create_rectangle(x + left * scale, top * scale, x + right * scale, bottom * scale,
                                  fill=fill, outline="#a9bacb")

        if self.kind == "sticky":
            for offset, (_, color) in zip((8, 4, 0), reversed(tuple(NOTE_COLORS.values()))):
                box(offset, 19 - offset, offset + 40, 47 - offset, color)
        else:
            box(0, 12, 48, 48)
            if self.kind == "photo":
                box(5, 16, 43, 35, "#dbeaff")
            elif self.kind == "heart":
                box(4, 20, 17, 40, "#dbeaff")
            else:
                draw_note_tape(self, x + 10 * scale, 8 * scale, 28 * scale, 10 * scale)
        self.create_text(width / 2, height - 13 * scale, text=self.label,
                         font=self.font, fill=self.foreground)


class TaskCard:
    def __init__(self, panel, task):
        task_id = task["id"]
        self.frame = tk.Frame(panel.rows, bg=WHITE, height=pixels(panel.rows, ROW_HEIGHT), padx=1)
        self.frame.pack(fill="x")
        self.frame.pack_propagate(False)
        self.complete = CircleAction(self.frame, False, lambda: panel.app.complete_task(task_id), size=28)
        self.complete.pack(side="left", padx=(0, pixels(self.frame, 3)))
        if task["due_at"]:
            self.deadline = tk.Label(self.frame, text=task["due_at"][5:16], font=(FONT, 8),
                                     fg="#000000", bg=WHITE)
            self.deadline.pack(side="right", padx=(pixels(self.frame, 3), 0))
            panel.bind_open("tasks", self.deadline)
        title = " ".join(task["title"].split())
        color = panel.colors.get(task["category"], NEUTRAL)
        band = self.highlight_title(title, color, category_tint(color))
        panel.bind_open("tasks", self.frame, band, self.title)
        panel.bind_task_drag(task_id, band, self.title)

    def highlight_title(self, title, color, tint):
        band = tk.Canvas(self.frame, width=1, height=pixels(self.frame, 24),
                         bg=WHITE, highlightthickness=0, bd=0)
        band.pack(side="left", fill="x", expand=True)
        self.title = FitLabel(band, title, (FONT, 9, "bold"), color, background=tint)
        inset = pixels(band, 5)
        label_item = band.create_window(inset, 0, anchor="w", window=self.title)
        preferred_width = self.title.measure_font.measure(title) + 2 * inset + 6

        def resize(event):
            width = min(event.width, preferred_width)
            if width <= 2 * inset:
                return
            band.delete("surface")
            soft_rect(band, 0, 1, width, event.height - 1, pixels(band, 6), tint)
            band.tag_lower("surface")
            band.coords(label_item, inset, event.height / 2)
            band.itemconfigure(label_item, width=width - 2 * inset)

        band.bind("<Configure>", resize)
        return band


class DesktopPanel:
    def __init__(self, app):
        self.app = app
        self.cards = {}
        self.signature = None
        self.expanded = False
        self.note_visible = False
        self.display_kind = "note"
        self.entries = []
        self.colors = {}
        self.drag_start = None
        self.drag_guide = None
        self.pending_save = None
        self.saved_note = ("", "", "lined", None)
        self.note_template = "lined"
        self.note_image = None
        self.note_thumbnail = None
        self.note_id = None
        self.reminders = {}
        self.window = tk.Toplevel(app.root, bg=MASK)
        self.window.title(f"{APP_NAME} · 桌面面板")
        self.window.overrideredirect(True)
        self.window.attributes("-transparentcolor", MASK)
        self.width = pixels(self.window, WIDTH)
        self.window.protocol("WM_DELETE_WINDOW", self.hide)
        self.pin = tk.BooleanVar(self.window, True)
        self.toggle_pin()
        self.position = (max(0, app.root.winfo_screenwidth() - self.width - pixels(self.window, 20)),
                         pixels(self.window, 90))
        self.height = 0
        self.window_drag = None
        self.scene = tk.Canvas(self.window, bg=MASK, borderwidth=0, highlightthickness=0)
        self.scene.pack(fill="both", expand=True)
        self.build_tasks()
        self.build_reminders()
        self.build_note()
        self.load_note()
        self.window.update_idletasks()

    def build_tasks(self):
        box = tk.Frame(self.scene, bg=WHITE)
        self.task_surface = self.scene.create_window(pixels(box, 20), pixels(box, 15), window=box, anchor="nw")
        top = tk.Frame(box, bg=WHITE)
        top.pack(fill="x", pady=(0, pixels(box, 5)))
        self.task_heading = tk.Label(top, text="待办事项", font=(FONT, 13, "bold"), fg=INK, bg=WHITE)
        self.task_heading.pack(side="left")
        controls = tk.Frame(top, bg=WHITE)
        controls.pack(side="right")
        self.menu_button = HeaderIcon(controls, "···", self.open_menu)
        self.menu_button.pack(side="left")
        self.quick_add = HeaderIcon(controls, "＋", self.open_quick_add)
        self.quick_add.pack(side="left", padx=(pixels(box, 3), 0))
        self.quick_menu = tk.Menu(self.quick_add, tearoff=False, font=(FONT, 10))
        for label, kind in (("本日便签", "notes"), ("三栏情绪日记", "mood"),
                            ("四象限日记", "review"), ("本日记账", "ledger")):
            self.quick_menu.add_command(label=label, command=lambda value=kind: self.quick_create(value))
        self.menu = tk.Menu(self.menu_button, tearoff=False, font=(FONT, 10))
        self.menu.add_command(label="打开管理窗口", command=self.app.show_main)
        self.menu.add_checkbutton(label="保持置顶", variable=self.pin, command=self.toggle_pin)
        self.menu.add_command(label="显示便签", command=self.toggle_note)
        self.note_menu_index = self.menu.index("end")
        self.menu.add_command(label="更改展示", command=lambda: self.open_display_menu(self.menu_button))
        self.menu.add_separator()
        self.menu.add_command(label="隐藏桌面组件", command=self.hide)
        self.menu.add_command(label=f"退出 {APP_NAME}", command=self.app.close)
        self.task_header = top
        self.task_list_body = tk.Frame(box, bg=WHITE)
        self.task_list_body.pack(fill="both", expand=True)
        self.count = tk.IntVar(box)
        rail = tk.Frame(self.task_list_body, bg=WHITE)
        rail.pack(side="left", padx=(0, pixels(box, 6)))
        self.counter = tk.Canvas(rail, bg=WHITE, width=pixels(box, 59),
                                 height=pixels(box, 53), highlightthickness=0, bd=0)
        self.counter.pack()
        task_buttons = tk.Frame(rail, bg=WHITE)
        task_buttons.pack()
        self.add_button = HeaderIcon(task_buttons, "＋", self.app.edit_task)
        self.add_button.pack(side="left")
        self.more = HeaderIcon(task_buttons, "▾", self.toggle_expanded)
        self.more.pack(side="left")
        self.counter.bind("<Configure>", self.draw_count)
        self.make_movable(top, self.task_heading, self.counter)
        self.bind_open("tasks", box, top, self.task_heading, self.counter)
        self.task_area = tk.Frame(self.task_list_body, bg=WHITE)
        self.task_area.pack(side="left", fill="both", expand=True)
        self.canvas = tk.Canvas(self.task_area, bg=WHITE, highlightthickness=0, borderwidth=0,
                                yscrollincrement=pixels(self.task_area, 12))
        self.scroll = ttk.Scrollbar(self.task_area, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.rows = tk.Frame(self.canvas, bg=WHITE)
        frame_id = self.canvas.create_window(0, 0, window=self.rows, anchor="nw")
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(frame_id, width=event.width))
        self.rows.bind("<Configure>", lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.window.bind("<MouseWheel>", self.wheel)

    def draw_count(self, event=None):
        width, height = self.counter.winfo_width(), self.counter.winfo_height()
        if min(width, height) < 8:
            return
        self.counter.delete("all")
        badge_height = min(height, pixels(self.counter, 64))
        top = 0 if self.expanded else (height - badge_height) / 2
        radius = min(pixels(self.counter, 12), badge_height / 3)
        soft_rect(self.counter, 0, top, width, top + badge_height, radius, COUNT_BG)
        total = str(self.count.get())
        size = min(31, max(8, 76 // len(total)))
        self.counter.create_text(width / 2, top + badge_height / 2, text=total,
                                 fill=BURGUNDY, font=(FONT, size, "bold"))

    def build_reminders(self):
        self.reminder_box = tk.Frame(self.scene, bg=WHITE, padx=pixels(self.scene, 10),
                                     pady=pixels(self.scene, 5), highlightthickness=1,
                                     highlightbackground="#b6cee8")
        self.reminder_surface = self.scene.create_window(0, 0, window=self.reminder_box,
                                                         anchor="nw", state="hidden")

    def show_reminders(self, tasks):
        self.reminders.update((row["id"], row) for row in tasks)
        self.draw_reminders()
        self.window.deiconify()
        self.window.lift()
        self.window.bell()

    def dismiss_reminder(self, task_id):
        self.reminders.pop(task_id, None)
        self.draw_reminders()

    def draw_reminders(self):
        for child in self.reminder_box.winfo_children():
            child.destroy()
        colors = self.app.store.category_colors()
        for task_id, task in self.reminders.items():
            row = tk.Frame(self.reminder_box, bg=WHITE, cursor="hand2")
            row.pack(fill="x", pady=pixels(row, 3))
            color = colors.get(task["category"], NEUTRAL)
            category = tk.Label(row, text=task["category"], font=(FONT, 8), fg=color,
                                bg=category_tint(color), padx=pixels(row, 5),
                                wraplength=pixels(row, 75), cursor="hand2")
            category.pack(side="right", padx=(pixels(row, 8), 0))
            title = FitLabel(row, task["title"], (FONT, 10, "bold"), INK)
            title.configure(cursor="hand2")
            title.pack(side="left", fill="x", expand=True)
            for control in (row, category, title):
                control.bind("<Button-1>", lambda event, item=task_id: self.dismiss_reminder(item))
        self.reminder_box.update_idletasks()
        limit = EXPANDED_ROWS if self.expanded else COLLAPSED_ROWS
        self.layout_surfaces(min(len(self.entries), limit))

    def build_note(self):
        box = tk.Frame(self.scene, bg=WHITE)
        self.note_surface = self.scene.create_window(pixels(box, 29), 0, window=box, anchor="nw", state="hidden")
        top = self.note_topbar = tk.Frame(box, bg=WHITE)
        top.pack(fill="x")
        self.display_title = tk.StringVar(top, "便签")
        label = tk.Label(top, textvariable=self.display_title, font=(FONT, 12, "bold"), fg=INK, bg=WHITE)
        label.pack(side="left")
        self.note_add = HeaderIcon(top, "＋", self.open_note_templates, WHITE)
        self.note_add.pack(side="right")
        self.change_display = Action(top, "更改", lambda: self.open_display_menu(self.change_display),
                                     WHITE, foreground=ACCENT, height=27)
        self.change_display.pack(side="right", padx=(0, pixels(box, 3)))
        self.note_picker = None
        self.note_category = UNCATEGORIZED
        self.note_card = tk.Frame(box, bg=WHITE, highlightthickness=1, highlightbackground=EDGE,
                                  padx=pixels(box, 8), pady=pixels(box, 5))
        self.note_card.pack(fill="both", expand=True)
        self.note_card.columnconfigure(1, weight=1)
        tape_width, tape_height = pixels(box, 54), pixels(box, 22)
        self.note_tape = tk.Canvas(box, bg=WHITE, width=tape_width, height=tape_height,
                                   bd=0, highlightthickness=0)
        self.note_tape.create_line(0, tape_height / 2, tape_width, tape_height / 2, fill=EDGE)
        draw_note_tape(self.note_tape, 1, 1, tape_width - 2, tape_height - 2)
        self.note_title = tk.StringVar(box)
        self.note_heading = tk.Entry(self.note_card, textvariable=self.note_title, fg="#000000", bg=WHITE,
                                     bd=0, highlightthickness=0, font=(FONT, 11, "bold"), width=18)
        self.note_heading.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(pixels(box, 3), 0))
        self.note_title_hint = tk.Label(self.note_heading, text="输入标题", bg=WHITE, fg=MUTED,
                                        font=(FONT, 11, "bold"), bd=0, padx=0, pady=0, cursor="xterm")
        self.note_title_hint.bind("<Button-1>", lambda event: self.note_heading.focus_force())
        self.note_heading.bind("<FocusIn>", self.update_note_title_hint)
        self.note_heading.bind("<Button-1>", lambda event: event.widget.focus_force())
        self.note_heading.bind("<Return>", self.focus_note_body)
        self.note_heading.bind("<KP_Enter>", self.focus_note_body)
        self.note_heading.bind("<FocusOut>", lambda event: self.flush_note())
        self.note_heading.bind("<FocusOut>", self.update_note_title_hint, add="+")
        self.note_photo = tk.Canvas(self.note_card, bg="#dceaf9", highlightthickness=1,
                                    highlightbackground="#b6cee8", cursor="hand2")
        self.note_photo.bind("<ButtonRelease-1>", self.choose_note_image)
        self.make_movable(top, label)
        self.note_body = tk.Text(self.note_card, width=20, height=3, wrap="word", undo=True, relief="flat",
                                 highlightthickness=0, bg=WHITE, fg=INK,
                                 insertbackground=ACCENT, selectbackground=PRIMARY,
                                 font=(FONT, 10), pady=pixels(box, 3), spacing3=pixels(box, 3))
        self.note_body.bind("<<Modified>>", self.note_changed)
        self.note_body.bind("<Button-1>", lambda event: event.widget.focus_force())
        self.note_body.bind("<FocusOut>", lambda event: self.flush_note())
        self.note_status = tk.StringVar(box)
        self.note_title.trace_add("write", self.note_title_changed)
        self.note_footer = tk.Label(box, textvariable=self.note_status, fg=MUTED, bg=WHITE,
                                    font=(FONT, 8))
        self.note_footer.pack(side="bottom", anchor="w", pady=(pixels(box, 3), 0))
        self.summary_card = tk.Frame(box, bg=WHITE, highlightbackground=EDGE, highlightthickness=1,
                                     padx=pixels(box, 9), pady=pixels(box, 7))
        self.summary_content = tk.Frame(self.summary_card, bg=WHITE)
        self.summary_content.pack(fill="x")
        self.summary_signature = None
        Action(self.summary_card, "打开详情", self.open_summary, WHITE,
               background=WHITE, foreground=ACCENT, height=27).pack(anchor="w")
        self.bind_open("notes", self.note_body, self.note_footer)

    def bind_open(self, page, *controls):
        for control in controls:
            control.bind("<Double-Button-1>", lambda event: self.open_page(page))

    def bind_task_drag(self, task_id, *controls):
        for control in controls:
            control.configure(cursor="fleur")
            control.bind("<ButtonPress-1>", lambda event: self.begin_task_drag(task_id, event))
            control.bind("<B1-Motion>", self.move_task_drag)
            control.bind("<ButtonRelease-1>", self.finish_task_drag)

    def begin_task_drag(self, task_id, event):
        self.drag_start = (task_id, event.y_root)

    def task_drop_slot(self, y):
        for task_id, card in self.cards.items():
            row = card.frame
            if y < row.winfo_rooty() + row.winfo_height() / 2:
                return task_id, row.winfo_y()
        last = next(reversed(self.cards.values())).frame
        count = len(self.cards)
        next_id = self.entries[count]["id"] if count < len(self.entries) else None
        return next_id, last.winfo_y() + last.winfo_height()

    def move_task_drag(self, event):
        if self.drag_start is None:
            return
        if self.drag_guide is None:
            if abs(event.y_root - self.drag_start[1]) < pixels(self.canvas, 5):
                return
            self.drag_guide = tk.Frame(self.rows, bg=ACCENT)
        margin = pixels(self.canvas, 12)
        top = self.canvas.winfo_rooty()
        if self.scroll.winfo_ismapped():
            if event.y_root < top + margin:
                self.canvas.yview_scroll(-1, "units")
            elif event.y_root > top + self.canvas.winfo_height() - margin:
                self.canvas.yview_scroll(1, "units")
        _, guide_y = self.task_drop_slot(event.y_root)
        thickness = pixels(self.rows, 2)
        self.drag_guide.place(x=0, y=max(0, guide_y - thickness), relwidth=1, height=thickness)
        self.drag_guide.lift()

    def finish_task_drag(self, event):
        start, self.drag_start = self.drag_start, None
        if self.drag_guide is None:
            return
        self.drag_guide.destroy()
        self.drag_guide = None
        x, y = self.canvas.winfo_rootx(), self.canvas.winfo_rooty()
        if (x <= event.x_root < x + self.canvas.winfo_width()
                and y <= event.y_root < y + self.canvas.winfo_height()):
            before_id, _ = self.task_drop_slot(event.y_root)
            try:
                self.app.store.move_desktop_task(start[0], before_id)
            except sqlite3.Error as error:
                self.app.show_data_error(self.window, error)
        self.app.refresh_tasks()

    def open_page(self, page):
        if self.flush_note():
            self.app.show_main(page)
        return "break"

    def make_movable(self, *controls):
        for control in controls:
            control.configure(cursor="fleur")
            control.bind("<ButtonPress-1>", self.grab_panel)
            control.bind("<B1-Motion>", self.move_panel)
            control.bind("<ButtonRelease-1>", self.release_panel)

    def grab_panel(self, event):
        self.window_drag = (event.x_root - self.position[0], event.y_root - self.position[1])

    def move_panel(self, event):
        if self.window_drag is not None:
            dx, dy = self.window_drag
            self.set_geometry(event.x_root - dx, event.y_root - dy)

    def release_panel(self, event):
        self.window_drag = None

    def set_geometry(self, x, y):
        x = min(max(0, x), max(0, self.window.winfo_screenwidth() - self.width))
        y = min(max(0, y), max(0, self.window.winfo_screenheight() - self.height - pixels(self.window, 44)))
        self.position = (x, y)
        self.window.geometry(f"{self.width}x{self.height}+{x}+{y}")

    def open_menu(self):
        button = self.menu_button
        self.menu.entryconfigure(self.note_menu_index, label="隐藏展示" if self.note_visible else "显示便签")
        self.menu.tk_popup(button.winfo_rootx(), button.winfo_rooty() + button.winfo_height())

    def toggle_note(self):
        if self.note_picker is not None:
            self.close_note_picker()
            return
        if not self.flush_note():
            return
        self.note_visible = not self.note_visible
        if self.note_visible:
            self.set_display_kind("note")
            self.expanded = False
            self.load_note()
            self.render_tasks(self.entries, self.colors)
        else:
            self.layout_surfaces(len(self.cards))
        self.app.refresh_notes()

    def open_display_menu(self, button):
        if hasattr(self, "display_menu"):
            self.display_menu.destroy()
        menu = self.display_menu = tk.Menu(button, tearoff=False, font=(FONT, 10))
        notes = tk.Menu(menu, tearoff=False, font=(FONT, 10))
        for row in self.app.store.notes():
            label = " ".join(row["title"].split()) or "无标题便签"
            notes.add_command(label=label[:30], command=lambda note_id=row["id"]: self.select_note(note_id))
        if notes.index("end") is None:
            notes.add_command(label="便签库还是空的", state="disabled")
        menu.add_cascade(label="选择便签", menu=notes)
        menu.add_command(label="今日账单", command=lambda: self.show_summary("ledger"))
        diaries = tk.Menu(menu, tearoff=False, font=(FONT, 10))
        for label, kind in (("三栏情绪日记", "mood"), ("四象限日记", "review")):
            diaries.add_command(label=label, command=lambda value=kind: self.show_summary(value))
        menu.add_cascade(label="今日日记", menu=diaries)
        try:
            menu.tk_popup(button.winfo_rootx(), button.winfo_rooty() + button.winfo_height())
        finally:
            menu.grab_release()

    def show_summary(self, kind):
        if not self.flush_note():
            return
        self.close_note_picker()
        self.note_visible = True
        self.set_display_kind(kind)
        if self.expanded:
            self.toggle_expanded()
        self.refresh_summary()
        self.layout_surfaces(len(self.cards))
        self.app.refresh_notes()

    def set_display_kind(self, kind):
        self.display_kind = kind
        title = {"note": "便签", "ledger": "今日账单", "mood": "今日情绪日记", "review": "今日四象限日记"}
        self.display_title.set(title[kind])
        self.note_card.pack_forget()
        self.summary_card.pack_forget()
        self.note_footer.pack_forget()
        self.note_add.pack_forget()
        if kind == "note":
            self.note_add.pack(side="right", before=self.change_display)
            self.note_card.pack(fill="both", expand=True)
            self.note_footer.pack(side="bottom", anchor="w", pady=(pixels(self.note_footer, 3), 0))
        else:
            self.summary_card.pack(fill="both", expand=True)

    def refresh_summary(self):
        kind = self.display_kind
        if kind == "note" or not self.note_visible:
            return
        day = date.today()
        if kind == "ledger":
            data = [dict(row) for row in self.app.store.ledger_entries(day)]
        else:
            data = self.app.store.journal(kind, day) or {}
        signature = (kind, day, data)
        if self.summary_signature == signature:
            return
        self.summary_signature = signature
        for child in self.summary_content.winfo_children():
            child.destroy()
        if kind == "ledger":
            self.draw_ledger_summary(data)
        else:
            self.draw_journal_summary(kind, day, data)
        self.summary_content.update_idletasks()
        self.layout_surfaces(len(self.cards))

    def draw_ledger_summary(self, entries):
        parent = self.summary_content
        totals = tk.Frame(parent, bg=WHITE)
        totals.pack(fill="x", pady=(0, pixels(parent, 6)))
        income, expense = ledger_totals(entries)
        totals.columnconfigure((0, 1, 2), weight=1, uniform="amount")
        for col, (title, value, color) in enumerate((
                ("收入", income, "#267254"), ("支出", expense, "#a34d41"), ("结余", income - expense, ACCENT))):
            tile = tk.Frame(totals, bg="#f0f5fc", pady=pixels(parent, 4))
            tile.grid(row=0, column=col, sticky="ew", padx=2)
            tk.Label(tile, text=title, bg="#f0f5fc", fg=MUTED, font=(FONT, 8)).pack()
            value_text = money(value)
            tk.Label(tile, text=value_text, bg="#f0f5fc", fg=color,
                     font=(FONT, 10 if len(value_text) < 10 else 8, "bold")).pack()
        tk.Label(parent, text=f"今日明细 · {len(entries)} 笔", bg=WHITE, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w")
        for row in reversed(entries[-3:]):
            line = tk.Frame(parent, bg=WHITE)
            line.pack(fill="x")
            label = " ".join((row["memo"] or row["category"] or ("收入" if row["kind"] == "income" else "支出")).split())
            positive = row["kind"] == "income"
            amount = ("+" if positive else "−") + money(row["cents"])
            tk.Label(line, text=amount, bg=WHITE, fg="#267254" if positive else "#a34d41",
                     font=(FONT, 9, "bold")).pack(side="right")
            FitLabel(line, "•  " + label, (FONT, 9), INK).pack(side="left", fill="x", expand=True)

    def draw_journal_summary(self, kind, day, entry):
        parent = self.summary_content
        review = kind == "review"
        paper = REVIEW_PAPER if review else "#eff5fd"
        columns, rows = (2, 2) if review else (3, 1)
        sheet = tk.Canvas(parent, bg=paper, highlightthickness=0, bd=0,
                          width=pixels(parent, 240), height=pixels(parent, 144 if review else 101))
        sheet.pack(fill="x")
        fields = REVIEW_FIELDS if review else ("facts", "feelings", "needs")
        titles = (entry.get("titles") or REVIEW_PRESETS["复盘"]) if review else ("事实", "感受", "需求")

        def draw(event):
            sheet.delete("all")
            width, height = event.width, event.height
            cell_width, cell_height = width / columns, height / rows
            if review:
                step = pixels(parent, 12)
                for x in range(step, width, step):
                    sheet.create_line(x, 0, x, height, fill="#eee9dc")
                for y in range(step, height, step):
                    sheet.create_line(0, y, width, y, fill="#eee9dc")
                sheet.create_line(0, cell_height, width, cell_height, fill=MUTED)
            for col in range(1, columns):
                sheet.create_line(col * cell_width, 0, col * cell_width, height, fill=MUTED if review else EDGE)
            inset = pixels(parent, 6)
            for i, (field, title) in enumerate(zip(fields, titles)):
                x = i % columns * cell_width + inset
                row = i // columns
                y = row * cell_height + inset + (pixels(parent, 7) if row else 0)
                sheet.create_text(x, y, text=title[:8], anchor="nw", fill=INK, font=(FONT, 8, "bold"))
                value = entry.get(field, "")
                lines = value if isinstance(value, list) else value.splitlines()
                if field == "feelings" and entry.get("moods"):
                    lines = ["、".join(entry["moods"]), *lines]
                emoji = entry.get("emojis", []) if field == "feelings" else []
                offset = pixels(parent, 17)
                if emoji:
                    sheet.create_text(x, y + offset, text=" ".join(emoji[:3]) + ("…" if len(emoji) > 3 else ""),
                                      anchor="nw", fill=INK, font=("Segoe UI Emoji", 9))
                    offset += pixels(parent, 18)
                bullets = "\n".join("• " + item.strip()[:(11 if review else 7)]
                                    for item in [item for item in lines if item.strip()][:2])
                sheet.create_text(x, y + offset, text=bullets, anchor="nw", fill=INK,
                                  width=max(1, cell_width - 2 * inset), font=(FONT, 8))
            if review:
                x, y = width / 2, height / 2
                w, h = pixels(parent, 23), pixels(parent, 9)
                sheet.create_rectangle(x-w, y-h, x+w, y+h, fill=paper, outline=MUTED)
                sheet.create_text(x, y, text=day.strftime("%m/%d"), fill=INK, font=(FONT, 8, "bold"))

        sheet.bind("<Configure>", draw)

    def open_summary(self):
        if self.display_kind == "ledger":
            self.app.workspace.calendar.open_ledger(date.today())
        else:
            self.open_quick_journal(self.display_kind)

    def open_quick_add(self):
        button = self.quick_add
        self.quick_menu.tk_popup(button.winfo_rootx(), button.winfo_rooty() + button.winfo_height())

    def quick_create(self, kind):
        day = date.today()
        if kind == "notes":
            return self.open_note_templates()
        if kind == "ledger":
            ledger = LedgerWindow(self.app, day, self.refresh_quick_ledger)
            ledger.window.attributes("-topmost", self.pin.get())
            return ledger
        return self.open_quick_journal(kind)

    def refresh_quick_ledger(self):
        workspace = self.app.workspace
        workspace.ledger.refresh()
        if workspace.active_page == "calendar":
            workspace.calendar.refresh()

    def open_quick_journal(self, kind):
        workspace = self.app.workspace
        original = workspace.journals[kind]
        if not original.save():
            return
        window = tk.Toplevel(self.app.root, bg=BG)
        window.attributes("-topmost", self.pin.get())
        window.title("三栏情绪日记" if kind == "mood" else "四象限复盘日记")
        window.minsize(pixels(window, 620), pixels(window, 480))
        panel = tk.Frame(window, bg=BG, padx=pixels(window, 16), pady=pixels(window, 12))
        panel.pack(fill="both", expand=True)
        page = JournalPage(panel, self.app, kind, compact=True)

        def close():
            if not page.save():
                return
            if original.day == page.day:
                original.load(self.app.store.journal(kind, page.day))
            if workspace.active_page == "calendar":
                workspace.calendar.refresh()
            window.destroy()

        window.protocol("WM_DELETE_WINDOW", close)
        window.bind("<Escape>", lambda event: close())
        first = next(iter(page.texts.values()))

        def focus_editor(event):
            if event.widget == window:
                window.grab_set()
                first.focus_set()

        window.bind("<Map>", focus_editor)
        return page

    def layout_surfaces(self, count):
        def px(amount):
            return pixels(self.scene, amount)

        body_height = max(min(count, EXPANDED_ROWS) * px(ROW_HEIGHT), px(82))
        task_height = self.task_header.winfo_reqheight() + px(5) + body_height
        self.more.update_style("▴" if self.expanded else "▾", WHITE, ACCENT)
        task_bottom = task_height + px(24)
        content_bottom = task_bottom
        self.scene.itemconfigure(self.reminder_surface, state="normal" if self.reminders else "hidden")
        if self.reminders:
            reminder_top = task_bottom + px(12)
            reminder_height = self.reminder_box.winfo_reqheight()
            self.scene.coords(self.reminder_surface, px(17), reminder_top)
            self.scene.itemconfigure(self.reminder_surface, width=self.width - px(34), height=reminder_height)
            content_bottom = reminder_top + reminder_height
        note_top = content_bottom + px(12)
        if self.note_picker is not None:
            parts = (self.note_picker,)
        else:
            parts = (self.note_card, self.note_footer) if self.display_kind == "note" else (self.summary_card,)
        note_height = self.note_topbar.winfo_reqheight() + sum(widget.winfo_reqheight() for widget in parts)
        note_height += px(25)
        show_note = (self.note_visible or self.note_picker is not None) and not self.expanded
        self.height = note_top + note_height + px(16) if show_note else content_bottom + px(10)
        self.set_geometry(*self.position)
        self.scene.delete("surface")
        right = self.width
        soft_rect(self.scene, px(7), px(8), right - px(5), task_bottom + px(4), px(20), "#cad7e5")
        soft_rect(self.scene, px(5), px(5), right - px(7), task_bottom + px(1), px(20), EDGE)
        soft_rect(self.scene, px(6), px(6), right - px(8), task_bottom, px(19), WHITE)
        self.scene.itemconfigure(self.note_surface, state="normal" if show_note else "hidden")
        if show_note:
            soft_rect(self.scene, px(26), note_top + px(9), right - px(13),
                      note_top + note_height + px(11), px(17), "#d2dce7")
            soft_rect(self.scene, px(25), note_top + px(7), right - px(15),
                      note_top + note_height + px(8), px(17), "#f6f8fb")
            soft_rect(self.scene, px(16), note_top, right - px(24), note_top + note_height, px(17), EDGE)
            soft_rect(self.scene, px(17), note_top + px(1), right - px(25),
                      note_top + note_height - px(1), px(16), WHITE)
            self.scene.coords(self.note_surface, px(29), note_top + px(8))
            self.scene.itemconfigure(self.note_surface, width=self.width - px(66), height=note_height - px(17))
        self.scene.tag_lower("surface")
        self.scene.itemconfigure(self.task_surface, width=self.width - px(41), height=task_height)
        if count > EXPANDED_ROWS:
            self.scroll.pack(side="right", fill="y", before=self.canvas)
        else:
            self.scroll.pack_forget()
            self.canvas.yview_moveto(0)

    def toggle_pin(self):
        self.window.attributes("-topmost", self.pin.get())

    def hide(self):
        if self.flush_note():
            if self.app.root.state() == "withdrawn":
                self.app.show_main()
            self.window.withdraw()

    def wheel(self, event):
        x, y = self.canvas.winfo_rootx(), self.canvas.winfo_rooty()
        if x <= event.x_root < x + self.canvas.winfo_width() and y <= event.y_root < y + self.canvas.winfo_height():
            self.canvas.yview_scroll(-int(event.delta / 120), "units")
            return "break"

    def toggle_expanded(self):
        if not self.expanded and not self.flush_note():
            return
        self.expanded = not self.expanded
        self.canvas.yview_moveto(0)
        self.render_tasks(self.entries, self.colors)

    def render_tasks(self, tasks, colors):
        if self.drag_start is not None:
            return
        self.entries = tasks
        self.colors = colors
        visible = tasks if self.expanded else tasks[:COLLAPSED_ROWS]
        signature = (self.expanded, len(tasks),
                     [(tuple(row), colors.get(row["category"])) for row in visible])
        if signature == self.signature:
            return
        self.signature = signature
        self.count.set(len(tasks))
        self.layout_surfaces(len(visible))
        self.draw_count()
        for item in self.rows.winfo_children():
            item.destroy()
        self.cards = {row["id"]: TaskCard(self, row) for row in visible}
        if not tasks:
            empty = tk.Label(self.rows, text="清单还是空的", bg=WHITE, fg=MUTED,
                             font=(FONT, 9), anchor="w", padx=7, pady=6)
            empty.pack(fill="x")
            self.bind_open("tasks", empty)

    def reveal_task(self, task_id):
        self.window.update_idletasks()
        card = self.cards.get(task_id)
        if card and self.rows.winfo_height() > self.canvas.winfo_height():
            y = card.frame.winfo_y()
            top = self.canvas.canvasy(0)
            if y < top or y + card.frame.winfo_height() > top + self.canvas.winfo_height():
                self.canvas.yview_moveto(y / self.rows.winfo_height())

    def note_changed(self, event):
        if not self.note_body.edit_modified():
            return
        self.note_body.edit_modified(False)
        self.schedule_note_save()

    def focus_note_body(self, event):
        self.note_body.focus_force()
        return "break"

    def note_title_changed(self, *args):
        self.update_note_title_hint()
        if self.note_title.get() != self.saved_note[0]:
            self.schedule_note_save()

    def update_note_title_hint(self, event=None):
        if not self.note_title.get() and self.note_heading.focus_get() != self.note_heading:
            self.note_title_hint.place(x=1, rely=.5, anchor="w")
        else:
            self.note_title_hint.place_forget()

    def schedule_note_save(self, event=None):
        if self.pending_save is not None:
            self.window.after_cancel(self.pending_save)
        self.note_status.set("正在保存…")
        self.pending_save = self.window.after(450, self.flush_note)

    def update_note_header(self, note):
        self.note_id = note["id"] if note else None
        self.note_status.set(f"保存于 {note['updated_at'][:16]}" if note else "输入后自动保存到本地")

    def load_note(self):
        note = self.app.store.desktop_note()
        self.note_category = note["category"] if note else UNCATEGORIZED
        self.saved_note = (note["title"], note["body"], note["template"], note["image"]) if note else ("", "", "lined", None)
        title, body, self.note_template, self.note_image = self.saved_note
        self.note_title.set(title)
        self.note_body.delete("1.0", "end")
        self.note_body.insert("1.0", body)
        self.note_body.edit_reset()
        self.note_body.edit_modified(False)
        self.update_note_header(note)
        self.render_note_template()

    def render_note_template(self):
        photo = self.note_template == "photo"
        heart = self.note_template == "heart"
        color = NOTE_COLORS.get(self.note_template, ("", WHITE))[1]
        for widget in (self.note_card, self.note_heading, self.note_body, self.note_title_hint):
            widget.configure(bg=color)
        self.update_note_title_hint()
        self.note_card.configure(highlightthickness=0 if heart else 1, highlightcolor=EDGE)
        self.note_card.rowconfigure(3, weight=1)
        self.note_heading.configure(width=18)
        self.note_heading.grid(row=2 if photo or heart else 1, column=int(heart),
                               columnspan=1 if heart else 2, sticky="ew", padx=0)
        self.note_tape.place_forget()
        self.note_card.rowconfigure(0, minsize=0)
        self.note_photo.grid_remove()
        if self.note_template == "lined":
            self.note_card.rowconfigure(0, minsize=pixels(self.note_card, 13))
            self.note_tape.place(in_=self.note_card, relx=.5, anchor="center", bordermode="outside")
        if photo or heart:
            width = pixels(self.note_card, 246 if photo else 70)
            height = pixels(self.note_card, 91 if photo else 70)
            self.note_photo.configure(width=width, height=height, bg="#f6f8fb" if photo else WHITE,
                                      highlightcolor="#b6cee8")
            self.note_photo.grid(row=1 if photo else 2, rowspan=1 if photo else 2,
                                 column=0, columnspan=2 if photo else 1,
                                 sticky="nw" if heart else "", padx=(0, pixels(self.note_card, 7) if heart else 0),
                                 pady=(pixels(self.note_card, 6) if heart else 0, pixels(self.note_card, 4)))
            self.note_photo.delete("all")
            self.note_thumbnail = None
            if self.note_image:
                with Image.open(BytesIO(self.note_image)) as image:
                    image.thumbnail((width, height), Image.Resampling.LANCZOS)
                    self.note_thumbnail = ImageTk.PhotoImage(image, master=self.window)
                self.note_photo.create_image(width / 2, height / 2, image=self.note_thumbnail)
            else:
                self.note_photo.create_text(width / 2, height / 2, text="♡" if heart else "＋  添加图片",
                                            fill=ACCENT, font=(FONT, 19 if heart else 9))
        self.note_body.configure(height=2 if photo else 3, width=10 if heart else 20,
                                 pady=0 if heart else pixels(self.note_card, 3))
        self.note_body.grid(row=3, column=int(heart), columnspan=1 if heart else 2, sticky="nsew")
        if self.height:
            self.note_card.update_idletasks()
            limit = EXPANDED_ROWS if self.expanded else COLLAPSED_ROWS
            self.layout_surfaces(min(len(self.entries), limit))

    def choose_note_image(self, event=None):
        try:
            picture = choose_note_picture(self.window)
        except (OSError, ValueError, Image.DecompressionBombError) as error:
            self.app.show_data_error(self.window, error)
            return
        if picture is None:
            return
        self.note_image = picture
        self.render_note_template()
        self.flush_note()

    def select_note(self, note_id):
        if not self.flush_note():
            return False
        self.close_note_picker()
        try:
            self.app.store.set_desktop_note(note_id)
        except sqlite3.Error as error:
            self.app.show_data_error(self.window, error)
            return False
        self.note_visible = True
        self.set_display_kind("note")
        if self.expanded:
            self.toggle_expanded()
        self.load_note()
        self.app.refresh_notes()
        return True

    def open_note_templates(self):
        if self.note_picker is not None:
            return self.note_picker
        if not self.flush_note():
            return None
        if self.expanded:
            self.toggle_expanded()
        picker = self.note_picker = tk.Frame(self.note_topbar.master, bg=WHITE, padx=8, pady=8)
        self.note_card.pack_forget()
        self.note_footer.pack_forget()
        self.summary_card.pack_forget()
        self.note_add.pack_forget()
        self.change_display.pack_forget()
        picker.pack(fill="both", expand=True)
        self.display_title.set("新建便签")
        self.new_note_category = tk.StringVar(picker, UNCATEGORIZED)
        self.show_note_categories()
        return picker

    def show_note_categories(self):
        picker = self.note_picker
        for child in picker.winfo_children():
            child.destroy()
        tk.Label(picker, text="先选择便签分类", bg=WHITE, fg=INK, font=(FONT, 11, "bold")).pack(anchor="w")
        categories = tuple(dict.fromkeys((UNCATEGORIZED, *self.app.store.categories())))
        ttk.Combobox(picker, textvariable=self.new_note_category, values=categories,
                     state="readonly", width=22).pack(fill="x", pady=6)
        Action(picker, "下一步 · 选择款式", self.show_note_styles, WHITE,
               background=PRIMARY, foreground=ACCENT).pack(fill="x")
        Action(picker, "取消", self.close_note_picker, WHITE).pack(anchor="e", pady=(4, 0))
        self.resize_note_picker()

    def show_note_styles(self):
        picker = self.note_picker
        for child in picker.winfo_children():
            child.destroy()
        self.note_choices = []
        picker.columnconfigure((0, 1), weight=1, uniform="templates")
        for index, kind in enumerate(NOTE_TEMPLATES):
            command = self.toggle_note_colors if kind == "sticky" else lambda value=kind: self.pick_note_template(value)
            tile = NoteTemplateTile(picker, kind, command)
            tile.grid(row=index // 2, column=index % 2, padx=3, pady=3)
            self.note_choices.append(tile)
        self.note_colors = tk.Frame(picker, bg=WHITE)
        for key, (name, color) in NOTE_COLORS.items():
            Action(self.note_colors, name, lambda value=key: self.pick_note_template(value), WHITE,
                   background=color, width=68, bold=True).pack(side="left", padx=3)
        Action(picker, "返回分类", self.show_note_categories, WHITE).grid(row=3, column=0, pady=(4, 0))
        Action(picker, "取消", self.close_note_picker, WHITE).grid(row=3, column=1, pady=(4, 0))
        self.resize_note_picker()

    def resize_note_picker(self):
        self.note_picker.update_idletasks()
        self.layout_surfaces(len(self.cards))

    def toggle_note_colors(self):
        if self.note_colors.winfo_manager():
            self.note_colors.grid_remove()
        else:
            self.note_colors.grid(row=2, column=0, columnspan=2, pady=(5, 0))
        self.resize_note_picker()

    def close_note_picker(self):
        if self.note_picker is not None:
            picker, self.note_picker = self.note_picker, None
            picker.destroy()
            self.change_display.pack(side="right", padx=(0, pixels(self.window, 3)))
            self.set_display_kind(self.display_kind)
            self.layout_surfaces(len(self.cards))

    def pick_note_template(self, template):
        category = self.new_note_category.get()
        self.close_note_picker()
        self.new_note(template, category)

    def new_note(self, template="lined", category=UNCATEGORIZED):
        if self.select_note(None):
            self.note_template = template
            self.note_category = category
            self.render_note_template()
            self.note_body.focus_force()

    def flush_note(self):
        if self.pending_save is not None:
            self.window.after_cancel(self.pending_save)
            self.pending_save = None
        body = self.note_body.get("1.0", "end-1c")
        title = self.note_title.get()
        content = (title, body, self.note_template, self.note_image)
        if content == self.saved_note or (self.note_id is None and not (title.strip() or body.strip() or self.note_image)):
            if self.note_id is None:
                self.note_status.set("输入后自动保存到本地")
            return True
        try:
            note = self.app.store.write_desktop_note(body, title=title, template=self.note_template,
                                                     image=self.note_image, category=self.note_category)
        except sqlite3.Error as error:
            self.note_status.set("保存失败")
            self.app.show_data_error(self.window, error)
            return False
        self.saved_note = content
        self.update_note_header(note)
        self.app.refresh_notes()
        return True
