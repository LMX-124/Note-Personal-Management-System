import tkinter as tk
import tkinter.font as tkfont
from io import BytesIO
from tkinter import filedialog

from PIL import Image, ImageOps, ImageTk

from visual import EDGE, FONT, INK, WHITE, pixels


NOTE_COLORS = {"sticky-yellow": ("黄色", "#fff0ac"), "sticky-blue": ("蓝色", "#dbeaff"),
               "sticky-pink": ("粉色", "#f9dce7")}
NOTE_STYLES = {"lined": "白底便签", **{key: name + "便签" for key, (name, _) in NOTE_COLORS.items()},
               "photo": "照片便签", "heart": "并排便签"}


def choose_note_picture(parent):
    path = filedialog.askopenfilename(parent=parent, title="选择便签图片",
                                      filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp *.gif")])
    if not path:
        return None
    with Image.open(path) as source:
        if source.width * source.height > 30_000_000:
            raise ValueError("请选择不超过 3000 万像素的图片。")
        image = ImageOps.exif_transpose(source)
        image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
        data = BytesIO()
        image.convert("RGBA").save(data, format="PNG")
    return data.getvalue()


def draw_note_tape(canvas, x, y, width, height):
    points = ((.04, .22), (.94, .03), (.91, .24), (.97, .4), (.93, .63),
              (.98, .82), (.04, .99), (.07, .78), (.01, .61), (.06, .41))
    canvas.create_polygon(*(point for dx, dy in points for point in (x + dx * width, y + dy * height)),
                          fill="#c7ddf4", outline="#9db8d3")
    for offset in (.42, .63):
        canvas.create_line(x + .14 * width, y + offset * height,
                           x + .86 * width, y + (offset - .14) * height, fill="#dceafa")


class NotePreview(tk.Canvas):
    def __init__(self, parent, row, *, large=False):
        self.large = large
        factor = 4 if large else 1
        super().__init__(parent, bg=WHITE, width=pixels(parent, 62 * factor),
                         height=pixels(parent, 46 * factor), highlightthickness=0)
        self.scale = pixels(parent, 10) / 10 * factor
        self.template = None
        self.picture = None
        self.thumbnail = None
        self.title_font = tkfont.Font(parent, family=FONT, size=13 if large else 5, weight="bold")
        self.update_note(row)

    def update_note(self, row):
        if (self.template, self.picture) != (row["template"], row["image"]):
            self.template, self.picture = row["template"], row["image"]
            self.draw_frame()
        title = " ".join(row["title"].split())
        body = row["body"]
        limit = 6 if self.template == "heart" else 11
        if self.large:
            title = title[:24] or "输入标题"
            maximum = 25 if self.template == "photo" else 65 if self.template == "heart" else 100
            body = "\n".join(body.strip().splitlines()[:2 if self.template == "photo" else 3])
            if len(body) > maximum:
                body = body[:maximum - 1] + "…"
        else:
            title = title[:limit]
            body = " ".join(body.split())[:limit]
        if self.title_font.measure(title) > self.text_width:
            while title and self.title_font.measure(title + "…") > self.text_width:
                title = title[:-1]
            title += "…"
        self.itemconfigure(self.title_item, text=title, fill=INK if row["title"].strip() else "#60758d")
        self.itemconfigure(self.body_item, text=body)

    def draw_frame(self):
        self.delete("all")
        self.thumbnail = None
        template = self.template
        color = NOTE_COLORS.get(template, ("", WHITE))[1]
        scale = self.scale

        def rect(x1, y1, x2, y2, fill):
            self.create_rectangle(x1 * scale, y1 * scale, x2 * scale, y2 * scale,
                                  fill=fill, outline=EDGE)

        rect(1, 2, 61, 45, color)
        title_y, title_x, body_width = 10, 6, 50
        if template == "photo":
            self.draw_photo(self.picture, (5, 5, 57, 24), scale)
            title_y = 29
        elif template == "heart":
            self.draw_photo(self.picture, (5, 10, 22, 31), scale)
            title_x, body_width = 26, 31
        elif template == "lined":
            draw_note_tape(self, 17 * scale, 0, 27 * scale, 9 * scale)
            title_y = 14
        self.text_width = body_width * scale
        self.title_item = self.create_text(title_x * scale, title_y * scale, anchor="w",
                                           font=self.title_font, fill=INK)
        self.body_item = self.create_text(title_x * scale, (title_y + 7) * scale, anchor="nw",
                                          width=body_width * scale, font=(FONT, 10 if self.large else 5), fill=INK)

    def draw_photo(self, data, bounds, scale):
        left, top, right, bottom = (point * scale for point in bounds)
        self.create_rectangle(left, top, right, bottom, fill="#f0f5fa", outline=EDGE)
        if data:
            with Image.open(BytesIO(data)) as image:
                image.thumbnail((int(right - left), int(bottom - top)), Image.Resampling.LANCZOS)
                self.thumbnail = ImageTk.PhotoImage(image, master=self)
            self.create_image((left + right) / 2, (top + bottom) / 2, image=self.thumbnail)
        elif self.large:
            self.create_text((left + right) / 2, (top + bottom) / 2,
                             text="♡" if self.template == "heart" else "照片区域",
                             fill="#60758d", font=(FONT, 17 if self.template == "heart" else 10))
