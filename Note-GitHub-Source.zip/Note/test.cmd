@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\project.ps1" -Action Test
set "result=%errorlevel%"
pause
exit /b %result%
