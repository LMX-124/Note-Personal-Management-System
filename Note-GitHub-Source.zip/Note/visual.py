import tkinter as tk
import tkinter.font as tkfont

from palette import PALETTE

FONT = "Microsoft YaHei UI"
APP_NAME = "Note"
BG = "#f4f7fb"
WHITE = "#ffffff"
INK = "#202e40"
MUTED = "#53657b"
ACCENT = "#2b5a8c"
EDGE = "#dce6f0"
PAPER = "#e5f1ff"
PAPER_BODY = "#eff7ff"
SOFT_BLUE = "#e3effc"
PRIMARY = "#d8eaff"
PRIMARY_HOVER = "#c8e2fe"
SUBTLE = "#edf2f7"


def soft_rect(canvas, left, top, right, bottom, radius, color):
    points = (left + radius, top, right - radius, top, right, top, right, top + radius,
              right, bottom - radius, right, bottom, right - radius, bottom,
              left + radius, bottom, left, bottom, left, bottom - radius,
              left, top + radius, left, top)
    return canvas.create_polygon(points, smooth=True, splinesteps=28,
                                 fill=color, outline="", tags="surface")


def pixels(widget, amount):
    return max(1, round(widget.winfo_fpixels("1i") * amount / 96))


class Action(tk.Canvas):
    """Compact rounded button with mouse and keyboard activation."""

    def __init__(self, parent, label, command, surface, *, background=SUBTLE,
                 foreground=INK, hover=SOFT_BLUE, bold=False, height=34, width=None, align="center",
                 font_size=10):
        self.surface = surface
        self.command = command
        self.background = background
        self.foreground = foreground
        self.hover = hover
        self.align = align
        self.font = tkfont.Font(parent, family=FONT, size=font_size, weight="bold" if bold else "normal")
        self.label = label
        self.hovering = False
        self.padding = pixels(parent, 12)
        self.fixed_width = pixels(parent, width) if width else None
        super().__init__(parent, bg=surface, width=self.requested_width(),
                         height=pixels(parent, height), highlightthickness=0,
                         bd=0, takefocus=True, cursor="hand2")
        self.bind("<Configure>", self.draw)
        self.bind("<Enter>", lambda event: self.point(True))
        self.bind("<Leave>", lambda event: self.point(False))
        self.bind("<FocusIn>", self.draw)
        self.bind("<FocusOut>", self.draw)
        self.bind("<ButtonRelease-1>", self.activate)
        self.bind("<Return>", self.activate)
        self.bind("<space>", self.activate)

    def requested_width(self):
        return self.fixed_width or self.font.measure(self.label) + 2 * self.padding

    def point(self, hovering):
        self.hovering = hovering
        self.draw()

    def update_style(self, label, background, foreground):
        self.label, self.background, self.foreground = label, background, foreground
        self.configure(width=self.requested_width())
        self.draw()

    def draw(self, event=None):
        width, height = self.winfo_width(), self.winfo_height()
        if min(width, height) < 4:
            return
        self.delete("all")
        radius = pixels(self, 10)
        fill = self.hover if self.hovering or self.focus_get() == self else self.background
        soft_rect(self, 1, 1, width - 1, height - 1, radius, fill)
        self.draw_label(width, height)

    def draw_label(self, width, height):
        left = self.align == "left"
        self.create_text(self.padding if left else width / 2, height / 2,
                         text=self.label, font=self.font, fill=self.foreground,
                         anchor="w" if left else "center")

    def invoke(self):
        self.command()

    def activate(self, event):
        if event.type == tk.EventType.ButtonRelease:
            if not (0 <= event.x < self.winfo_width() and 0 <= event.y < self.winfo_height()):
                return "break"
        self.invoke()
        return "break"


class CircleAction(Action):
    def __init__(self, parent, done, command, *, size=35):
        self.done = done
        self.size = size
        super().__init__(parent, "恢复待办" if done else "完成待办", command, WHITE,
                         background=WHITE, foreground=ACCENT, width=size, height=size)

    def draw(self, event=None):
        if self.winfo_width() < 4:
            return
        self.delete("all")
        mid = self.winfo_width() / 2
        scale = pixels(self, 10) / 10 * self.size / 35
        radius = 10 * scale
        fill = ACCENT if self.done else SOFT_BLUE if self.hovering or self.focus_get() == self else WHITE
        self.create_oval(mid - radius, mid - radius, mid + radius, mid + radius,
                         fill=fill, outline=ACCENT, width=max(1, 1.3 * scale))
        if self.done:
            self.create_line(mid - 4 * scale, mid, mid - scale, mid + 3 * scale,
                             mid + 5 * scale, mid - 4 * scale, fill=WHITE,
                             width=1.7 * scale, capstyle="round", joinstyle="round")


def category_tint(color):
    if color in PALETTE:
        return PALETTE[color][1]
    channels = (int(color[index:index + 2], 16) for index in (1, 3, 5))
    return "#" + "".join(f"{round(255 * .87 + channel * .13):02x}" for channel in channels)


class CategoryPicker(Action):
    def __init__(self, parent, variable, get_colors, on_create, on_change, *, include_all=False,
                 on_manage=None):
        self.variable = variable
        self.get_colors = get_colors
        self.on_create = on_create
        self.on_change = on_change
        self.include_all = include_all
        self.on_manage = on_manage
        self.dropdown = None
        super().__init__(parent, "", self.open, BG, background=SUBTLE, foreground=MUTED,
                         height=36, align="left")
        self.refresh()

    def refresh(self):
        name = self.variable.get()
        color = self.get_colors().get(name)
        limit = 10 if self.include_all else 18
        label = (name[:limit - 1] + "…" if len(name) > limit else name) + "  ▾"
        self.update_style(label, category_tint(color) if color else SUBTLE, color or MUTED)

    def open(self):
        if self.dropdown is not None:
            self.dismiss()
            return
        colors = self.get_colors()
        popup = tk.Toplevel(self.winfo_toplevel(), bg=EDGE)
        popup.withdraw()
        popup.overrideredirect(True)
        popup.attributes("-topmost", True)
        self.dropdown = popup
        popup.bind("<Escape>", lambda event: self.dismiss())
        popup.bind("<ButtonPress-1>", self.dismiss_outside)
        popup.bind("<Destroy>", self.clear_dropdown)
        panel = tk.Frame(popup, bg=WHITE, padx=pixels(self, 6), pady=pixels(self, 6))
        panel.pack(fill="both", expand=True, padx=1, pady=1)
        options = list(colors.items())
        if self.include_all:
            options.insert(0, ("全部分类", ACCENT))
        self.option_buttons = {}
        rows = self.dropdown_rows(panel, len(options))
        for name, color in options:
            tint = category_tint(color)
            label = name[:15] + "…" if len(name) > 16 else name
            button = Action(rows, label, lambda value=name: self.select_option(value), WHITE,
                            background=tint, foreground=color, hover=tint, align="left", height=31)
            button.pack(fill="x", pady=(0, pixels(self, 3)))
            self.option_buttons[name] = button
        tk.Frame(panel, bg=EDGE, height=1).pack(fill="x", pady=pixels(self, 3))
        Action(panel, "＋ 新建分类", self.create, WHITE, background=WHITE, foreground=ACCENT,
               align="left", height=29).pack(fill="x")
        if self.on_manage is not None:
            self.manage_button = Action(panel, "管理分类", self.manage, WHITE, background=SOFT_BLUE,
                                        foreground=ACCENT, align="left", height=31, bold=True)
            self.manage_button.pack(fill="x", pady=(pixels(self, 2), 0))
        popup.update_idletasks()
        natural_width = max(button.requested_width() for button in self.option_buttons.values())
        width = min(pixels(self, 275),
                    max(pixels(self, 155), self.winfo_width(), natural_width + pixels(self, 17)))
        height = popup.winfo_reqheight()
        x = max(0, min(self.winfo_rootx(), self.winfo_screenwidth() - width))
        y = self.winfo_rooty() + self.winfo_height() + pixels(self, 4)
        if y + height > self.winfo_screenheight() - pixels(self, 28):
            y = max(0, self.winfo_rooty() - height - pixels(self, 4))
        popup.geometry(f"{width}x{height}+{x}+{y}")
        popup.deiconify()
        popup.grab_set()
        popup.focus_force()

    def dropdown_rows(self, panel, count):
        holder = tk.Frame(panel, bg=WHITE)
        holder.pack(fill="x")
        if count <= 6:
            return holder
        canvas = tk.Canvas(holder, width=1, height=pixels(self, 6 * 34), bg=WHITE, highlightthickness=0)
        scrollbar = tk.Scrollbar(holder, orient="vertical", command=canvas.yview, width=pixels(self, 8))
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="x", expand=True)
        rows = tk.Frame(canvas, bg=WHITE)
        item = canvas.create_window(0, 0, anchor="nw", window=rows)
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(item, width=event.width))
        rows.bind("<Configure>", lambda event: canvas.configure(scrollregion=canvas.bbox("all")))
        self.dropdown.bind("<MouseWheel>", lambda event: canvas.yview_scroll(-int(event.delta / 120), "units"))
        return rows

    def clear_dropdown(self, event):
        if event.widget is self.dropdown:
            self.dropdown = None

    def dismiss_outside(self, event):
        popup = self.dropdown
        if popup is None:
            return
        x, y = popup.winfo_rootx(), popup.winfo_rooty()
        if not (x <= event.x_root < x + popup.winfo_width()
                and y <= event.y_root < y + popup.winfo_height()):
            self.dismiss()

    def dismiss(self):
        if self.dropdown is not None:
            self.dropdown.destroy()

    def select_option(self, name):
        self.dismiss()
        self.select(name)

    def create(self):
        self.dismiss()
        name = self.on_create()
        if name:
            self.select(name)

    def manage(self):
        self.dismiss()
        self.on_manage()
        colors = self.get_colors()
        if self.variable.get() not in colors and self.variable.get() != "全部分类":
            self.select("全部分类" if self.include_all else next(iter(colors)))
        else:
            self.refresh()

    def select(self, name):
        self.variable.set(name)
        self.refresh()
        self.on_change()


class RecordCard(tk.Canvas):
    def __init__(self, parent, height=78, *, auto_pack=True):
        super().__init__(parent, bg=BG, height=pixels(parent, height), bd=0, highlightthickness=0)
        if auto_pack:
            self.pack(fill="x", pady=(0, pixels(self, 9)))
        self.body = tk.Frame(self, bg=WHITE)
        self.inner = self.create_window(0, 0, anchor="nw", window=self.body)
        self.bind("<Configure>", self.resize)

    def resize(self, event):
        width, height = event.width, event.height
        if min(width, height) < 6:
            return
        self.delete("surface")
        radius = pixels(self, 14)
        soft_rect(self, 0, 0, width, height, radius, EDGE)
        soft_rect(self, 1, 1, width - 1, height - 1, radius, WHITE)
        self.tag_lower("surface")
        inset_x, inset_y = pixels(self, 15), pixels(self, 10)
        self.coords(self.inner, inset_x, inset_y)
        self.itemconfigure(self.inner, width=max(1, width - 2 * inset_x),
                           height=max(1, height - 2 * inset_y))


class FitLabel(tk.Label):
    def __init__(self, parent, text, font, foreground, *, background=WHITE):
        self.full_text = text
        self.measure_font = tkfont.Font(parent, font=font)
        super().__init__(parent, text=text, font=self.measure_font, fg=foreground,
                         bg=background, anchor="w")
        self.bind("<Configure>", self.fit)

    def fit(self, event):
        width = event.width - 6
        if self.measure_font.measure(self.full_text) <= width:
            text = self.full_text
        else:
            left, right = 0, len(self.full_text)
            while left < right:
                middle = (left + right + 1) // 2
                if self.measure_font.measure(self.full_text[:middle] + "…") <= width:
                    left = middle
                else:
                    right = middle - 1
            text = self.full_text[:left] + "…"
        if text != self.cget("text"):
            self.configure(text=text)


