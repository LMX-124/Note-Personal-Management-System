import sqlite3
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch
from datetime import date, datetime, timedelta
from io import BytesIO
from pathlib import Path

from PIL import Image

from storage import Store


class StoreTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "test.sqlite3"
        self.store = Store(self.path)
        self.addCleanup(self.store.close)
        self.now = datetime(2026, 11, 7, 12)

    def test_calendar_tracks_actual_completion_and_all_pending_tasks(self):
        first = self.store.save_task("过期待办", "学习", datetime(2024, 1, 1), None)
        second = self.store.save_task("无截止", "工作", None, None)
        self.store.set_done(first, True)
        self.assertEqual([row["id"] for row in self.store.completed_tasks_on(date.today())], [first])
        self.assertEqual([row["id"] for row in self.store.desktop_tasks()], [second])
        self.store.set_done(first, False)
        self.assertEqual(self.store.completed_tasks_on(date.today()), [])

    def test_calendar_summaries_count_records_and_total_money_by_day(self):
        day = date.today()
        self.store.save_note("便签一", "", "学习")
        self.store.save_note("便签二", "", "生活")
        self.store.save_journal("mood", day, {"facts": "记录"})
        self.store.save_journal("review", day, {"gains": "收获"})
        self.store.save_ledger_entry(day, "income", 20000, "")
        self.store.save_ledger_entry(day, "expense", 1550, "")
        self.store.save_ledger_entry(day + timedelta(days=1), "expense", 999, "")
        summary = self.store.calendar_summary(day)[day]
        self.assertEqual((summary["notes"], summary["journals"], summary["income"],
                          summary["expense"], summary["bills"]), (2, 2, 20000, 1550, 2))

    def test_ledger_keeps_exact_cents_and_marks_only_days_with_records(self):
        day = date(2026, 11, 9)
        entry = self.store.save_ledger_entry(day, "expense", 1025, "午饭")
        self.store.save_ledger_entry(day, "income", 3050, "退款")
        self.store.save_ledger_entry(day, "expense", 1205, "午饭和饮料", entry)
        rows = self.store.ledger_entries(day)
        self.assertEqual([(row["kind"], row["cents"]) for row in rows],
                         [("expense", 1205), ("income", 3050)])
        self.assertEqual(self.store.calendar_days(day), {day})
        for row in rows:
            self.store.delete_ledger_entry(day, row["id"])
        self.assertEqual(self.store.calendar_days(day), set())

    def test_calendar_migrates_legacy_note_once_and_keeps_date_when_edited(self):
        path = self.path.with_name("legacy.sqlite3")
        with sqlite3.connect(path) as legacy:
            legacy.execute("""CREATE TABLE notes (
                id INTEGER PRIMARY KEY, title TEXT, body TEXT, category TEXT, updated_at TEXT
            )""")
            legacy.execute("INSERT INTO notes VALUES (1, '旧便签', '', '生活', '2024-03-05 16:30:00')")
        legacy.close()
        store = Store(path)
        self.addCleanup(store.close)
        day = date(2024, 3, 5)
        store.save_note("修改后的旧便签", "", "生活", note_id=1)
        self.assertEqual(store.notes_on(day)[0]["title"], "修改后的旧便签")
        self.assertEqual(store.calendar_days(day), {day})

    def test_deadline_order_takes_precedence_over_legacy_priorities_and_manual_order(self):
        later = self.store.save_task("稍晚", "工作", datetime(2026, 11, 9), None)
        overdue = self.store.save_task("已逾期", "学习", datetime(2026, 11, 6), None)
        soon = self.store.save_task("今天", "工作", datetime(2026, 11, 7, 18), None)
        anytime = self.store.save_task("无截止", "生活", None, None)
        with self.store.db:
            self.store.db.execute("UPDATE tasks SET priority = 3, manual_order = 0 WHERE id = ?", (later,))
        self.assertEqual([row["id"] for row in self.store.tasks()], [overdue, soon, later, anytime])

    def test_desktop_drag_order_survives_restart_and_new_item_is_inserted_by_due_date(self):
        first = self.store.save_task("第一项", "学习", datetime(2026, 11, 8, 10), None)
        last = self.store.save_task("最后一项", "生活", datetime(2026, 11, 8, 17), None)
        middle = self.store.save_task("中间一项", "工作", datetime(2026, 11, 8, 13), None)
        self.assertEqual([row["id"] for row in self.store.desktop_tasks()], [first, middle, last])
        self.store.move_desktop_task(middle, first)
        inserted = self.store.save_task("新事项", "工作", datetime(2026, 11, 8, 15), None)
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual([row["id"] for row in reopened.desktop_tasks()], [middle, first, inserted, last])
        self.assertEqual([row["id"] for row in reopened.tasks()], [first, middle, inserted, last])

    def test_reminders_resume_once_and_ignore_completed_tasks(self):
        past = datetime(2026, 11, 7, 11)
        future = datetime(2026, 11, 7, 13)
        missed = self.store.save_task("补报", "课程", None, past)
        done = self.store.save_task("已完成", "课程", None, past)
        upcoming = self.store.save_task("稍后", "课程", None, future)
        self.store.set_done(done, True)
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual([row["id"] for row in reopened.take_reminders(self.now)], [missed])
        self.assertEqual(self.store.take_reminders(self.now), [])
        self.assertEqual([row["id"] for row in self.store.take_reminders(future)], [upcoming])
        self.store.save_task("改提醒", "课程", None, future, task_id=missed)
        self.assertEqual([row["id"] for row in self.store.take_reminders(future)], [missed])

    def test_note_persists_and_matches_literal_search(self):
        note = self.store.save_note("上课", "实验报告完成 50%", "课程")
        self.store.save_note("其他", "实验报告草稿", "生活")
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual([row["id"] for row in reopened.notes("50%", "课程")], [note])
        self.assertEqual(reopened.notes("%", "生活"), [])
        reopened.save_note("上课", "改好了", "课程", note_id=note)
        self.assertEqual(self.store.notes("改好了")[0]["id"], note)

    def test_custom_categories_keep_their_color_after_restart(self):
        defaults = self.store.category_colors()
        self.assertEqual(tuple(defaults), ("生活", "学习", "工作"))
        self.assertEqual(len(set(defaults.values())), 3)
        self.store.create_category("运动")
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        colors = reopened.category_colors()
        self.assertEqual(colors, self.store.category_colors())
        self.assertNotIn(colors["运动"], defaults.values())
        with self.assertRaises(ValueError):
            reopened.create_category(" 运动 ")

    def test_category_recolor_and_delete_keep_records_and_survive_restart(self):
        task = self.store.save_task("整理资料", "工作", None, None)
        note = self.store.save_note("会议记录", "内容", "工作")
        self.store.set_category_color("工作", "#674183")
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual(reopened.category_colors()["工作"], "#674183")
        reopened.delete_category("工作")
        self.assertNotIn("工作", self.store.category_colors())
        self.assertEqual([(row["id"], row["category"]) for row in self.store.tasks()], [(task, "未分类")])
        self.assertEqual([(row["id"], row["category"]) for row in self.store.notes()], [(note, "未分类")])
        with self.assertRaises(ValueError):
            reopened.delete_category("未分类")
        self.assertEqual(reopened.create_category("工作"), "工作")
        self.assertIn("工作", self.store.category_colors())

    def test_desktop_note_selection_and_timestamp_survive_restart(self):
        chosen = self.store.save_note("置于桌面", "第一张", "生活")
        self.store.save_note("另一张", "第二张", "工作")
        self.store.set_desktop_note(chosen)
        self.store.write_desktop_note("从桌面改写")
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        note = reopened.desktop_note()
        self.assertEqual((note["id"], note["body"]), (chosen, "从桌面改写"))
        self.assertIsInstance(datetime.fromisoformat(note["updated_at"]), datetime)

    def test_diary_types_and_dates_are_independent_after_reopen(self):
        today = date(2026, 11, 8)
        yesterday = today - timedelta(days=1)
        self.store.save_journal("mood", today, {"facts": "完成会议", "moods": ["平静"]})
        self.store.save_journal("review", today, {"gains": "学会了整理资料", "plan": ["阅读", "散步", ""]})
        self.store.save_journal("mood", yesterday, {"needs": "休息"})
        self.store.save_journal("mood", today, {"facts": "会议结束", "moods": ["平静", "疲惫"]})
        reopened = Store(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual(reopened.journal_dates("mood"), [today, yesterday])
        self.assertEqual(reopened.journal("mood", yesterday), {"needs": "休息"})
        self.assertEqual(reopened.journal("mood", today)["moods"], ["平静", "疲惫"])
        self.assertEqual(reopened.journal("review", today)["plan"], ["阅读", "散步", ""])
        reopened.save_journal("mood", today, {"facts": "  ", "moods": []})
        self.assertEqual(reopened.journal_dates("mood"), [yesterday])
        self.assertIsNotNone(reopened.journal("review", today))


class WindowTests(unittest.TestCase):
    def setUp(self):
        from app import CourseDesk

        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.store = Store(Path(directory.name) / "test.sqlite3")
        self.addCleanup(self.store.close)
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = CourseDesk(self.root, self.store)
        self.root.update_idletasks()
        self.addCleanup(self.app.close)

    def test_save_task_updates_widget_and_completion_removes_it(self):
        editor = self.app.edit_task()
        editor.title.set("实验报告")
        editor.category_picker.select("学习")
        editor.save()
        row = self.store.tasks()[0]
        self.assertEqual(row["category"], "学习")
        self.assertIn("实验报告", self.widget_titles())
        self.app.complete_task(row["id"])
        self.assertNotIn("实验报告", self.widget_titles())

    def widget_titles(self):
        return [card.title.cget("text") for card in self.app.desktop.cards.values()]

    def test_note_body_saves_when_quick_editor_closes(self):
        editor = self.app.edit_note()
        editor.body.insert("1.0", "周一带电脑")
        editor.close()
        self.assertEqual(self.store.notes()[0]["body"], "周一带电脑")

    def test_task_category_filter_leaves_desktop_tasks_in_place(self):
        work = self.store.save_task("设计稿", "工作", None, None)
        self.store.save_task("采购", "生活", None, None)
        self.app.refresh_tasks()
        self.app.workspace.task_category_picker.select("工作")
        self.assertEqual(tuple(self.app.workspace.tasks.items), (work,))
        self.assertEqual(self.widget_titles(), ["设计稿", "采购"])
        self.app.workspace.task_category_picker.select("全部分类")
        self.assertEqual(len(self.app.workspace.tasks.items), 2)

    def test_management_uses_one_time_ordered_list_and_marks_only_overdue_items(self):
        now = datetime.now().replace(second=0, microsecond=0)
        work = self.store.save_task("早些处理", "工作", now - timedelta(days=1), None)
        life = self.store.save_task("买菜", "生活", now + timedelta(days=1), None)
        later = self.store.save_task("稍后处理", "工作", now + timedelta(days=2), None)
        done = self.store.save_task("已经完成", "工作", now - timedelta(days=2), None)
        self.store.set_done(done, True)
        workspace = self.app.workspace
        workspace.set_task_filter("all")
        self.assertEqual(list(workspace.tasks.items), [work, life, later, done])
        sections = [widget.cget("text") for widget in workspace.tasks.inner.winfo_children()
                    if isinstance(widget, tk.Label)]
        self.assertEqual(sections, [])
        self.assertEqual((workspace.task_open_count.get(), workspace.task_done_count.get()), (3, 1))
        details = workspace.tasks.items[work].details.winfo_children()
        self.assertEqual(details[0].label, "工作")
        overdue_card = workspace.tasks.items[work]
        title = overdue_card.title
        self.assertLess(int(details[0].font.cget("size")), int(title.measure_font.cget("size")))
        self.assertEqual([label.cget("text") for label in details[1:]],
                         [(now - timedelta(days=1)).strftime("%Y-%m-%d %H:%M")])
        self.assertEqual(overdue_card.overdue_badge.cget("text"), "！已逾期")
        self.assertEqual(overdue_card.title.master.winfo_children(), [title, overdue_card.overdue_badge])
        self.assertEqual(len(workspace.tasks.items[done].details.winfo_children()), 2)

    def test_category_manager_has_twenty_colors_and_recolors_both_task_views(self):
        from category_manager import CategoryManager

        item = self.store.save_task("整理资料", "工作", None, None)
        self.app.refresh_tasks()
        manager = CategoryManager(self.root, self.app)
        self.assertEqual(len(manager.swatches), 20)
        self.assertEqual(len(set(manager.swatches)), 20)
        manager.select_category("工作")
        self.assertEqual(manager.summary.get(), "工作")
        self.assertTrue(all(swatch.label.endswith("工作") for swatch in manager.swatches.values()))
        manager.apply_color("#674183")
        desktop_card = self.app.desktop.cards[item]
        main_tag = self.app.workspace.tasks.items[item].details.winfo_children()[0]
        self.assertEqual(desktop_card.title.cget("fg"), "#674183")
        self.assertEqual(main_tag.foreground, "#674183")
        manager.window.destroy()

    def test_category_dropdown_uses_highlighted_options_and_management_action(self):
        self.root.deiconify()
        self.root.update()
        picker = self.app.workspace.task_category_picker
        picker.open()
        self.root.update()
        life = picker.option_buttons["生活"]
        self.assertEqual(life.label, "生活")
        self.assertEqual(life.background, "#f9e8a9")
        self.assertIn("管理分类", picker.manage_button.label)
        life.invoke()
        self.assertEqual(self.app.workspace.task_category.get(), "生活")
        self.assertIsNone(picker.dropdown)

    def test_task_deadline_expands_and_applies_within_the_editor(self):
        editor = self.app.edit_task()
        self.root.update()
        windows = [child for child in self.root.winfo_children() if isinstance(child, tk.Toplevel)]
        picker = editor.deadline_picker
        picker.arrow.invoke()
        self.root.update()
        self.assertTrue(picker.panel.winfo_ismapped())
        self.assertEqual([child for child in self.root.winfo_children() if isinstance(child, tk.Toplevel)], windows)
        for variable, value in zip(picker.parts, ("2026", "11", "08", "19", "45")):
            variable.set(value)
        picker.apply()
        self.assertEqual(editor.due.get(), "2026-11-08 19:45")
        self.assertFalse(picker.panel.winfo_ismapped())

    def test_due_reminder_appears_under_desktop_without_popup_and_only_once(self):
        task_id = self.store.save_task("交作业", "学习", None, datetime(2026, 1, 1))
        self.app.refresh_tasks()
        windows = [child for child in self.root.winfo_children() if isinstance(child, tk.Toplevel)]
        self.app.check_reminders()
        self.root.update_idletasks()
        desktop = self.app.desktop
        self.assertEqual(list(desktop.reminders), [task_id])
        self.assertEqual([child for child in self.root.winfo_children() if isinstance(child, tk.Toplevel)], windows)
        reminder_y = desktop.scene.coords(desktop.reminder_surface)[1]
        task_y = desktop.scene.coords(desktop.task_surface)[1]
        self.assertGreater(reminder_y, task_y + float(desktop.scene.itemcget(desktop.task_surface, "height")))
        texts = [label.cget("text") for row in desktop.reminder_box.winfo_children()
                 for label in row.winfo_children()]
        self.assertEqual(texts, ["学习", "交作业"])
        self.app.check_reminders()
        self.assertEqual(len(desktop.reminders), 1)
        desktop.dismiss_reminder(task_id)
        self.assertEqual(desktop.scene.itemcget(desktop.reminder_surface, "state"), "hidden")
        self.app.check_reminders()
        self.assertFalse(desktop.reminders)

    def test_thirty_second_reminder_keeps_seconds_when_saved_and_reopened(self):
        from app import parse_time
        now = (datetime.now() + timedelta(days=1)).replace(hour=12, minute=34, second=45, microsecond=0)
        editor = self.app.edit_task()
        editor.title.set("展示提醒")
        editor.reminder_picker.toggle()
        with patch("app.datetime", wraps=datetime) as clock:
            clock.now.return_value = now
            editor.reminder_picker.thirty_seconds.invoke()
        expected = now + timedelta(seconds=30)
        self.assertEqual(parse_time(editor.reminder.get(), "提醒时间"), expected)
        self.assertFalse(editor.reminder_picker.panel.winfo_manager())
        editor.save()
        row = self.store.tasks()[0]
        self.assertEqual(row["remind_at"], expected.isoformat(sep=" ", timespec="seconds"))
        self.assertFalse(self.store.take_reminders(expected - timedelta(seconds=1)))
        reopened = self.app.edit_task(row)
        self.assertEqual(parse_time(reopened.reminder.get(), "提醒时间"), expected)
        self.assertEqual([item["id"] for item in self.store.take_reminders(expected)], [row["id"]])

    def test_desktop_note_picker_expands_three_colors_and_keeps_white_photo_layouts(self):
        desktop = self.app.desktop
        desktop.open_note_templates()
        desktop.new_note_category.set("工作")
        desktop.show_note_styles()
        self.assertEqual(len(desktop.note_choices), 4)
        desktop.note_choices[0].invoke()
        self.assertEqual(len(desktop.note_colors.winfo_children()), 3)
        desktop.note_colors.winfo_children()[2].invoke()
        self.assertEqual(desktop.note_title_hint.cget("text"), "输入标题")
        self.assertEqual(desktop.note_title_hint.winfo_manager(), "place")
        self.assertEqual(desktop.note_body.winfo_children(), [])
        desktop.note_body.insert("1.0", "粉色便签")
        self.assertTrue(desktop.flush_note())
        self.assertEqual(self.store.desktop_note()["template"], "sticky-pink")
        self.assertEqual(self.store.desktop_note()["category"], "工作")
        desktop.new_note("photo")
        self.assertLess(int(desktop.note_photo.grid_info()["row"]),
                        int(desktop.note_heading.grid_info()["row"]))
        desktop.new_note("heart")
        self.assertEqual([int(widget.grid_info()["column"]) for widget in
                          (desktop.note_photo, desktop.note_heading, desktop.note_body)], [0, 1, 1])
        self.assertLess(int(desktop.note_heading.grid_info()["row"]),
                        int(desktop.note_body.grid_info()["row"]))
        self.assertEqual(desktop.note_card.cget("bg"), "#ffffff")

    def test_desktop_note_enter_moves_from_title_then_inserts_and_saves_newline(self):
        desktop = self.app.desktop
        desktop.new_note("sticky-pink")
        desktop.note_title.set("标题")
        desktop.note_heading.focus_force()
        self.root.update()
        desktop.note_heading.event_generate("<Return>")
        self.assertEqual(desktop.window.focus_get(), desktop.note_body)
        desktop.note_body.insert("1.0", "第一行")
        desktop.note_body.event_generate("<Return>")
        desktop.note_body.insert("insert", "第二行")
        self.assertTrue(desktop.flush_note())
        self.assertEqual(self.store.desktop_note()["body"], "第一行\n第二行")

    def test_calendar_opens_records_for_selected_day(self):
        day = date.today()
        photo = BytesIO()
        Image.new("RGB", (12, 12), "blue").save(photo, format="PNG")
        note = self.store.write_desktop_note("正文", title="日历便签", template="photo", image=photo.getvalue())
        self.store.save_journal("mood", day, {"facts": "事实"})
        self.store.save_journal("review", day, {"gains": "收获"})
        workspace = self.app.workspace
        workspace.show_page("calendar")
        calendar = workspace.calendar
        calendar.select(day)
        self.assertEqual(len(calendar.records), 3)
        calendar.open_record(*next(iter(calendar.records.values())))
        self.assertEqual(self.app.note_editor.preview.thumbnail.width(), 12)
        self.assertTrue(self.app.note_editor.close())
        calendar.open_record("mood", day)
        self.assertEqual(workspace.active_page, "mood")
        self.assertEqual(workspace.journals["mood"].day, day)
        self.assertEqual(self.store.notes_on(day)[0]["id"], note["id"])

    def test_calendar_ledger_backdates_and_desktop_quick_add_uses_today(self):
        today = date.today()
        yesterday = today - timedelta(days=1)
        workspace = self.app.workspace
        workspace.show_page("calendar")
        workspace.calendar.select(yesterday)
        workspace.calendar.open_ledger(yesterday)
        self.assertEqual(workspace.active_page, "ledger")
        workspace.ledger.amount.set("12.50")
        workspace.ledger.save()
        self.assertEqual(self.store.ledger_entries(yesterday)[0]["cents"], 1250)
        quick = self.app.desktop.quick_create("ledger")
        self.assertEqual(workspace.ledger.day, yesterday)
        self.assertEqual(quick.day, today)
        quick.set_category("餐饮")
        for key in ("1", ".", "5", "0"):
            quick.key(key)
        quick.finish()
        self.assertEqual(self.store.ledger_entries(today)[0]["category"], "餐饮")
        self.assertEqual(self.store.ledger_entries(today)[0]["cents"], 150)

    def test_note_starts_hidden_and_new_editor_previews_templates(self):
        desktop = self.app.desktop
        self.root.update()
        self.assertFalse(desktop.note_body.winfo_ismapped())
        editor = self.app.new_note()
        self.assertEqual(editor.preview.template, "lined")
        editor.style.set("黄色便签")
        editor.title.set("预览标题")
        self.assertEqual(editor.preview.template, "sticky-yellow")
        self.assertEqual(editor.preview.itemcget(editor.preview.title_item, "text"), "预览标题")
        self.assertTrue(editor.close())
        self.root.update()
        self.assertTrue(desktop.note_body.winfo_ismapped())
        self.assertEqual(desktop.note_id, self.store.notes()[0]["id"])
        self.store.save_ledger_entry(date.today(), "expense", 250, "早餐")
        desktop.show_summary("ledger")
        self.root.update()
        self.assertFalse(desktop.note_body.winfo_ismapped())
        totals = desktop.summary_content.winfo_children()[0]
        self.assertIn("¥2.50", [tile.winfo_children()[1].cget("text") for tile in totals.winfo_children()])
        self.store.save_journal("review", date.today(), {"gains": "读书\n整理笔记"})
        desktop.show_summary("review")
        self.root.update()
        sheet = desktop.summary_content.winfo_children()[0]
        text = [sheet.itemcget(item, "text") for item in sheet.find_all() if sheet.type(item) == "text"]
        self.assertIn("今日收获", text)
        self.assertIn("• 读书\n• 整理笔记", text)

    def test_desktop_quick_note_and_journal_keep_main_page(self):
        workspace = self.app.workspace
        desktop = self.app.desktop
        picker = desktop.quick_create("notes")
        self.root.update()
        self.assertEqual(picker.winfo_toplevel(), desktop.window)
        self.assertTrue(picker.winfo_ismapped())
        self.assertIsNone(self.app.note_editor)
        desktop.show_note_styles()
        desktop.note_choices[0].invoke()
        desktop.note_colors.winfo_children()[2].invoke()
        desktop.note_title.set("桌面新建")
        self.assertTrue(desktop.flush_note())
        self.assertEqual(self.store.notes()[0]["template"], "sticky-pink")
        journal = self.app.desktop.quick_create("mood")
        journal.texts["facts"].insert("1.0", "独立窗口输入")
        self.assertTrue(journal.save())
        self.assertEqual(self.store.journal("mood", date.today())["facts"], "独立窗口输入")
        self.assertEqual(workspace.active_page, "tasks")

    def test_desktop_note_can_be_typed_and_switched(self):
        older = self.store.save_note("另一张", "会议纪要", "工作")
        self.app.desktop.note_body.insert("1.0", "桌面临时记下的内容")
        self.assertTrue(self.app.desktop.flush_note())
        self.assertEqual(self.store.desktop_note()["body"], "桌面临时记下的内容")
        self.assertTrue(self.app.desktop.select_note(older))
        self.assertEqual(self.app.desktop.note_body.get("1.0", "end-1c"), "会议纪要")
        self.assertEqual(len(self.store.notes()), 2)

    def test_desktop_completion_reveals_next_task_and_stays_in_history(self):
        ids = [self.store.save_task(f"任务 {n}", "工作", datetime(2026, 11, 7, 8 + n), None)
               for n in range(4)]
        self.app.refresh_tasks()
        desktop = self.app.desktop
        self.assertEqual(list(desktop.cards), ids[:3])
        desktop.cards[ids[0]].complete.invoke()
        self.assertEqual(list(desktop.cards), ids[1:])
        self.app.workspace.set_task_filter("done")
        self.assertEqual(tuple(self.app.workspace.tasks.items), (ids[0],))
        self.app.workspace.tasks.items[ids[0]].primary.invoke()
        self.assertEqual(list(desktop.cards), ids[:3])

    def test_desktop_double_click_opens_matching_management_page(self):
        self.root.deiconify()
        self.root.update()
        desktop = self.app.desktop
        desktop.note_body.insert("1.0", "双击前保存")
        for control, page in ((desktop.note_body, "notes"), (desktop.task_heading, "tasks")):
            self.app.hide_main()
            self.root.update()
            self.assertEqual(self.root.state(), "withdrawn")
            self.assertTrue(desktop.window.winfo_viewable())
            for ms in (1000, 1100):
                control.event_generate("<ButtonPress-1>", x=6, y=8, time=ms)
                control.event_generate("<ButtonRelease-1>", x=6, y=8, time=ms + 20)
            self.assertEqual(self.app.workspace.active_page, page)
            self.assertEqual(self.root.state(), "normal")
        self.assertEqual(self.store.desktop_note()["body"], "双击前保存")

    def test_note_library_can_pin_a_note_to_the_desktop(self):
        note_id = self.store.save_note("随手记", "带伞", "生活")
        self.app.refresh_notes()
        self.app.workspace.notes.items[note_id].primary.invoke()
        self.assertEqual(self.store.desktop_note()["id"], note_id)
        self.assertEqual(self.app.desktop.note_body.get("1.0", "end-1c"), "带伞")

    def test_mood_journal_saves_draft_before_switching_day(self):
        page = self.app.workspace.journals["mood"]
        today = page.day
        page.texts["facts"].insert("1.0", "按约定时间出门了")
        page.texts["needs"].insert("1.0", "一点独处时间")
        page.moods["平静"].invoke()
        page.emoji_menu.invoke(0)
        self.assertTrue(page.select_date(today - timedelta(days=1)))
        self.assertEqual(page.texts["facts"].get("1.0", "end-1c"), "")
        self.assertTrue(page.select_date(today))
        self.assertEqual(page.texts["facts"].get("1.0", "end-1c"), "按约定时间出门了")
        self.assertEqual(self.store.journal("mood", today)["needs"], "一点独处时间")
        self.assertEqual(self.store.journal("mood", today)["moods"], ["平静"])
        self.assertEqual(self.store.journal("mood", today)["emojis"], ["😊"])

    def test_review_presets_custom_titles_and_multiline_plan_survive_reload(self):
        workspace = self.app.workspace
        workspace.show_page("review")
        page = workspace.journals["review"]
        page.apply_review_preset("一日四分")
        self.assertEqual([title.get() for title in page.review_titles], ["凌晨", "上午", "下午", "夜晚"])
        page.review_titles[2].set("自由记录")
        page.texts["gains"].insert("1.0", "学会分解目标")
        page.texts["plan"].insert("1.0", "看完一章\n\n散步")
        workspace.show_page("tasks")
        entry = self.store.journal("review", page.day)
        self.assertEqual(entry["gains"], "学会分解目标")
        self.assertEqual(entry["plan"], ["看完一章", "", "散步"])
        self.assertTrue(page.select_date(page.day))
        self.assertEqual(page.review_titles[2].get(), "自由记录")
        self.assertEqual(page.texts["plan"].get("1.0", "end-1c"), "看完一章\n\n散步")

    def test_floating_panel_collapses_to_three_then_expands_and_scrolls(self):
        desktop = self.app.desktop
        desktop.new_note()
        self.root.deiconify()
        self.assertTrue(desktop.window.overrideredirect())
        self.root.update()
        empty_height = desktop.window.winfo_height()
        for number in range(3):
            self.store.save_task(f"任务 {number}", "个人", None, None)
        self.app.refresh_tasks()
        self.root.update()
        three_task_height = desktop.window.winfo_height()
        self.assertGreater(three_task_height, empty_height)
        last_card = list(desktop.cards.values())[-1].frame
        self.assertGreaterEqual(desktop.canvas.winfo_height(), last_card.winfo_y() + last_card.winfo_height())
        footer = desktop.note_footer
        self.assertGreaterEqual(footer.winfo_height(), footer.winfo_reqheight())
        for number in range(3, 8):
            self.store.save_task(f"任务 {number}", "个人", None, None)
        self.app.refresh_tasks()
        self.root.update()
        collapsed_height = desktop.window.winfo_height()
        collapsed_list_height = desktop.canvas.winfo_height()
        self.assertEqual(desktop.count.get(), 8)
        self.assertEqual(len(desktop.cards), 3)
        desktop.note_body.insert("1.0", "展开前写下的便签")
        desktop.more.invoke()
        self.root.update()
        self.assertEqual(len(desktop.cards), 8)
        self.assertGreater(desktop.canvas.winfo_height(), collapsed_list_height)
        self.assertFalse(desktop.note_body.winfo_ismapped())
        self.assertEqual(self.store.desktop_note()["body"], "展开前写下的便签")
        self.assertTrue(desktop.scroll.winfo_ismapped())
        self.app.complete_task(next(iter(desktop.cards)))
        self.assertEqual(desktop.count.get(), 7)
        desktop.more.invoke()
        self.root.update()
        self.assertEqual(len(desktop.cards), 3)
        self.assertEqual(desktop.window.winfo_height(), collapsed_height)
        self.assertTrue(desktop.note_body.winfo_ismapped())
        self.assertEqual(desktop.note_body.get("1.0", "end-1c"), "展开前写下的便签")

    def test_collapsed_tasks_show_deadline_and_category_highlights(self):
        first = self.store.save_task("复习", "学习", datetime(2026, 11, 8, 19, 30), None)
        second = self.store.save_task("买菜", "生活", datetime(2026, 11, 9, 12), None)
        self.app.refresh_tasks()
        self.root.update_idletasks()
        cards = self.app.desktop.cards
        self.assertEqual(cards[first].deadline.cget("text"), "11-08 19:30")
        self.assertEqual(cards[second].deadline.cget("text"), "11-09 12:00")
        self.assertEqual(cards[first].deadline.cget("fg"), "#000000")
        self.assertEqual(cards[second].deadline.cget("fg"), "#000000")
        self.assertNotEqual(cards[first].title.cget("bg"), cards[second].title.cget("bg"))

    def test_task_controls_under_count_and_quick_add_in_header(self):
        self.root.update()
        desktop = self.app.desktop
        button = desktop.add_button
        counter = desktop.counter
        self.assertTrue(button.winfo_viewable())
        self.assertEqual(button.label, "＋")
        self.assertEqual(desktop.more.label, "▾")
        self.assertEqual(desktop.menu_button.label, "···")
        self.assertEqual(len({(icon.background, icon.foreground, icon.hover)
                              for icon in (button, desktop.more, desktop.menu_button)}), 1)
        spans = []
        for icon in (button, desktop.more, desktop.menu_button):
            glyph = [item for item in icon.find_all() if "surface" not in icon.gettags(item)]
            self.assertNotIn("text", [icon.type(item) for item in glyph])
            x_coords = [x for item in glyph for x in icon.coords(item)[::2]]
            spans.append(max(x_coords) - min(x_coords))
        for span in spans[1:]:
            self.assertAlmostEqual(span, spans[0])
        self.assertLess(button.winfo_rootx(), desktop.more.winfo_rootx())
        self.assertGreaterEqual(button.winfo_rooty(), counter.winfo_rooty() + counter.winfo_height())
        self.assertLess(desktop.quick_add.winfo_rooty(), counter.winfo_rooty())
        self.assertEqual(desktop.quick_menu.index("end"), 3)
        button.invoke()
        self.assertTrue(self.app.task_editor.window.winfo_exists())

    def test_note_brand_and_library_count(self):
        self.assertEqual(self.root.title(), "Note")
        self.store.save_note("便签", "已保存", "生活")
        self.app.refresh_notes()
        self.assertEqual(self.app.workspace.note_count.get(), 1)

    def test_dragging_third_visible_slot_keeps_hidden_items_after_it(self):
        ids = [self.store.save_task(f"事项 {i}", "工作", datetime(2026, 11, 8, 10 + i), None)
               for i in range(4)]
        self.app.refresh_tasks()
        self.root.update()
        desktop = self.app.desktop
        source = desktop.cards[ids[0]].title
        last = desktop.cards[ids[2]].frame
        start_x, start_y = source.winfo_rootx() + 5, source.winfo_rooty() + 5
        end_y = last.winfo_rooty() + last.winfo_height() - 2
        source.event_generate("<ButtonPress-1>", x=5, y=5, rootx=start_x, rooty=start_y)
        source.event_generate("<B1-Motion>", x=5, y=end_y - source.winfo_rooty(), rootx=start_x, rooty=end_y)
        source.event_generate("<ButtonRelease-1>", x=5, y=end_y - source.winfo_rooty(),
                              rootx=start_x, rooty=end_y)
        self.assertEqual(list(desktop.cards), [ids[1], ids[2], ids[0]])
        self.assertEqual([row["id"] for row in self.store.desktop_tasks()], [ids[1], ids[2], ids[0], ids[3]])
        self.assertEqual(list(self.app.workspace.tasks.items), [ids[1], ids[2], ids[0], ids[3]])
