# 架构与代码阅读

## 总体结构

Python 为应用语言，Tkinter 管理事件与显示，SQLite 保存本地记录。`CourseDesk` 和 `Store` 是本项目定义的类，不是外部框架。

```mermaid
flowchart LR
    User[用户操作] --> UI[Tkinter 页面与回调]
    UI --> App[CourseDesk 协调与校验]
    App --> Store[Store 数据访问]
    Store --> DB[(SQLite)]
    DB --> Store
    Store --> App
    App --> Main[Workspace 管理窗口]
    App --> Desktop[DesktopPanel 桌面组件]
```

当前采用按职责分模块的单机设计，部分校验和处理仍在界面类中，不是严格的 MVC 框架。

## 关键调用链

| 场景 | 调用关系 |
|---|---|
| 启动 | `main → Store(database_path()) → CourseDesk → root.mainloop` |
| 保存任务 | `TaskEditor.save → Store.save_task → CourseDesk.refresh_tasks` |
| 拖动排序 | `finish_task_drag → Store.move_desktop_task → refresh_tasks` |
| 完成任务 | `CourseDesk.complete_task → Store.set_done → refresh_tasks` |
| 桌面便签 | `schedule_note_save → flush_note → Store.write_desktop_note` |
| 编辑器便签 | `NoteEditor.schedule_save → save → Store.save_note` |
| 日记 | `JournalPage.schedule_save → save → Store.save_journal` |
| 提醒 | `tick → check_reminders → Store.take_reminders → DesktopPanel.show_reminders` |
| 日历 | `CalendarPage.refresh → calendar_days / calendar_summary → render_records` |

## 主要数据表

| 表 | 主键/关联 | 作用 |
|---|---|---|
| tasks | id | 待办名称、分类、时间和完成状态 |
| desktop_task_order | task_id → tasks.id | 手动显示顺序 |
| notes | id | 便签正文、图片、模板与时间 |
| desktop_selection | singleton=1；note_id → notes.id | 桌面选中的便签 |
| journal_entries | (kind, day) | 每天每类日记一条，内容为 JSON |
| ledger_entries | id；day 索引 | 同日多笔收支，金额为整数分 |
| custom_categories | name | 分类和颜色覆盖 |
| removed_categories | name | 记住被删除的默认分类 |

`priority`、`manual_order` 是兼容旧数据保留的历史字段；当前手动排序主要使用 `desktop_task_order`。数据库通过检查已有列并增量 `ALTER TABLE` 升级。

## 关键设计

- **时间与顺序分离**：新任务在当前列表中找到第一个截止更晚或无截止的位置插入，已有元素相对顺序保留；拖动后持久化位置。
- **保存与显示分离**：数据库提交后显式重读和刷新。管理页筛选不会改变桌面的全部任务来源。
- **自动保存**：便签 450 毫秒、日记 650 毫秒防抖，比较内容后写入，切换和正常退出前再尝试保存。
- **提醒**：大约每 2.5 秒检查；SQL 同时标记 `reminded` 并返回本次任务。30 秒快捷选项保留秒数。提醒和便签都位于桌面同一组件内，布局会让位。
- **金额**：使用整数分，合计后格式化为元；不执行用户输入的表达式。
- **图片**：限制像素量，使用 Pillow 修正方向、等比例缩小，转为 PNG 后存入 BLOB。
- **日期归属**：便签使用 created_at；日记、账单使用 day；完成待办使用 completed_at。旧记录缺失的历史时间无法凭空还原。
- **日历统计**：`UNION` 查询有记录的日期；`UNION ALL + GROUP BY + SUM/COUNT` 汇总每日数字，再点选读取明细。

## 验证与维护

执行 `test.cmd` 检查数据和真实 Tk 窗口行为。测试使用临时数据库。更改持久化字段、金额规则、日期归档或调用关系时，同步更新本文件与 README，并保留旧记录可读取性。

应用没有完整任务事件历史、跨实例冲突合并、云端服务或独立提醒后台进程。避免把现有完成时间当成历史状态快照，也不要将提醒领取标记解释为任何异常下的送达保证。
