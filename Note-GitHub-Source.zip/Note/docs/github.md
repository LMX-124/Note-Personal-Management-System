# 上传到 GitHub

## 源码仓库

1. 解压 `Note-GitHub-Source.zip`，进入里面的 `Note` 文件夹。
2. 在 GitHub 新建仓库，名称可用 `note-desktop`，简介可写“Python + Tkinter + SQLite 的本地待办、便签与日记工具”。
3. 将 `Note` 文件夹**里面的内容**上传到仓库根目录，使 README.md、app.py 在首页根目录可见。不要只上传 ZIP，否则同学不能直接浏览代码。
4. 确认 `.gitignore`、`.gitattributes`、`.github/workflows/tests.yml` 等隐藏文件也在提交中。
5. 等 GitHub Actions 运行，查看结果；本地测试通过不等于仓库云端流程已执行。

也可以在这个 Note 文件夹打开 PowerShell，通过 Git 提交。以下只在独立的 Note 文件夹执行，避免提交其他项目或个人目录：

```powershell
git init
git add .
git commit -m "Add Note desktop application"
git branch -M main
```

然后复制 GitHub 新建仓库页面给出的 remote 和 push 命令。仓库 URL 取决于你创建的账号和仓库，本包不预填虚构地址。

## Windows 运行包

在仓库的 Releases 创建一个版本发布，将单独的 `Note-Windows.zip` 和 `SHA256SUMS.txt` 附到发布中。README 已说明同学可从 Releases 下载运行包。

不要把本机的数据库、备份、`.venv`、临时目录、私密截图、课程花名册或带个人资料的 PPT 上传进源码仓库。本包已按允许文件清单整理，不包含这些内容。

未代作者选择开源许可证。正式发布前可自行决定是否添加 LICENSE，GitHub 托管源码本身不等于已经指定了某种开源许可证。

参考：[GitHub 上传文件说明](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)。
