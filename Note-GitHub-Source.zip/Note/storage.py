import json
import os
import sqlite3
from contextlib import closing
from datetime import date, datetime
from pathlib import Path

from palette import DEFAULT_CATEGORIES, NEUTRAL, PALETTE, UNCATEGORIZED

def next_category_color(used):
    return next((color for color in ("#674183", *PALETTE) if color not in used), "#674183")


def database_path():
    override = os.environ.get("COURSE_DESK_DB")
    if override:
        return Path(override)
    local = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    return local / "CourseDesk" / "course_desk.sqlite3"


def timestamp(value):
    return value.isoformat(sep=" ", timespec="seconds") if value is not None else None


class Store:
    def __init__(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        with self.db, closing(self.db.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                priority INTEGER NOT NULL CHECK (priority BETWEEN 1 AND 3),
                due_at TEXT,
                remind_at TEXT,
                reminded INTEGER NOT NULL DEFAULT 0,
                done INTEGER NOT NULL DEFAULT 0,
                manual_order INTEGER
            );
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                category TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS desktop_selection (
                singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                note_id INTEGER REFERENCES notes(id) ON DELETE SET NULL
            );
            CREATE TABLE IF NOT EXISTS custom_categories (
                name TEXT PRIMARY KEY,
                color TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS removed_categories (
                name TEXT PRIMARY KEY
            );
            CREATE TABLE IF NOT EXISTS desktop_task_order (
                task_id INTEGER PRIMARY KEY REFERENCES tasks(id) ON DELETE CASCADE,
                position INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS journal_entries (
                kind TEXT NOT NULL CHECK (kind IN ('mood', 'review')),
                day TEXT NOT NULL,
                contents TEXT NOT NULL,
                PRIMARY KEY (kind, day)
            );
            CREATE TABLE IF NOT EXISTS ledger_entries (
                id INTEGER PRIMARY KEY,
                day TEXT NOT NULL,
                kind TEXT NOT NULL CHECK (kind IN ('income', 'expense')),
                cents INTEGER NOT NULL CHECK (cents BETWEEN 1 AND 99999999999),
                memo TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ledger_entries_day ON ledger_entries(day);
            INSERT OR IGNORE INTO desktop_task_order (task_id, position)
            SELECT id, COALESCE((SELECT MAX(position) FROM desktop_task_order), -1) +
                       ROW_NUMBER() OVER (ORDER BY due_at IS NULL, due_at, id)
            FROM tasks
            WHERE done = 0 AND id NOT IN (SELECT task_id FROM desktop_task_order);
        """)):
            pass
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            columns = {row["name"] for row in self.db.execute("PRAGMA table_info(notes)")}
            if "template" not in columns:
                self.db.execute("ALTER TABLE notes ADD COLUMN template TEXT NOT NULL DEFAULT 'lined'")
            if "image" not in columns:
                self.db.execute("ALTER TABLE notes ADD COLUMN image BLOB")
            if "created_at" not in columns:
                self.db.execute("ALTER TABLE notes ADD COLUMN created_at TEXT NOT NULL DEFAULT ''")
                self.db.execute("UPDATE notes SET created_at = updated_at")
            task_columns = {row["name"] for row in self.db.execute("PRAGMA table_info(tasks)")}
            if "completed_at" not in task_columns:
                self.db.execute("ALTER TABLE tasks ADD COLUMN completed_at TEXT")
            ledger_columns = {row["name"] for row in self.db.execute("PRAGMA table_info(ledger_entries)")}
            if "category" not in ledger_columns:
                self.db.execute("ALTER TABLE ledger_entries ADD COLUMN category TEXT NOT NULL DEFAULT ''")

    def close(self):
        self.db.close()

    def tasks(self, limit=-1, include_done=False):
        return self.db.execute("""
            SELECT * FROM tasks
            WHERE done = 0 OR ?
            ORDER BY done, due_at IS NULL, due_at, id
            LIMIT ?
        """, (include_done, limit)).fetchall()

    def desktop_tasks(self, include_done=False):
        return self.db.execute("""
            SELECT tasks.*
            FROM tasks
            LEFT JOIN desktop_task_order ON task_id = tasks.id AND tasks.done = 0
            WHERE tasks.done = 0 OR ?
            ORDER BY tasks.done, position IS NULL, position, due_at IS NULL, due_at, tasks.id
        """, (include_done,)).fetchall()

    def write_desktop_order(self, task_ids):
        self.db.executemany("""
            INSERT INTO desktop_task_order (position, task_id) VALUES (?, ?)
            ON CONFLICT (task_id) DO UPDATE SET position = excluded.position
        """, enumerate(task_ids))

    def place_desktop_task(self, task_id, due_at):
        existing = [row for row in self.desktop_tasks() if row["id"] != task_id]
        position = len(existing)
        if due_at is not None:
            position = next((index for index, row in enumerate(existing)
                             if row["due_at"] is None or row["due_at"] > due_at), position)
        order = [row["id"] for row in existing]
        order.insert(position, task_id)
        self.write_desktop_order(order)

    def move_desktop_task(self, task_id, before_id):
        if task_id == before_id:
            return
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            order = [row["id"] for row in self.desktop_tasks()]
            if task_id not in order or (before_id is not None and before_id not in order):
                return
            order.remove(task_id)
            position = order.index(before_id) if before_id is not None else len(order)
            order.insert(position, task_id)
            self.write_desktop_order(order)

    def save_task(self, title, category, due_at, remind_at, task_id=None):
        title = title.strip()
        if not title:
            raise ValueError("请输入待办名称。")
        reminder = timestamp(remind_at)
        deadline = timestamp(due_at)
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            values = (title, self.active_category(category), deadline, reminder)
            if task_id is None:
                task_id = self.db.execute("""
                    INSERT INTO tasks (title, category, priority, due_at, remind_at)
                    VALUES (?, ?, 2, ?, ?)
                """, values).lastrowid
                self.place_desktop_task(task_id, deadline)
                return task_id
            self.db.execute("""
                UPDATE tasks
                SET title = ?, category = ?, due_at = ?, remind_at = ?,
                    reminded = CASE WHEN remind_at IS ? THEN reminded ELSE 0 END
                WHERE id = ?
            """, (*values, reminder, task_id))
        return task_id

    def set_done(self, task_id, done):
        with self.db:
            row = self.db.execute("""
                UPDATE tasks SET done = ?, completed_at = ? WHERE id = ? AND done <> ? RETURNING due_at
            """, (int(done), timestamp(datetime.now()) if done else None, task_id, int(done))).fetchone()
            if row is None:
                return
            if done:
                self.db.execute("DELETE FROM desktop_task_order WHERE task_id = ?", (task_id,))
            else:
                self.place_desktop_task(task_id, row["due_at"])

    def delete_task(self, task_id):
        with self.db:
            self.db.execute("DELETE FROM tasks WHERE id = ?", (task_id,))

    def take_reminders(self, now):
        with self.db:
            return self.db.execute("""
                UPDATE tasks SET reminded = 1
                WHERE done = 0 AND reminded = 0 AND remind_at <= ?
                RETURNING id, title, category, due_at, remind_at
            """, (timestamp(now),)).fetchall()

    def notes(self, search="", category=""):
        search = search.strip().lower()
        return self.db.execute("""
            SELECT * FROM notes
            WHERE (instr(lower(title), ?) OR instr(lower(body), ?))
              AND (? = '' OR category = ?)
            ORDER BY updated_at DESC, id DESC
        """, (search, search, category, category)).fetchall()

    def save_note(self, title, body, category, note_id=None, *, template=None, image=None):
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            values = (title.strip(), body, self.active_category(category), timestamp(datetime.now()))
            if note_id is None:
                return self.db.execute("""
                    INSERT INTO notes (title, body, category, updated_at, created_at, template, image)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (*values, values[-1], template or "lined", image)).lastrowid
            self.db.execute("""
                UPDATE notes SET title = ?, body = ?, category = ?, updated_at = ?,
                    template = COALESCE(?, template), image = CASE WHEN ? IS NULL THEN image ELSE ? END
                WHERE id = ?
            """, (*values, template, template, image, note_id))
        return note_id

    def delete_note(self, note_id):
        with self.db:
            self.db.execute("DELETE FROM notes WHERE id = ?", (note_id,))

    def desktop_note(self):
        return self.db.execute("""
            SELECT notes.* FROM desktop_selection
            JOIN notes ON notes.id = desktop_selection.note_id
            WHERE singleton = 1
        """).fetchone()

    def set_desktop_note(self, note_id):
        with self.db:
            self.db.execute("""
                INSERT INTO desktop_selection (singleton, note_id) VALUES (1, ?)
                ON CONFLICT(singleton) DO UPDATE SET note_id = excluded.note_id
            """, (note_id,))

    def write_desktop_note(self, body, *, title=None, template="lined", image=None, category=UNCATEGORIZED):
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            note = self.desktop_note()
            now = timestamp(datetime.now())
            if note is None:
                note_id = self.db.execute("""
                    INSERT INTO notes (title, body, category, updated_at, template, image, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (title or "", body, self.active_category(category), now, template, image, now)).lastrowid
                self.db.execute("""
                    INSERT INTO desktop_selection (singleton, note_id) VALUES (1, ?)
                    ON CONFLICT(singleton) DO UPDATE SET note_id = excluded.note_id
                """, (note_id,))
            else:
                if title is None:
                    self.db.execute("UPDATE notes SET body = ?, updated_at = ? WHERE id = ?",
                                    (body, now, note["id"]))
                else:
                    self.db.execute("""UPDATE notes SET title = ?, body = ?, updated_at = ?,
                                    template = ?, image = ? WHERE id = ?""",
                                    (title, body, now, template, image, note["id"]))
        return self.desktop_note()

    def categories(self):
        return list(self.category_colors())

    def category_colors(self):
        removed = {row["name"] for row in self.db.execute("SELECT name FROM removed_categories")}
        colors = {name: color for name, color in DEFAULT_CATEGORIES.items() if name not in removed}
        stored = self.db.execute("SELECT name, color FROM custom_categories ORDER BY rowid")
        colors.update((row["name"], row["color"]) for row in stored)
        legacy = self.db.execute("SELECT category FROM tasks UNION SELECT category FROM notes ORDER BY 1")
        for row in legacy:
            name = row["category"]
            if name not in colors and name not in removed:
                colors[name] = NEUTRAL if name == UNCATEGORIZED else next_category_color(colors.values())
        return colors or {UNCATEGORIZED: NEUTRAL}

    def active_category(self, category):
        name = category.strip() or UNCATEGORIZED
        removed = self.db.execute("SELECT 1 FROM removed_categories WHERE name = ?", (name,)).fetchone()
        return UNCATEGORIZED if removed or name == "全部分类" else name

    def create_category(self, name):
        name = name.strip()
        if not name or len(name) > 20:
            raise ValueError("请输入 1–20 个字符的分类名称。")
        if name in ("全部分类", UNCATEGORIZED):
            raise ValueError("这个名称已用于系统分类。")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            colors = self.category_colors()
            if name.casefold() in {category.casefold() for category in colors}:
                raise ValueError("此分类已存在。")
            self.db.execute("INSERT INTO custom_categories (name, color) VALUES (?, ?)",
                            (name, next_category_color(colors.values())))
            self.db.execute("DELETE FROM removed_categories WHERE name = ?", (name,))
        return name

    def set_category_color(self, name, color):
        if color not in PALETTE:
            raise ValueError("请选择一个预设颜色。")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            if name not in self.category_colors():
                raise ValueError("此分类已不存在。")
            self.db.execute("""
                INSERT INTO custom_categories (name, color) VALUES (?, ?)
                ON CONFLICT (name) DO UPDATE SET color = excluded.color
            """, (name, color))

    def delete_category(self, name):
        if name == UNCATEGORIZED:
            raise ValueError("「未分类」用于接收移出的记录。")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            if name not in self.category_colors():
                raise ValueError("此分类已不存在。")
            self.db.execute("UPDATE tasks SET category = ? WHERE category = ?", (UNCATEGORIZED, name))
            self.db.execute("UPDATE notes SET category = ? WHERE category = ?", (UNCATEGORIZED, name))
            self.db.execute("DELETE FROM custom_categories WHERE name = ?", (name,))
            self.db.execute("INSERT OR IGNORE INTO removed_categories (name) VALUES (?)", (name,))

    def notes_on(self, day):
        return self.db.execute("""
            SELECT * FROM notes WHERE created_at LIKE ? ORDER BY created_at, id
        """, (day.isoformat() + "%",)).fetchall()

    def calendar_days(self, month):
        prefix = month.isoformat()[:7] + "-%"
        return {date.fromisoformat(row[0]) for row in self.db.execute("""
            SELECT substr(created_at, 1, 10) FROM notes WHERE created_at LIKE ?
            UNION SELECT day FROM journal_entries WHERE day LIKE ?
            UNION SELECT day FROM ledger_entries WHERE day LIKE ?
            UNION SELECT substr(completed_at, 1, 10) FROM tasks WHERE done = 1 AND completed_at LIKE ?
        """, (prefix, prefix, prefix, prefix))}

    def calendar_summary(self, month):
        prefix = month.isoformat()[:7] + "-%"
        rows = self.db.execute("""
            SELECT day, SUM(notes) AS notes, SUM(journals) AS journals,
                   SUM(income) AS income, SUM(expense) AS expense, SUM(bills) AS bills
            FROM (
                SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS notes,
                       0 AS journals, 0 AS income, 0 AS expense, 0 AS bills
                FROM notes WHERE created_at LIKE ? GROUP BY day
                UNION ALL
                SELECT day, 0, COUNT(*), 0, 0, 0 FROM journal_entries WHERE day LIKE ? GROUP BY day
                UNION ALL
                SELECT day, 0, 0,
                       SUM(CASE WHEN kind = 'income' THEN cents ELSE 0 END),
                       SUM(CASE WHEN kind = 'expense' THEN cents ELSE 0 END), COUNT(*)
                FROM ledger_entries WHERE day LIKE ? GROUP BY day
            ) GROUP BY day
        """, (prefix, prefix, prefix)).fetchall()
        return {date.fromisoformat(row["day"]): dict(row) for row in rows}

    def completed_tasks_on(self, day):
        return self.db.execute("""
            SELECT * FROM tasks WHERE done = 1 AND completed_at LIKE ? ORDER BY completed_at DESC, id DESC
        """, (day.isoformat() + "%",)).fetchall()

    def ledger_entries(self, day):
        return self.db.execute("""
            SELECT id, kind, cents, memo, category FROM ledger_entries WHERE day = ? ORDER BY id
        """, (day.isoformat(),)).fetchall()

    def save_ledger_entry(self, day, kind, cents, memo, entry_id=None, *, category=None):
        values = (kind, cents, memo.strip(), category, day.isoformat())
        with self.db:
            if entry_id is None:
                return self.db.execute("""
                    INSERT INTO ledger_entries (kind, cents, memo, category, day)
                    VALUES (?, ?, ?, COALESCE(?, ''), ?)
                """, values).lastrowid
            self.db.execute("""
                UPDATE ledger_entries SET kind = ?, cents = ?, memo = ?, category = COALESCE(?, category)
                WHERE day = ? AND id = ?
            """, (*values, entry_id))
        return entry_id

    def delete_ledger_entry(self, day, entry_id):
        with self.db:
            self.db.execute("DELETE FROM ledger_entries WHERE day = ? AND id = ?",
                            (day.isoformat(), entry_id))

    def journal(self, kind, day):
        row = self.db.execute("SELECT contents FROM journal_entries WHERE kind = ? AND day = ?",
                              (kind, day.isoformat())).fetchone()
        return json.loads(row["contents"]) if row is not None else None

    def journal_dates(self, kind):
        rows = self.db.execute("SELECT day FROM journal_entries WHERE kind = ? ORDER BY day DESC", (kind,))
        return [date.fromisoformat(row["day"]) for row in rows]

    def save_journal(self, kind, day, contents):
        key = (kind, day.isoformat())
        has_content = any(text.strip() for value in contents.values()
                          for text in (value if isinstance(value, list) else (value,)))
        with self.db:
            if has_content:
                self.db.execute("""
                    INSERT INTO journal_entries (kind, day, contents) VALUES (?, ?, ?)
                    ON CONFLICT (kind, day) DO UPDATE SET contents = excluded.contents
                """, (*key, json.dumps(contents, ensure_ascii=False)))
            else:
                self.db.execute("DELETE FROM journal_entries WHERE kind = ? AND day = ?", key)
        return has_content
