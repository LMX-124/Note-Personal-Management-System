import re
import sqlite3
import tkinter as tk
from datetime import date
from tkinter import messagebox, ttk

from visual import ACCENT, BG, FONT, INK, MUTED, PRIMARY, WHITE, Action, pixels


KINDS = {"expense": "支出", "income": "收入"}
CATEGORIES = {
    "支出": ("餐饮", "交通", "购物", "学习", "娱乐", "医疗", "住房", "其他"),
    "收入": ("工资", "兼职", "奖金", "红包", "退款", "补贴", "理财", "其他"),
}


def parse_cents(text):
    match = re.fullmatch(r"([0-9]{1,9})(?:\.([0-9]{1,2}))?", text.strip())
    if match:
        cents = int(match[1]) * 100 + int((match[2] or "").ljust(2, "0"))
        if cents:
            return cents
    raise ValueError("请输入大于 0 的金额，最多保留两位小数。")


def money(cents):
    units, remainder = divmod(abs(cents), 100)
    return f"{'-' if cents < 0 else ''}¥{units:,}.{remainder:02d}"


def ledger_totals(rows):
    totals = dict.fromkeys(KINDS, 0)
    for row in rows:
        totals[row["kind"]] += row["cents"]
    return totals["income"], totals["expense"]


class LedgerWindow:
    def __init__(self, app, day, on_change, *, parent=None):
        self.app = app
        self.day = day
        self.on_change = on_change
        self.editing = None
        self.quick = parent is None
        window = self.window = parent if parent is not None else tk.Toplevel(app.root, bg=BG)
        if parent is None:
            window.title("本日记账")
            window.minsize(pixels(window, 350), pixels(window, 465))
        body = tk.Frame(window, bg=BG, padx=pixels(window, 18), pady=pixels(window, 15))
        body.pack(fill="both", expand=True)
        self.heading = tk.Label(body, bg=BG, fg=INK, font=(FONT, 16, "bold"))
        self.heading.pack(anchor="w")
        if parent is not None:
            dates = tk.Frame(body, bg=BG)
            dates.pack(fill="x", pady=(0, pixels(body, 6)))
            self.date_input = tk.StringVar(window)
            entry = ttk.Entry(dates, textvariable=self.date_input, width=13)
            entry.pack(side="left")
            entry.bind("<Return>", lambda event: self.choose_date())
            Action(dates, "查看日期", self.choose_date, BG, height=28).pack(side="left", padx=5)
            Action(dates, "今天", lambda: self.select_date(date.today()), BG, height=28).pack(side="left")
        self.summary = tk.Label(body, bg=BG, fg=ACCENT, font=(FONT, 11, "bold"))
        self.summary.pack(anchor="w", pady=(0, pixels(body, 10)))

        columns = tk.Frame(body, bg=BG)
        columns.pack(fill="both", expand=True)
        self.list = None
        if not self.quick:
            self.build_history(columns)
        self.build_entry(columns)
        if self.quick:
            window.bind("<Escape>", lambda event: window.destroy())
            window.bind("<Map>", self.focus_form)
        self.refresh()

    def build_history(self, parent):
        history = tk.Frame(parent, bg=BG)
        history.pack(side="left", fill="both", expand=True, padx=(0, pixels(parent, 12)))
        tk.Label(history, text="当天明细", bg=BG, fg=INK, font=(FONT, 11, "bold")).pack(anchor="w")
        list_frame = tk.Frame(history, bg=BG)
        list_frame.pack(fill="both", expand=True, pady=pixels(parent, 4))
        ttk.Style(parent).configure("Ledger.Treeview", rowheight=pixels(parent, 27), font=(FONT, 10))
        self.list = ttk.Treeview(list_frame, columns=("category", "amount", "memo"), show="headings",
                                 selectmode="browse", height=5, style="Ledger.Treeview")
        for column, title, width in (("category", "分类", 61), ("amount", "金额", 80), ("memo", "备注", 68)):
            self.list.heading(column, text=title)
            self.list.column(column, width=pixels(parent, width), stretch=column == "memo",
                             anchor="e" if column == "amount" else "w")
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.list.yview)
        self.list.configure(yscrollcommand=scroll.set)
        self.list.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.list.bind("<Double-Button-1>", self.edit_selected)
        actions = tk.Frame(history, bg=BG)
        actions.pack(fill="x")
        Action(actions, "修改选中", self.edit_selected, BG, height=27).pack(side="left")
        Action(actions, "删除选中", self.delete_selected, BG, height=27).pack(side="left", padx=5)

    def build_entry(self, parent):
        window = self.window
        form = tk.Frame(parent, bg=WHITE, padx=pixels(parent, 8), pady=pixels(parent, 6))
        form.pack(side="right", fill="both", expand=self.quick)
        self.kind = tk.StringVar(window, "支出")
        self.category = tk.StringVar(window, "")
        self.amount = tk.StringVar(window)
        self.memo = tk.StringVar(window)
        self.form_title = tk.StringVar(window, "记一笔")
        toolbar = tk.Frame(form, bg=WHITE)
        toolbar.pack(fill="x", pady=(0, 4))
        tk.Label(toolbar, textvariable=self.form_title, bg=WHITE, fg=INK,
                 font=(FONT, 10, "bold")).pack(side="left")
        self.kind_buttons = {}
        for label in reversed(tuple(KINDS.values())):
            button = Action(toolbar, label, lambda value=label: self.set_kind(value), WHITE,
                            width=47, height=29, bold=True)
            button.pack(side="right", padx=4)
            self.kind_buttons[label] = button
        self.category_grid = tk.Frame(form, bg=WHITE)
        self.category_grid.pack(fill="x")
        self.draw_categories()
        amount_row = tk.Frame(form, bg=WHITE)
        amount_row.pack(fill="x", pady=(5, 4))
        tk.Label(amount_row, text="¥", bg=WHITE, fg=ACCENT, font=(FONT, 18, "bold")).pack(side="left")
        self.amount_input = ttk.Entry(amount_row, textvariable=self.amount, width=11,
                                      justify="right", font=(FONT, 17, "bold"))
        self.amount_input.pack(side="right", fill="x", expand=True, padx=(7, 0))
        memo_row = tk.Frame(form, bg=WHITE)
        memo_row.pack(fill="x", pady=(0, 5))
        tk.Label(memo_row, text="备注", bg=WHITE, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(0, 5))
        memo_input = ttk.Entry(memo_row, textvariable=self.memo, width=16)
        memo_input.pack(side="left", fill="x", expand=True)
        for entry in (self.amount_input, memo_input):
            entry.bind("<Return>", lambda event: self.save())
        keys = tk.Frame(form, bg=WHITE)
        keys.pack(fill="x")
        keys.columnconfigure((0, 1, 2, 3), weight=1, uniform="key")
        for index, key in enumerate(("7", "8", "9", "⌫", "4", "5", "6", "清空",
                                     "1", "2", "3", "再记", ".", "0", "00", "完成")):
            callback = self.reset if key == "清空" else (
                self.save if key == "再记" else self.finish if key == "完成" else lambda v=key: self.key(v))
            Action(keys, key, callback, WHITE, width=54, height=34, bold=key in ("完成", "再记"),
                   background=PRIMARY if key == "完成" else "#edf4fc",
                   foreground=ACCENT if key == "完成" else INK).grid(
                row=index // 4, column=index % 4, padx=2, pady=2, sticky="ew")

    def set_kind(self, label):
        if label != self.kind.get():
            self.kind.set(label)
            self.category.set("")
            self.draw_categories()

    def draw_categories(self):
        for label, button in self.kind_buttons.items():
            button.update_style(label, PRIMARY if label == self.kind.get() else WHITE, ACCENT)
        for child in self.category_grid.winfo_children():
            child.destroy()
        self.category_grid.columnconfigure((0, 1, 2, 3), weight=1, uniform="category")
        for index, label in enumerate(CATEGORIES[self.kind.get()]):
            Action(self.category_grid, label, lambda value=label: self.set_category(value), WHITE,
                   width=54, height=30, background=PRIMARY if label == self.category.get() else "#f3f6fa",
                   foreground=ACCENT if label == self.category.get() else INK).grid(
                row=index // 4, column=index % 4, padx=2, pady=2, sticky="ew")

    def set_category(self, label):
        self.category.set(label)
        self.draw_categories()
        self.amount_input.focus_set()

    def key(self, key):
        value = self.amount.get()
        if key == "⌫":
            self.amount.set(value[:-1])
        else:
            updated = (value or "0") + "." if key == "." else value + key
            if re.fullmatch(r"[0-9]{1,9}(?:\.[0-9]{0,2})?", updated):
                self.amount.set(updated)

    def finish(self):
        if self.save() and self.quick:
            self.window.destroy()

    def choose_date(self):
        try:
            day = date.fromisoformat(self.date_input.get().strip())
        except ValueError:
            messagebox.showwarning("日期格式", "请按 YYYY-MM-DD 输入日期。", parent=self.window)
            return
        self.select_date(day)

    def select_date(self, day):
        if day != self.day:
            if (self.amount.get().strip() or self.memo.get().strip()) and not messagebox.askyesno(
                    "切换日期", "当前有未保存的输入。放弃输入并切换日期？", parent=self.window):
                self.date_input.set(self.day.isoformat())
                return False
            self.day = day
            self.reset()
        self.refresh()
        return True

    def focus_form(self, event):
        if event.widget == self.window:
            self.window.grab_set()
            self.amount_input.focus_set()

    def refresh(self):
        self.heading.configure(text=f"{self.day.isoformat()}  ·  记账")
        if hasattr(self, "date_input"):
            self.date_input.set(self.day.isoformat())
        self.rows = {str(row["id"]): row for row in self.app.store.ledger_entries(self.day)}
        if self.list is not None:
            self.list.delete(*self.list.get_children())
            for key, row in self.rows.items():
                kind = row["kind"]
                amount = money(row["cents"] if kind == "income" else -row["cents"])
                self.list.insert("", "end", iid=key, values=(row["category"] or KINDS[kind], amount, row["memo"]))
        income, expense = ledger_totals(self.rows.values())
        self.summary.configure(text=f"收入 {money(income)}    支出 {money(expense)}    结余 {money(income - expense)}")

    def selected_row(self):
        selected = self.list.selection()
        return self.rows[selected[0]] if selected else None

    def reset(self):
        self.editing = None
        self.form_title.set("记一笔")
        self.kind.set("支出")
        self.category.set("")
        self.amount.set("")
        self.memo.set("")
        self.draw_categories()
        self.amount_input.focus_set()

    def edit_selected(self, event=None):
        row = self.selected_row()
        if row is not None:
            self.editing = row["id"]
            self.form_title.set("修改这笔记录")
            self.kind.set(KINDS[row["kind"]])
            self.category.set(row["category"])
            self.amount.set(money(row["cents"]).replace(",", "")[1:])
            self.memo.set(row["memo"])
            self.draw_categories()
            self.amount_input.focus_set()

    def save(self):
        try:
            cents = parse_cents(self.amount.get())
        except ValueError as error:
            messagebox.showwarning("金额格式", str(error), parent=self.window)
            return
        kind = next(key for key, label in KINDS.items() if label == self.kind.get())
        try:
            self.app.store.save_ledger_entry(self.day, kind, cents, self.memo.get(), self.editing,
                                             category=self.category.get())
        except sqlite3.Error as error:
            self.app.show_data_error(self.window, error)
            return
        self.reset()
        self.refresh()
        self.on_change()
        return True

    def delete_selected(self):
        row = self.selected_row()
        if row is None or not messagebox.askyesno("删除记账", "删除选中的这笔记录？", parent=self.window):
            return
        try:
            self.app.store.delete_ledger_entry(self.day, row["id"])
        except sqlite3.Error as error:
            self.app.show_data_error(self.window, error)
            return
        if self.editing == row["id"]:
            self.reset()
        self.refresh()
        self.on_change()
